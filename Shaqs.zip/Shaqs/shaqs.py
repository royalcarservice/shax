import sqlite3
import webbrowser
from pathlib import Path

from skills.agent import run_agent
from skills.website_builder import create_website


DB_NAME = "memory.db"


# --------------------------------
# DATABASE
# --------------------------------

def setup_database():

    connection = sqlite3.connect(DB_NAME)

    connection.execute("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            memory TEXT NOT NULL
        )
    """)

    connection.commit()
    connection.close()


def save_memory(memory):

    connection = sqlite3.connect(DB_NAME)

    connection.execute(
        "INSERT INTO memories (memory) VALUES (?)",
        (memory,)
    )

    connection.commit()
    connection.close()


def get_memories():

    connection = sqlite3.connect(DB_NAME)

    rows = connection.execute(
        "SELECT memory FROM memories ORDER BY id"
    ).fetchall()

    connection.close()

    return [row[0] for row in rows]


# --------------------------------
# STARTUP
# --------------------------------

setup_database()

memories = get_memories()


# --------------------------------
# START SYSTEM
# --------------------------------

print("=================================")
print("        SHAQS AI ASSISTANT")
print("=================================")
print("Type 'exit' to close Shaqs.")
print("Type 'remember <something>' to save a memory.")
print("Type 'memories' to view saved memories.")
print()

conversation = []


# --------------------------------
# MAIN LOOP
# --------------------------------

while True:

    user_message = input("You: ").strip()


    # --------------------------------
    # EXIT
    # --------------------------------

    if user_message.lower() == "exit":

        print("Shaqs: Goodbye!")

        break


    # --------------------------------
    # SAVE MEMORY
    # --------------------------------

    if user_message.lower().startswith("remember "):

        memory = user_message[9:].strip()

        if memory:

            save_memory(memory)
            memories.append(memory)

            print("Shaqs: I'll remember that.")

        else:

            print(
                "Shaqs: What would you like me to remember?"
            )

        print()

        continue


    # --------------------------------
    # SHOW MEMORIES
    # --------------------------------

    if user_message.lower() == "memories":

        if memories:

            print("\nShaqs remembers:")

            for i, memory in enumerate(
                memories,
                start=1
            ):

                print(f"{i}. {memory}")

        else:

            print(
                "Shaqs: I don't have any saved memories yet."
            )

        print()

        continue


   # --------------------------------
# WEBSITE BUILDER
# --------------------------------

lower_message = user_message.lower()

website_keywords = [
    "create a website",
    "build a website",
    "make a website",
    "design a website",
    "website for",
    "build me a website",
    "make me a website",
    "create me a website"
]

if any(keyword in lower_message for keyword in website_keywords):

    print("\nShaqs: I'll help you build the website.")

    # Ask the AI whether the request contains enough
    # information to start building.
    try:
        from ollama import chat

        decision_prompt = f"""
You are the website-request planning assistant for Shaqs.

Determine whether the user's request contains enough information
to begin building a website.

USER REQUEST:
{user_message}

We normally need:
- Business/project name
- Type of business/project
- Main products or services/content
- Main purpose of the website

Contact details, address, phone number, WhatsApp number,
opening hours, prices, reviews, ratings, certifications,
and other factual business information are OPTIONAL.

IMPORTANT:
- Never invent missing factual information.
- If the user has already provided enough information,
  say READY.
- If important information is missing, say ASK.
- If asking, ask only the minimum necessary questions.
- Do not ask for information that is already present.

Respond in exactly this format:

STATUS: READY

or

STATUS: ASK
QUESTIONS:
1. ...
2. ...
"""

        decision_response = chat(
            model="qwen2.5-coder:7b",
            messages=[
                {
                    "role": "user",
                    "content": decision_prompt
                }
            ]
        )

        decision = decision_response.message.content.strip()

        if decision.startswith("STATUS: ASK"):

            print("\nShaqs:")
            print(decision)

            print()
            continue

        # --------------------------------
        # ENOUGH INFORMATION — BUILD
        # --------------------------------

        print("\nShaqs: I have enough information. Building your website...")

        # IMPORTANT:
        # Pass the exact user request directly to the website builder.
        # Do not let an intermediate wrapper, old request, or stale state
        # replace the current request.
        website_request = user_message.strip()

        print("\nShaqs: Sending this exact request to the website builder:")
        print(f"       {website_request}")

        output_file = create_website(
            website_request,
            "shaqs_website.html"
        )

        print("\nShaqs: Website created successfully!")
        print(f"Shaqs: {output_file}")

        # create_website normally returns a Path/string path.
        # Convert it safely before opening the browser.
        try:
            output_path = Path(output_file)
            if output_path.exists():
                print("Shaqs: Opening your website...")
                webbrowser.open(output_path.resolve().as_uri())
            else:
                print("Shaqs: Website file was reported as created, but "
                      "the returned path could not be found.")
        except Exception as open_error:
            print(f"Shaqs: Website created, but I could not open it: {open_error}")

    except Exception as e:

        print("\nShaqs: I couldn't create the website.")
        print(f"Error: {e}")

    print()
    continue

    try:

        answer, conversation = run_agent(
            user_message,
            conversation
        )

        print(
            "\nShaqs:",
            answer
        )

        print()

    except Exception as e:

        print(
            "\nShaqs: Something went wrong."
        )

        print(
            f"Error: {e}"
        )

        print()