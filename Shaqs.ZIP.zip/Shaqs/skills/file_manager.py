from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent / "workspace"

BASE_DIR.mkdir(exist_ok=True)


def create_file(filename, content=""):
    file_path = BASE_DIR / filename

    file_path.parent.mkdir(parents=True, exist_ok=True)

    file_path.write_text(content, encoding="utf-8")

    return file_path


def read_file(filename):
    file_path = BASE_DIR / filename

    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {filename}")

    return file_path.read_text(encoding="utf-8")


def create_folder(foldername):
    folder_path = BASE_DIR / foldername

    folder_path.mkdir(parents=True, exist_ok=True)

    return folder_path


def list_files():
    return list(BASE_DIR.rglob("*"))