from pathlib import Path
import re
import webbrowser


BASE_DIR = Path(__file__).resolve().parent.parent
WEBSITES_DIR = BASE_DIR / "websites"


def create_html(content, filename="index.html"):
    """
    Extract HTML from the AI response, save it,
    and open it in the default browser.
    """

    WEBSITES_DIR.mkdir(exist_ok=True)

    # Look for HTML inside a markdown code block
    match = re.search(
        r"```html\s*(.*?)```",
        content,
        re.IGNORECASE | re.DOTALL
    )

    if match:
        html = match.group(1).strip()
    else:
        # If the AI didn't use a code block,
        # try to find the HTML document directly.
        start = content.lower().find("<!doctype html>")

        if start == -1:
            start = content.lower().find("<html")

        if start == -1:
            raise ValueError("No HTML document was found in the AI response.")

        html = content[start:].strip()

        # Remove trailing markdown code fence if present
        html = html.replace("```", "").strip()

    output_file = WEBSITES_DIR / filename

    output_file.write_text(
        html,
        encoding="utf-8"
    )

    webbrowser.open(output_file.resolve().as_uri())

    return output_file