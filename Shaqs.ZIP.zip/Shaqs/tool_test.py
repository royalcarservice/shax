import json
from datetime import datetime

from ollama import chat

from skills.file_manager import (
    create_file,
    create_folder,
    list_files,
    read_file
)


# --------------------------------
# TOOLS
# --------------------------------

def get_time():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# --------------------------------
# TOOL DEFINITIONS
# --------------------------------

tools = [
    {
        "type": "function",
        "function": {
            "name": "get_time",
            "description": "Get the current local computer time.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "create_file",
            "description": "Create a file with the specified filename and content.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string"
                    },
                    "content": {
                        "type": "string"
                    }
                },
                "required": ["filename"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "create_folder",
            "description": "Create a folder.",
            "parameters": {
                "type": "object",
                "properties": {
                    "foldername": {
                        "type": "string"
                    }
                },
                "required": ["foldername"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "List files in the workspace.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read a file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string"
                    }
                },
                "required": ["filename"]
            }
        }
    }
]


# --------------------------------
# TOOL REGISTRY
# --------------------------------

tool_functions = {
    "get_time": get_time,
    "create_file": create_file,
    "create_folder": create_folder,
    "list_files": list_files,
    "read_file": read_file
}


# --------------------------------
# CONVERSATION
# --------------------------------

messages = [
    {
        "role": "system",
        "content": """
You are Shaqs, an AI assistant with access to tools.

When a tool is needed, request it using this exact JSON format:

{"name":"tool_name","arguments":{}}

After a tool result is provided, answer the user's original
question normally.

Do not request another tool unless the user specifically
requires another action.
"""
    },
    {
        "role": "user",
        "content": "What time is it?"
    }
]


# --------------------------------
# FIRST AI CALL
# --------------------------------

response = chat(
    model="qwen2.5-coder:7b",
    messages=messages,
    tools=tools
)

print("\nAI response:")
print(response)


# --------------------------------
# FIND TOOL REQUEST
# --------------------------------

tool_name = None
arguments = {}


# Try official Ollama tool calls first
if response.message.tool_calls:

    tool_call = response.message.tool_calls[0]

    tool_name = tool_call.function.name
    arguments = tool_call.function.arguments

    print("\nDetected official tool call.")


# Otherwise check for JSON returned as normal text
else:

    content = response.message.content.strip()

    try:

        parsed = json.loads(content)

        if "name" in parsed:

            tool_name = parsed["name"]
            arguments = parsed.get("arguments", {})

            print("\nDetected JSON tool request.")

    except json.JSONDecodeError:

        print("\nNo valid tool request detected.")

        print("Raw content:")
        print(content)


# --------------------------------
# EXECUTE TOOL
# --------------------------------

if tool_name:

    print("\nTool requested:")
    print(tool_name)

    print("\nArguments:")
    print(arguments)


    if tool_name not in tool_functions:

        print("\nERROR: Unknown tool:", tool_name)

    else:

        try:

            result = tool_functions[tool_name](**arguments)

            print("\nTool result:")
            print(result)


            # --------------------------------
            # GIVE RESULT BACK TO AI
            # --------------------------------

            messages.append({
                "role": "assistant",
                "content": response.message.content
            })

            messages.append({
                "role": "tool",
                "content": str(result)
            })

            messages.append({
                "role": "user",
                "content": (
                    f"The tool '{tool_name}' has finished.\n"
                    f"Tool result: {result}\n\n"
                    "Now answer my original question using this result. "
                    "Do not request another tool. "
                    "Give me a normal, concise answer."
                )
            })


            # --------------------------------
            # SECOND AI CALL
            # --------------------------------

            final_response = chat(
                model="qwen2.5-coder:7b",
                messages=messages
            )


            print("\nFinal AI response:")
            print(final_response.message.content)


        except Exception as e:

            print("\nTool execution error:")
            print(e)

else:

    print("\nShaqs did not request a tool.")