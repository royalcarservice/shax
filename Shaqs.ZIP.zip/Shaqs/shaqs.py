import sqlite3
import webbrowser

from skills.agent import run_agent
from skills.website_builder import create_html


DB_NAME = "memory.db"


# --------------------------------
# DATABASE
# --------------------------------

def setup_database():

    connection = sqlite3.connect(DB_NAME)

    connection.execute("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            memory TEXT NOT NULL
        )
    """)

    connection.commit()
    connection.close()


def save_memory(memory):

    connection = sqlite3.connect(DB_NAME)

    connection.execute(
        "INSERT INTO memories (memory) VALUES (?)",
        (memory,)
    )

    connection.commit()
    connection.close()


def get_memories():

    connection = sqlite3.connect(DB_NAME)

    rows = connection.execute(
        "SELECT memory FROM memories ORDER BY id"
    ).fetchall()

    connection.close()

    return [row[0] for row in rows]


# --------------------------------
# STARTUP
# --------------------------------

setup_database()

memories = get_memories()


# --------------------------------
# START SYSTEM
# --------------------------------

print("=================================")
print("        SHAQS AI ASSISTANT")
print("=================================")
print("Type 'exit' to close Shaqs.")
print("Type 'remember <something>' to save a memory.")
print("Type 'memories' to view saved memories.")
print()

conversation = []


# --------------------------------
# MAIN LOOP
# --------------------------------

while True:

    user_message = input("You: ").strip()


    # --------------------------------
    # EXIT
    # --------------------------------

    if user_message.lower() == "exit":

        print("Shaqs: Goodbye!")

        break


    # --------------------------------
    # SAVE MEMORY
    # --------------------------------

    if user_message.lower().startswith("remember "):

        memory = user_message[9:].strip()

        if memory:

            save_memory(memory)
            memories.append(memory)

            print("Shaqs: I'll remember that.")

        else:

            print(
                "Shaqs: What would you like me to remember?"
            )

        print()

        continue


    # --------------------------------
    # SHOW MEMORIES
    # --------------------------------

    if user_message.lower() == "memories":

        if memories:

            print("\nShaqs remembers:")

            for i, memory in enumerate(
                memories,
                start=1
            ):

                print(f"{i}. {memory}")

        else:

            print(
                "Shaqs: I don't have any saved memories yet."
            )

        print()

        continue


    # --------------------------------
    # WEBSITE BUILDER
    # --------------------------------

    lower_message = user_message.lower()

    if any(keyword in lower_message for keyword in [
        "create a website",
        "build a website",
        "make a website",
        "design a website",
        "website for"
    ]):

        print(
            "\nShaqs: Creating your website..."
        )

        website_prompt = f"""
You are an expert professional web designer and developer.

Create a complete, beautiful, modern, responsive website based on this request:

{user_message}

IMPORTANT REQUIREMENTS:

1. Return ONLY the complete HTML document.
2. The HTML must start with <!DOCTYPE html>.
3. Include all CSS inside <style> tags.
4. Include all JavaScript inside <script> tags.
5. Make the design professional and visually impressive.
6. Make it fully responsive for phones, tablets, and desktops.
7. DO NOT use local image paths.
8. DO NOT create <img> elements pointing to files that don't exist.
9. Do not use placeholder image filenames.
10. Use CSS, gradients, icons, emoji, or inline SVG instead.
11. Everything must be contained inside the single HTML file.
12. Include smooth hover effects and subtle animations.
13. Include a professional navigation bar.
14. Include a strong hero section.
15. Include a services section.
16. Include an about section.
17. Include a contact section with a working front-end form.
18. Include a footer.
19. Use clean semantic HTML.
20. Do not use Markdown code fences.
21. Do not explain anything outside the HTML.

The final result must work correctly when opened directly as a local HTML file.
"""


        try:

            from ollama import chat

            website_response = chat(
                model="qwen2.5-coder:7b",
                messages=[
                    {
                        "role": "user",
                        "content": website_prompt
                    }
                ]
            )

            website_html = (
                website_response.message.content
            )

            output_file = create_html(
                website_html,
                "shaqs_website.html"
            )

            print(
                "Shaqs: Website created successfully!"
            )

            print(
                f"Shaqs: {output_file}"
            )

            print(
                "Shaqs: Opening your website..."
            )

            webbrowser.open(
                output_file.resolve().as_uri()
            )

        except Exception as e:

            print(
                "Shaqs: I couldn't create the website."
            )

            print(f"Error: {e}")

        print()

        continue


    # --------------------------------
    # AI AGENT
    # --------------------------------

    try:

        answer, conversation = run_agent(
            user_message,
            conversation
        )

        print(
            "\nShaqs:",
            answer
        )

        print()

    except Exception as e:

        print(
            "\nShaqs: Something went wrong."
        )

        print(
            f"Error: {e}"
        )

        print()