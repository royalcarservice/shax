# Shaqs — stable engineering pass

## Changed files
- `main.py` — single clean CLI entry point.
- `skills/agent.py` — rebuilt agent routing/tool loop; website requests are isolated from old website conversations.
- `skills/website_builder.py` — rebuilt website generator with deterministic parsing, seven genuinely different layout families, AI copy as an optional layer, and deterministic HTML validation.
- `skills/file_manager.py` — rebuilt workspace path handling so absolute paths and traversal cannot escape the workspace.
- `tests/test_project.py` — repeatable parser/layout/self-contained-site tests.

## Important architectural change
The agent no longer builds a giant prompt containing assistant instructions and then sends that prompt to the website parser. Only the user messages belonging to the latest website project are sent to the website builder. This prevents internal text such as `IMPORTANT CONTEXT RULE` from becoming a business name.

The website builder owns generation, rendering, validation and saving. The agent owns conversation routing and tools. This removes the previous duplicated website-generation logic in `main.py` and `skills/agent.py`.

## Website layouts
The renderer selects different DOM structures and CSS systems for:
- coffee — editorial
- automotive — industrial
- restaurant — culinary
- salon — luxury
- fitness — athletic
- retail — bento
- professional — structured
- general/creative — modular or portfolio when requested

All generated sites are self-contained local HTML documents with inline CSS, inline SVG/CSS artwork, and vanilla JavaScript.

## Tests run
- Python compilation of all replacement files: PASS
- Parser smoke tests: PASS
- Business-name contamination regression test: PASS
- Seven category/layout rendering tests: PASS
- Self-contained HTML validation: PASS
- JavaScript syntax checks with Node: PASS
- CLI startup/exit test: PASS
- Agent routing test for `do it` after confirmation: PASS
- Workspace path traversal test: PASS

The local execution environment used for this engineering pass did not have the Ollama Python package/server available, so live Qwen generation was not used during testing. The generator is deliberately designed to fall back to deterministic category-specific copy when Ollama is unavailable; your normal Ollama installation remains supported through lazy loading.
