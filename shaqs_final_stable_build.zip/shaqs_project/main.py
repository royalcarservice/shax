from skills.agent import run_agent


def get_user_message():
    first_line = input("You: ")

    if first_line.strip().lower() != "/multi":
        return first_line.strip()

    print("Shaqs: Multiline mode. Type your message.")
    print("Shaqs: Type END on its own line when finished.\n")

    lines = []

    while True:
        line = input()

        if line.strip() == "END":
            break

        lines.append(line)

    return "\n".join(lines).strip()


def main():
    conversation = []

    print("Shaqs is ready.")
    print("Type 'exit' to quit.")
    print("Type '/multi' for multiline input.\n")

    while True:
        user_message = get_user_message()

        if not user_message:
            continue

        if user_message.lower() in {"exit", "quit"}:
            print("Shaqs: Goodbye.")
            break

        try:
            response, conversation = run_agent(
                user_message,
                conversation,
            )

            print(f"Shaqs: {response}\n")

        except Exception as e:
            print(f"Shaqs error: {e}\n")


if __name__ == "__main__":
    main()
