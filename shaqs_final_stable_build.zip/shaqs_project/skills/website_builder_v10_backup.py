"""
Shaqs Website Builder V10
Dynamic industry-aware, self-contained local website generator.

Drop into:
    Shaqs/skills/website_builder.py

Public interface:
    create_html(content, filename="index.html")
    create_website(request)
"""

from __future__ import annotations

import re
import webbrowser
from pathlib import Path
from ollama import chat

MODEL = "qwen2.5-coder:7b"
MAX_REPAIR_ATTEMPTS = 2

BASE_DIR = Path(__file__).resolve().parent.parent
WORKSPACE_DIR = BASE_DIR / "workspace"
WEBSITES_DIR = WORKSPACE_DIR / "websites"
WEBSITES_DIR.mkdir(parents=True, exist_ok=True)


def create_html(content, filename="index.html"):
    filename = Path(str(filename or "index.html")).name
    if not filename.lower().endswith(".html"):
        filename += ".html"
    WEBSITES_DIR.mkdir(parents=True, exist_ok=True)
    output_file = WEBSITES_DIR / filename
    output_file.write_text(str(content), encoding="utf-8")
    return output_file


def clean_markdown_fences(text):
    text = str(text or "").strip()
    text = re.sub(r"^```(?:html|HTML)?\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def extract_html_document(text):
    text = clean_markdown_fences(text)
    pos = text.lower().find("<!doctype html")
    return text[pos:].strip() if pos >= 0 else text.strip()


def validate_basic_html(text):
    low = text.lower()
    required = ["<!doctype html", "<html", "<head", "<body", "</html>"]
    missing = [x for x in required if x not in low]
    if missing:
        return False, "Missing required HTML markers: " + ", ".join(missing)
    return True, ""


def find_forbidden_assets(text):
    low = text.lower()
    violations = []

    for tag in [
        "img", "picture", "source", "iframe", "embed", "object",
        "frame", "frameset", "video", "audio", "track"
    ]:
        if re.search(rf"<\s*{tag}\b", low):
            violations.append(f"<{tag}> is forbidden.")

    for pattern, message in [
        (r"background-image\s*:", "background-image is forbidden."),
        (r"url\s*\(", "CSS url(...) is forbidden."),
        (r"https?://", "external HTTP/HTTPS URL is forbidden."),
        (r"<\s*link\b", "<link> is forbidden."),
        (r"@import\b", "@import is forbidden."),
    ]:
        if re.search(pattern, low):
            violations.append(message)

    for ext in [
        ".jpg", ".jpeg", ".png", ".webp",
        ".gif", ".avif", ".bmp", ".ico"
    ]:
        if ext in low:
            violations.append(f"{ext} asset reference is forbidden.")

    return list(dict.fromkeys(violations))


def validate_website_html(text):
    ok, error = validate_basic_html(text)
    if not ok:
        return ok, error

    violations = find_forbidden_assets(text)

    if violations:
        return False, " ".join(violations)

    return True, ""


# ============================================================
# BUSINESS / CATEGORY UNDERSTANDING
# ============================================================

CATEGORY_RULES = [
    ("coffee", [
        "coffee shop", "cafe", "café", "coffeehouse",
        "coffee house", "espresso", "latte", "cappuccino",
        "bakery cafe", "coffee"
    ]),
    ("automotive", [
        "car garage", "garage", "mechanic", "auto service",
        "car service", "automotive", "vehicle repair",
        "car repair", "workshop", "detailing"
    ]),
    ("restaurant", [
        "restaurant", "diner", "bistro", "eatery",
        "food house", "fine dining"
    ]),
    ("salon", [
        "salon", "barber", "beauty", "hair studio",
        "hair salon", "spa"
    ]),
    ("fitness", [
        "gym", "fitness", "crossfit", "yoga studio",
        "pilates", "workout"
    ]),
    ("retail", [
        "shop", "store", "boutique", "retail",
        "fashion", "clothing"
    ]),
    ("professional", [
        "law firm", "lawyer", "accounting", "accountant",
        "consulting", "agency", "real estate",
        "architect", "clinic", "doctor"
    ]),
]


def detect_category(request: str) -> str:
    text = request.lower()
    scores = {}

    for category, keywords in CATEGORY_RULES:
        scores[category] = sum(
            1 for keyword in keywords
            if keyword in text
        )

    best = max(scores, key=scores.get)

    return best if scores[best] else "general"


# ============================================================
# INDUSTRY DESIGN DNA
# ============================================================

DESIGN_DNA = {
    "coffee": r"""
THIS IS A COFFEE SHOP / CAFE.

Do NOT use the visual language of a garage, mechanic,
corporate service company, or generic SaaS landing page.

COFFEE SHOP DESIGN DNA:

- warm espresso / cream / caramel / cocoa palette
- editorial, cozy, tactile, premium cafe atmosphere
- hero MUST contain a LARGE, unmistakable coffee visual
- create the visual with INLINE SVG and/or CSS
- use a coffee cup, espresso cup, latte cup, coffee beans,
  steam, coffee pour, or a tasteful combination
- the visual must clearly look like coffee at first glance
- use coffee-inspired shapes, bean motifs, cup silhouettes,
  steam lines, roast motifs, menu-board details, or cafe styling
- use section labels appropriate to a cafe:
  MENU, SIGNATURE DRINKS, THE CAFE, OUR COFFEE, VISIT US
- include a visually prominent menu/product area
- include coffee drinks and optional pastries
- prices may be omitted when unknown
- include a cafe atmosphere / experience section
- primary CTA should feel natural for a cafe:
  VIEW MENU, ORDER A COFFEE, VISIT KOPIEEE, FIND US
- DO NOT use phrases such as:
  PROFESSIONAL SERVICE
  CLEAR NEXT STEPS
  SERVICE / DETAIL / PRECISION
  BUILT AROUND THE JOB
  BOOK A SERVICE
- do not use mechanical grids
- do not use dashboard cards
- do not use repair language
- do not use car motifs

FIRST VIEW REQUIREMENT:
A person looking at the first viewport must immediately understand
that this is a coffee shop without reading several paragraphs.
""",

    "automotive": r"""
THIS IS AN AUTOMOTIVE / GARAGE BUSINESS.

Use a premium automotive identity:
deep charcoal/black, warm neutral surfaces,
a restrained strong accent, technical details,
car/mechanical inline SVG motifs, service/repair language,
trust, and booking/contact CTA.

The first viewport must immediately communicate
automotive service.
""",

    "restaurant": r"""
THIS IS A RESTAURANT / FOOD BUSINESS.

Use a culinary identity, not a corporate service template.
Use rich food-inspired colors, menu storytelling,
dish/food inline SVG or CSS visual motifs,
signature dishes, dining experience, and reservation/order CTA.

The first viewport must immediately communicate food/dining.
""",

    "salon": r"""
THIS IS A SALON / BEAUTY BUSINESS.

Use an elegant beauty identity with refined typography,
a sophisticated palette, hair/beauty-inspired inline SVG/CSS
visuals, services, experience, and appointment CTA.

Avoid industrial/service-garage aesthetics.
""",

    "fitness": r"""
THIS IS A FITNESS BUSINESS.

Use an energetic athletic identity, bold typography,
movement-inspired shapes, strong contrast,
training/program sections, benefits, and a clear join/start CTA.

Avoid cafe, automotive, and generic corporate visuals.
""",

    "retail": r"""
THIS IS A RETAIL / SHOP BUSINESS.

Build a product-forward storefront identity:
strong product/category presentation,
editorial commerce layout, shopping CTA,
featured collection area, and visual motifs
appropriate to the products named.

Do not use a generic service-business template.
""",

    "professional": r"""
THIS IS A PROFESSIONAL BUSINESS.

Use a credible, refined identity appropriate to the profession.
Prioritize trust, expertise, clear services, outcomes,
about/team where appropriate, and a contact/consultation CTA.

Avoid irrelevant industrial or cafe motifs.
""",

    "general": r"""
THIS IS A GENERAL BUSINESS.

Infer its actual category from the request and make the
visual identity specific to that category.

Do not fall back to an automotive, coffee, or generic SaaS
template unless the request supports it.
"""
}


# ============================================================
# PROMPT
# ============================================================

def build_website_prompt(request: str) -> str:
    category = detect_category(request)
    dna = DESIGN_DNA[category]

    return f"""
You are Shaqs Web Studio:
a senior product designer, art director, UX designer,
conversion copywriter, and expert front-end engineer.

USER REQUEST:
{request}

DETECTED BUSINESS CATEGORY:
{category}

{dna}

============================================================
CORE RULE
============================================================

The website must be ABOUT THE BUSINESS THE USER REQUESTED.

The business category controls:
- visual language
- content structure
- iconography
- color direction
- hero artwork
- section names
- CTA language

A coffee shop must visibly look like a coffee shop.
An automotive garage must visibly look like an automotive garage.

============================================================
ANTI-TEMPLATE REQUIREMENT
============================================================

Do NOT reuse a generic visual template across unrelated industries.

Before writing HTML, silently decide:

1. business category
2. customer intent
3. visual personality
4. primary conversion action
5. 5-8 most useful sections
6. distinctive hero visual motif

Then implement those decisions.

============================================================
NO QUESTIONNAIRE
============================================================

If the user gives only a business name and category,
DO NOT ask questions.

Make sensible design decisions yourself.

NEVER invent factual:
- addresses
- phone numbers
- prices
- reviews
- awards
- certifications
- years of experience
- statistics
- opening hours
- guarantees

Use generic non-factual copy when information is unknown.

============================================================
VISUAL REQUIREMENT
============================================================

Every website MUST have at least ONE prominent
category-specific visual in the hero.

It must be made directly inside the HTML using:
- inline SVG
- CSS shapes
- gradients
- typography

DO NOT make a generic abstract rectangle and call it a visual.

The hero visual must be recognizable.

Examples:

coffee shop:
coffee cup / espresso cup / latte / beans / steam

automotive:
car / wheel / engine / mechanical motif

restaurant:
plate / dish / food / dining motif

salon:
hair / scissors / beauty motif

fitness:
athletic / movement / training motif

============================================================
TECHNICAL REQUIREMENTS
============================================================

Return ONLY one complete HTML document.

It MUST begin with:
<!DOCTYPE html>

Use:
- semantic HTML5
- CSS inside <style>
- JavaScript inside <script>
- inline SVG
- CSS-created decorative elements
- system fonts only

The website must work when opened directly with file://.

DO NOT use:
- <img>
- <picture>
- <source>
- <iframe>
- <video>
- <audio>
- <object>
- <embed>
- background-image
- url(...)
- external images
- local image files
- .jpg
- .jpeg
- .png
- .webp
- .gif
- .avif
- external SVG files
- external CSS
- <link>
- external JavaScript
- external fonts
- Google Fonts
- icon CDNs
- analytics
- tracking scripts

Inline SVG is allowed.

============================================================
CONTENT
============================================================

Use the exact business name supplied by the user.

Write polished, specific copy based on the business category.

Use category-appropriate section names.

Do NOT force every website to have:
- Services
- Process
- About
- Contact

unless those sections genuinely fit.

For a coffee shop, prefer:
- Hero
- Signature Drinks / Menu
- Cafe Experience
- About
- Visit
- CTA

For a garage, prefer:
- Hero
- Services
- Expertise
- Process
- About
- Contact

============================================================
FUNCTIONALITY
============================================================

Use vanilla JavaScript where useful.

Possible functionality:
- mobile menu
- smooth scrolling
- FAQ accordion
- tabs
- booking UI
- contact validation
- filters
- modal
- scroll reveal
- back-to-top

All interactions must work locally.

Never pretend a form was sent to a real server.

============================================================
RESPONSIVE DESIGN
============================================================

Must work on:
- desktop
- laptop
- tablet
- mobile

Use media queries.

No unwanted horizontal scrolling.

============================================================
QUALITY BAR
============================================================

The result should look like a real professional website.

Use:
- strong visual hierarchy
- excellent spacing
- premium typography
- purposeful whitespace
- beautiful sections
- polished buttons
- subtle shadows
- tasteful gradients
- micro-interactions
- strong CTA placement
- consistent design system

Avoid:
- giant empty hero sections
- repetitive cards everywhere
- childish emoji everywhere
- random green/blue backgrounds
- excessive glassmorphism
- generic SaaS appearance
- automotive styling on non-automotive businesses
- generic service-business copy

============================================================
FINAL CHECK
============================================================

Before returning the HTML, verify:

- valid complete HTML
- CSS included
- JavaScript included where useful
- navigation works
- buttons are styled
- responsive layout
- no <img>
- no <picture>
- no <source>
- no background-image
- no url(...)
- no external URLs
- no external CSS
- no external JavaScript
- no external fonts
- no image file references
- inline SVG is valid
- category-specific hero visual exists
- content matches the requested business
- no unrelated industry language

Return ONLY the HTML document.
No Markdown.
No explanation.
"""


# ============================================================
# REPAIR
# ============================================================

def repair_website_html(html, validation_error, request):
    prompt = f"""
Repair the following Shaqs website.

USER REQUEST:
{request}

VALIDATION ERROR:
{validation_error}

The repaired result MUST preserve the business-specific visual identity.

If this is a coffee shop:
- keep/add a recognizable inline SVG coffee cup,
  espresso cup, latte cup, coffee beans, or steam
- use a cafe palette
- use a menu/product section
- remove automotive/mechanical/service-company language

If this is automotive:
- keep an automotive visual identity.

Return ONLY the complete corrected HTML beginning with <!DOCTYPE html>.

Rules:
- standalone local HTML
- CSS inside <style>
- JS inside <script>
- no <img>
- no <picture>
- no <source>
- no iframe
- no video
- no audio
- no object
- no embed
- no background-image
- no url(...)
- no external URLs
- no external assets
- inline SVG is allowed
- responsive
- polished
"""

    try:
        response = chat(
            model=MODEL,
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ],
        )

        return extract_html_document(
            response.message.content or html
        )

    except Exception:
        return html


# ============================================================
# MAIN WEBSITE GENERATOR
# ============================================================

def create_website(request):
    try:
        category = detect_category(request)

        print("\n" + "=" * 60)
        print("SHAQS WEBSITE BUILDER V10")
        print("=" * 60)
        print(f"Business category: {category}")
        print("Stage 1/4: understanding the business...")
        print("Stage 2/4: applying industry-specific design DNA...")
        print("Stage 3/4: generating the website...")

        response = chat(
            model=MODEL,
            messages=[
                {
                    "role": "user",
                    "content": build_website_prompt(request)
                }
            ],
        )

        website_html = extract_html_document(
            response.message.content or ""
        )

        valid, error = validate_website_html(
            website_html
        )

        attempt = 0

        while (
            not valid
            and attempt < MAX_REPAIR_ATTEMPTS
        ):
            attempt += 1

            print(
                f"Stage 4/4: repairing invalid HTML "
                f"{attempt}/{MAX_REPAIR_ATTEMPTS}..."
            )

            website_html = repair_website_html(
                website_html,
                error,
                request,
            )

            valid, error = validate_website_html(
                website_html
            )

        if not valid:
            return (
                "Website creation failed quality validation: "
                + error
            )

        # --------------------------------------------------------
        # VISUAL QA
        # --------------------------------------------------------
        #
        # This catches the exact failure we just saw:
        # a coffee request producing a garage-looking result.
        #
        if category == "coffee":

            low = website_html.lower()

            coffee_signals = sum(
                x in low
                for x in [
                    "coffee",
                    "café",
                    "cafe",
                    "espresso",
                    "latte",
                    "cappuccino",
                    "beans",
                    "pastry"
                ]
            )

            automotive_signals = sum(
                x in low
                for x in [
                    "automotive",
                    "car service",
                    "mechanic",
                    "brake service",
                    "engine diagnostics",
                    "transmission",
                    "vehicle service"
                ]
            )

            if (
                coffee_signals < 3
                or automotive_signals >= 3
            ):

                print(
                    "[ Visual QA: coffee identity is weak. "
                    "Regenerating with stronger coffee direction... ]"
                )

                stronger_request = (
                    request
                    + "\n\nCRITICAL VISUAL QA FAILURE: "
                    "The previous website looked like an unrelated "
                    "automotive/generic service template. "
                    "This version MUST be unmistakably coffee-themed. "
                    "Use a large inline SVG coffee cup/espresso cup "
                    "with steam or beans in the hero, a cafe palette, "
                    "and a menu/signature-drinks section. "
                    "Do NOT use automotive dashboard styling."
                )

                response = chat(
                    model=MODEL,
                    messages=[
                        {
                            "role": "user",
                            "content": build_website_prompt(
                                stronger_request
                            )
                        }
                    ],
                )

                website_html = extract_html_document(
                    response.message.content
                    or website_html
                )

                valid, error = validate_website_html(
                    website_html
                )

        if not valid:
            return (
                "Website creation failed quality validation: "
                + error
            )

        # --------------------------------------------------------
        # SAVE
        # --------------------------------------------------------

        output_file = create_html(
            website_html,
            "shaqs_website.html",
        )

        # --------------------------------------------------------
        # OPEN
        # --------------------------------------------------------

        try:
            webbrowser.open(
                output_file.resolve().as_uri()
            )
        except Exception as e:
            print(
                f"[ Browser could not be opened: {e} ]"
            )

        print("=" * 60)
        print("WEBSITE CREATED SUCCESSFULLY")
        print(f"File: {output_file}")
        print("=" * 60)

        return (
            "Website created successfully at: "
            f"{output_file}"
        )

    except Exception as e:
        return (
            f"Website creation failed: {e}"
        )
