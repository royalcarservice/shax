from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
AGENT = ROOT / 'skills' / 'agent.py'
BACKUP = ROOT / 'skills' / 'agent_backup_before_tools.py'

if not AGENT.exists():
    raise SystemExit(f'Could not find {AGENT}')

text = AGENT.read_text(encoding='utf-8')
if 'def edit_file(' in text and 'def save_memory(' in text and 'def search_files(' in text:
    print('The extra tools already appear to be installed. Nothing changed.')
    raise SystemExit(0)

shutil.copy2(AGENT, BACKUP)

functions = r'''

# ============================================================
# EXTRA TOOL LAYER
# ============================================================

def _workspace_root():
    return Path(__file__).resolve().parent.parent


def _safe_workspace_path(name):
    root = _workspace_root().resolve()
    candidate = (root / str(name)).resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        raise ValueError("Path must stay inside the Shaqs workspace.")
    return candidate


def edit_file(filename, content):
    """Replace the contents of an existing workspace file."""
    path = _safe_workspace_path(filename)
    if not path.exists():
        return f"File not found: {path}"
    if not path.is_file():
        return f"Not a file: {path}"
    path.write_text(str(content), encoding="utf-8")
    return f"File updated: {path}"


def search_files(query, path="."):
    """Search text inside workspace files."""
    query = str(query).strip()
    if not query:
        return "Search query was empty."

    root = _safe_workspace_path(path)
    if not root.exists():
        return f"Path does not exist: {root}"

    matches = []
    ignored = {".venv", "__pycache__", ".git"}

    for file in root.rglob("*"):
        if not file.is_file() or any(part in ignored for part in file.parts):
            continue
        if file.name == "memory.db":
            continue
        try:
            text = file.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        if query.lower() in text.lower():
            hits = []
            for number, line in enumerate(text.splitlines(), 1):
                if query.lower() in line.lower():
                    hits.append(f"{number}: {line.strip()[:180]}")
                    if len(hits) >= 5:
                        break
            matches.append(f"{file.relative_to(_workspace_root())}\n  " + "\n  ".join(hits))

    return "\n".join(matches) if matches else f'No files containing "{query}" were found.'


def delete_path(path):
    """Delete a workspace file or folder, while protecting the workspace root and memory DB."""
    import shutil
    target = _safe_workspace_path(path)
    root = _workspace_root().resolve()
    if target == root:
        return "Refused to delete the entire Shaqs workspace."
    if target == (root / "memory.db").resolve():
        return "Refused to delete the memory database."
    if not target.exists():
        return f"Path not found: {target}"
    if target.is_dir():
        shutil.rmtree(target)
        return f"Folder deleted: {target}"
    target.unlink()
    return f"File deleted: {target}"


def _ensure_memory_table():
    connection = sqlite3.connect(DB_NAME)
    connection.execute(
        "CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY AUTOINCREMENT, memory TEXT NOT NULL)"
    )
    connection.commit()
    connection.close()


def save_memory(memory):
    """Save a long-term memory."""
    memory = str(memory).strip()
    if not memory:
        return "Memory was empty; nothing was saved."
    _ensure_memory_table()
    connection = sqlite3.connect(DB_NAME)
    connection.execute("INSERT INTO memories (memory) VALUES (?)", (memory,))
    connection.commit()
    connection.close()
    return f"Memory saved: {memory}"


def forget_memory(memory):
    """Forget memories matching supplied text."""
    memory = str(memory).strip()
    if not memory:
        return "Please provide the memory text to forget."
    _ensure_memory_table()
    connection = sqlite3.connect(DB_NAME)
    cursor = connection.execute(
        "DELETE FROM memories WHERE memory LIKE ?", (f"%{memory}%",)
    )
    deleted = cursor.rowcount
    connection.commit()
    connection.close()
    return f"Forgot {deleted} matching memory/memories." if deleted else "No matching memory was found."
'''

marker = '# ============================================================\n# TOOL DEFINITIONS\n'
if marker not in text:
    raise SystemExit('Could not find the TOOL DEFINITIONS marker in agent.py. No changes made.')
text = text.replace(marker, functions + '\n\n' + marker, 1)

# Add tool definitions without touching the existing list.
tools_insert = r'''

# Additional tools added by the Shaqs Tool Layer.
tools.extend([
    {
        "type": "function",
        "function": {
            "name": "edit_file",
            "description": "Replace the contents of an existing file in the Shaqs workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {"type": "string"},
                    "content": {"type": "string"},
                },
                "required": ["filename", "content"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "search_files",
            "description": "Search for text inside files in the Shaqs workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {"type": "string"},
                    "path": {"type": "string"},
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "delete_path",
            "description": "Delete a file or folder in the Shaqs workspace.",
            "parameters": {
                "type": "object",
                "properties": {"path": {"type": "string"}},
                "required": ["path"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "save_memory",
            "description": "Save useful long-term information about the user or their projects.",
            "parameters": {
                "type": "object",
                "properties": {"memory": {"type": "string"}},
                "required": ["memory"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "forget_memory",
            "description": "Forget saved long-term memories matching supplied text.",
            "parameters": {
                "type": "object",
                "properties": {"memory": {"type": "string"}},
                "required": ["memory"],
            },
        },
    },
])
'''

registry_marker = '# ============================================================\n# TOOL REGISTRY\n'
if registry_marker not in text:
    shutil.copy2(BACKUP, AGENT)
    raise SystemExit('Could not find the TOOL REGISTRY marker. Restored backup; no changes made.')
text = text.replace(registry_marker, tools_insert + '\n\n' + registry_marker, 1)

registry_end_marker = '# ============================================================\n# TOOL REQUEST PARSER\n'
registry_update = r'''

# Register the additional tools.
tool_functions.update({
    "edit_file": edit_file,
    "search_files": search_files,
    "delete_path": delete_path,
    "save_memory": save_memory,
    "forget_memory": forget_memory,
})
'''
if registry_end_marker not in text:
    shutil.copy2(BACKUP, AGENT)
    raise SystemExit('Could not find the TOOL REQUEST PARSER marker. Restored backup; no changes made.')
text = text.replace(registry_end_marker, registry_update + '\n\n' + registry_end_marker, 1)

# Tell Shaqs about the new tools.
prompt_marker = 'AVAILABLE TOOLS:'
if prompt_marker in text and 'search_files' not in text[text.find(prompt_marker):text.find(prompt_marker)+1000]:
    replacement = '''AVAILABLE TOOLS:\n\n- get_time\n- create_file\n- create_folder\n- list_files\n- read_file\n- edit_file\n- search_files\n- delete_path\n- save_memory\n- forget_memory\n- create_website'''
    start = text.find(prompt_marker)
    # Replace the whole simple AVAILABLE TOOLS block through create_website.
    end_token = 'create_website'
    end = text.find(end_token, start)
    if end != -1:
        end += len(end_token)
        text = text[:start] + replacement + text[end:]

AGENT.write_text(text, encoding='utf-8')
print(f'Backup created: {BACKUP}')
print(f'Upgraded: {AGENT}')
