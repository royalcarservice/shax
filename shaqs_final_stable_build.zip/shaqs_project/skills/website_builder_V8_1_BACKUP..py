
"""
Shaqs Website Builder — V8.1 Studio Edition

A deterministic, business-aware premium single-file website builder for Shaqs.
The local Ollama model creates a compact content/design plan; Python renders
the final HTML from a strong production-grade template. This prevents the
small local model from accidentally producing weak layouts, broken images,
giant placeholders, or generic pages.

Compatible with:
    from skills.website_builder import create_html
    from skills.website_builder import create_website
    from skills.website_builder import build_website
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import quote

import ollama


# ============================================================
# CONFIG
# ============================================================

MODEL = os.getenv("SHAQS_WEBSITE_MODEL", "qwen2.5-coder:7b")
TEMPERATURE = float(os.getenv("SHAQS_WEBSITE_TEMPERATURE", "0.25"))

BASE_DIR = Path(__file__).resolve().parent.parent
WORKSPACE_DIR = BASE_DIR / "workspace"
WEBSITES_DIR = WORKSPACE_DIR / "websites"

WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)
WEBSITES_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
# CONTENT PLANNER
# ============================================================

PLANNER_SYSTEM_PROMPT = r"""
You are the content strategist for Shaqs Web Studio.

Your job is NOT to write HTML. You create a compact JSON content plan that
will be rendered by a deterministic professional website template.

RULES:
- Never ask questions.
- Infer sensible structure from the user's request.
- If the request names a business, use that exact business name.
- Never return generic placeholder business copy when the request clearly identifies the business.
- Preserve facts supplied by the user.
- NEVER invent phone numbers, WhatsApp numbers, addresses, prices, reviews,
  ratings, awards, certifications, opening hours, years, statistics,
  guarantees, or customer quotes.
- If a fact is not supplied, return an empty string/list rather than guessing.
- Do not add a blog unless explicitly requested.
- Do not use fake testimonials.
- Keep copy concise, natural and specific.
- Avoid generic phrases such as "one-stop solution", "experience the
  difference", "best-in-class", "unmatched quality", "committed to excellence".
- For local service businesses, prioritize conversion: call, message, book,
  directions, or request a quote depending on what is actually supported.
- The final site will be a single local HTML file with no external assets.

Return ONLY valid JSON matching this schema:

{
  "business_name": "",
  "business_type": "",
  "eyebrow": "",
  "headline": "",
  "subheadline": "",
  "primary_cta": "",
  "secondary_cta": "",
  "services": [
    {"name":"","description":"","icon":"wrench"}
  ],
  "reasons": [
    {"title":"","description":"","icon":"check"}
  ],
  "about_title": "",
  "about_text": "",
  "process": [
    {"step":"01","title":"","description":""}
  ],
  "faq": [
    {"question":"","answer":""}
  ],
  "phone": "",
  "whatsapp": "",
  "email": "",
  "address": "",
  "hours": "",
  "directions_url": "",
  "review_summary": "",
  "accent": "amber",
  "business_facts": []
}

ICON VALUES should be one of:
wrench, engine, brake, oil, tire, ac, bolt, scan, gear, car, shield,
check, clock, location, phone, message, star, tool, spark.

For unknown contact fields return "".
For unknown review_summary return "".
For accent choose one of: amber, red, blue, green, violet, cyan.
Choose based on the business personality, not the business name.
"""

FALLBACK_PLAN: Dict[str, Any] = {
    "business_name": "Your Business",
    "business_type": "Local service business",
    "eyebrow": "Professional service",
    "headline": "Professional service. Clear next steps.",
    "subheadline": "A polished, customer-focused experience designed to make it easy to understand what you offer and get in touch.",
    "primary_cta": "Get Started",
    "secondary_cta": "Explore Services",
    "services": [
        {"name": "Professional Service", "description": "Practical help tailored to what you need.", "icon": "wrench"},
        {"name": "Reliable Support", "description": "A straightforward service experience from start to finish.", "icon": "shield"},
        {"name": "Clear Communication", "description": "Know what is happening before the work moves forward.", "icon": "message"},
    ],
    "reasons": [
        {"title": "Straightforward", "description": "Clear information without unnecessary complexity.", "icon": "check"},
        {"title": "Customer focused", "description": "Designed around the visitor's next useful step.", "icon": "star"},
        {"title": "Professional", "description": "A polished service experience from first contact onward.", "icon": "shield"},
    ],
    "about_title": "A better service experience",
    "about_text": "A professional local business focused on useful service, clear communication, and dependable customer care.",
    "process": [
        {"step": "01", "title": "Tell us what you need", "description": "Share the service or problem you want help with."},
        {"step": "02", "title": "Get clear guidance", "description": "Discuss the right next step for your request."},
        {"step": "03", "title": "Move forward", "description": "Book, call, or contact the business when you are ready."},
    ],
    "faq": [],
    "phone": "",
    "whatsapp": "",
    "email": "",
    "address": "",
    "hours": "",
    "directions_url": "",
    "review_summary": "",
    "accent": "amber",
    "business_facts": [],
}


# ============================================================
# MODEL HELPERS
# ============================================================

def _ollama_text(response: Any) -> str:
    try:
        return str(response["message"]["content"])
    except Exception:
        pass
    try:
        return str(response.message.content)
    except Exception as exc:
        raise RuntimeError(f"Could not read Ollama response: {exc}") from exc


def _chat(system: str, user: str, temperature: Optional[float] = None) -> str:
    response = ollama.chat(
        model=MODEL,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        options={
            "temperature": TEMPERATURE if temperature is None else temperature,
        },
    )
    return _ollama_text(response)


def _extract_json(text: str) -> Dict[str, Any]:
    text = str(text or "").strip()
    text = re.sub(r"^\s*```(?:json)?\s*", "", text, flags=re.I)
    text = re.sub(r"\s*```\s*$", "", text)

    # Prefer the largest object-looking region.
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end <= start:
        raise ValueError("No JSON object found.")
    raw = text[start:end + 1]
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise ValueError("Planner response was not a JSON object.")
    return data


def _merge_plan(data: Dict[str, Any]) -> Dict[str, Any]:
    plan = dict(FALLBACK_PLAN)

    for key, fallback in FALLBACK_PLAN.items():
        value = data.get(key)
        if isinstance(fallback, list):
            plan[key] = value if isinstance(value, list) else list(fallback)
        elif isinstance(fallback, dict):
            plan[key] = value if isinstance(value, dict) else dict(fallback)
        else:
            plan[key] = value if isinstance(value, str) else fallback

    # Never allow empty business name after planning.
    if not plan["business_name"].strip():
        plan["business_name"] = "Business"

    # Sanitize list objects.
    for key in ("services", "reasons", "process", "faq"):
        cleaned = []
        for item in plan.get(key, []):
            if isinstance(item, dict):
                cleaned.append({str(k): str(v) for k, v in item.items()})
        plan[key] = cleaned

    if plan["accent"] not in {"amber", "red", "blue", "green", "violet", "cyan"}:
        plan["accent"] = "amber"

    return plan



# ============================================================
# REQUEST-AWARE ENRICHMENT
# ============================================================

AUTO_SERVICE_PRESET = [
    {"name": "Car Servicing & Maintenance", "description": "Routine servicing and preventative maintenance to keep vehicles running reliably.", "icon": "wrench"},
    {"name": "Engine Diagnostics & Repair", "description": "Systematic diagnosis and repair for engine-related problems.", "icon": "engine"},
    {"name": "Brake & Suspension Service", "description": "Inspection and repair work focused on braking, handling and ride quality.", "icon": "brake"},
    {"name": "AC & Electrical Service", "description": "Vehicle AC, electrical and related fault-finding work.", "icon": "ac"},
    {"name": "Transmission & Gear Work", "description": "Transmission-related inspection, repair and specialist work.", "icon": "gear"},
    {"name": "Multi-Brand Vehicle Service", "description": "Service and repair support for vehicles across multiple brands.", "icon": "car"},
    {"name": "Manual-to-Automatic Conversion", "description": "Specialized conversion work for vehicles requiring a manual-to-automatic setup.", "icon": "tool"},
    {"name": "Oil, Tyre & Routine Care", "description": "Essential maintenance including oil changes, tyre care and routine checks.", "icon": "oil"},
    {"name": "Vehicle Diagnostics", "description": "Diagnostic checks to identify faults before repair work begins.", "icon": "scan"},
    {"name": "Interior & Exterior Detailing", "description": "Cleaning and detailing work for a cleaner, better-presented vehicle.", "icon": "spark"},
]

AUTO_REASONS = [
    {"title": "Multi-brand expertise", "description": "Built around servicing and repairing vehicles from different brands.", "icon": "car"},
    {"title": "Practical diagnosis", "description": "Understand the problem first, then decide the right repair or service.", "icon": "scan"},
    {"title": "Specialized automotive work", "description": "Support for routine maintenance as well as more involved mechanical work.", "icon": "tool"},
    {"title": "Clear customer communication", "description": "A straightforward path from enquiry to inspection, service and final check.", "icon": "message"},
]

AUTO_PROCESS = [
    {"step": "01", "title": "Tell us what your car needs", "description": "Share the vehicle, service requirement or problem you want checked."},
    {"step": "02", "title": "Inspection & diagnosis", "description": "The vehicle is assessed so the required work can be understood clearly."},
    {"step": "03", "title": "Service or repair", "description": "The agreed maintenance or repair work is carried out with attention to detail."},
    {"step": "04", "title": "Final check", "description": "The vehicle is checked before it is ready for collection or the next step."},
]


def _extract_business_name(request: str) -> str:
    text = str(request or "").strip()
    patterns = [
        r"(?:build|create|make|design)\s+(?:a\s+)?(?:website|site)\s+(?:for|of)\s+(.+?)(?:[.!?\\n]|$)",
        r"(?:website|site)\s+(?:for|of)\s+(.+?)(?:[.!?\\n]|$)",
    ]
    for pattern in patterns:
        m = re.search(pattern, text, flags=re.I)
        if m:
            candidate = m.group(1).strip(" \"'")
            candidate = re.sub(r"\\s+", " ", candidate)
            if candidate and len(candidate) <= 100:
                return candidate
    return ""


def _looks_automotive(text: str, plan: Dict[str, Any]) -> bool:
    hay = (str(text or "") + " " + str(plan.get("business_name", "")) + " " + str(plan.get("business_type", ""))).lower()
    terms = ("car", "auto", "automotive", "garage", "vehicle", "mechanic", "service center", "service centre", "engine", "transmission", "tyre", "tire", "brake")
    return any(term in hay for term in terms)


def _enrich_plan(plan: Dict[str, Any], user_request: str) -> Dict[str, Any]:
    """Turn sparse/generic model output into business-specific content without inventing contact facts."""
    plan = _merge_plan(plan)
    extracted_name = _extract_business_name(user_request)
    if extracted_name:
        plan["business_name"] = extracted_name

    automotive = _looks_automotive(user_request, plan)
    if automotive:
        # Never let a generic planner response erase a clearly automotive request.
        if not plan.get("business_type") or plan["business_type"].lower() in {"local business", "local service business", "professional service"}:
            plan["business_type"] = "Automotive service & repair"

        generic_names = {"business", "your business", "professional service"}
        if not plan.get("headline") or plan["headline"].strip().lower() in {"built around the work that matters.", "professional service. clear next steps."}:
            plan["headline"] = "Expert car service & repairs, built around your vehicle."
        if not plan.get("subheadline") or "thoughtful workmanship" in plan["subheadline"].lower() or "customer-focused" in plan["subheadline"].lower():
            plan["subheadline"] = "From routine servicing and diagnostics to complex repair work, get a clearer path to keeping your car on the road."
        if not plan.get("eyebrow") or plan["eyebrow"].lower() == "professional service":
            plan["eyebrow"] = "AUTOMOTIVE SERVICE & REPAIR"
        if not plan.get("primary_cta") or plan["primary_cta"].lower() == "get started":
            plan["primary_cta"] = "Book a Service"
        if not plan.get("secondary_cta") or plan["secondary_cta"].lower() == "explore services":
            plan["secondary_cta"] = "View Services"

        current_services = [x for x in plan.get("services", []) if str(x.get("name", "")).strip()]
        names = " ".join(str(x.get("name", "")) for x in current_services).lower()
        if len(current_services) < 5 or not any(k in names for k in ("engine", "brake", "diagnostic", "service")):
            # Prefer explicit service phrases found in the user's request; otherwise use the curated automotive preset.
            explicit = []
            for item in AUTO_SERVICE_PRESET:
                if item["name"].lower() in user_request.lower():
                    explicit.append(item)
            plan["services"] = explicit if len(explicit) >= 3 else AUTO_SERVICE_PRESET

        plan["reasons"] = AUTO_REASONS
        plan["process"] = AUTO_PROCESS
        plan["about_title"] = "Automotive knowledge that goes beyond routine servicing"
        plan["about_text"] = (
            f"{plan['business_name']} is positioned as a practical automotive service and repair business, "
            "helping vehicle owners understand what their car needs and move from diagnosis to the right service or repair."
        )
        plan["business_facts"] = ["Multi-brand servicing", "Diagnostics & repairs", "Routine maintenance", "Specialized automotive work"]
        plan["accent"] = "amber"

    return _merge_plan(plan)

def _make_plan(user_request: str) -> Dict[str, Any]:
    # The model is optional: the deterministic enrichment layer guarantees that
    # a simple request such as "Build a website for Royal Car Service Center"
    # still becomes a specific, useful website rather than a generic template.
    try:
        response = _chat(
            PLANNER_SYSTEM_PROMPT,
            "Create the website content plan from this request. Do not ask questions.\n\n" + user_request,
            temperature=0.15,
        )
        raw_plan = _extract_json(response)
    except Exception:
        raw_plan = {}
    return _enrich_plan(raw_plan, user_request)


# ============================================================
# HTML HELPERS
# ============================================================

def _clean_filename(filename: str) -> str:
    filename = str(filename or "shaqs_website.html").strip()
    filename = Path(filename).name
    filename = re.sub(r"[^a-zA-Z0-9._-]", "_", filename)
    if not filename.lower().endswith(".html"):
        filename += ".html"
    return filename


def _esc(value: Any) -> str:
    return (
        str(value or "")
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


def _slug(value: str) -> str:
    value = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return value or "service"


def _tel_href(phone: str) -> str:
    raw = re.sub(r"[^0-9+]", "", phone or "")
    return "tel:" + raw if raw else ""


def _whatsapp_href(number: str) -> str:
    raw = re.sub(r"\D", "", number or "")
    if not raw:
        return ""
    return "https://wa.me/" + raw


ICON_SVGS = {
    "wrench": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14.7 6.3a4.1 4.1 0 0 0-5.4 5.4L3.8 17.2a2 2 0 1 0 2.9 2.9l5.5-5.5a4.1 4.1 0 0 0 5.4-5.4l-2.2 2.2-2.4-.4-.4-2.4 2.1-2.3Z"/></svg>',
    "engine": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9h3l2-3h5l2 3h3l2 3v6h-5v-3H8v3H3v-6l1-3Zm5 1h6v3H9v-3Z"/></svg>',
    "brake": '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="M12 4v5m8 3h-5m-3 8v-5m-8-3h5"/></svg>',
    "oil": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 5h8v12H7z"/><path d="M9 3h5m-2 14v4m-6 0h12"/><path d="M17 8h3l1 2v6h-4"/></svg>',
    "tire": '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3"/><path d="m7 7 2 2m8 8-2-2m0-8 2-2M9 15l-2 2"/></svg>',
    "ac": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v18M4 7l16 10M20 7 4 17"/><circle cx="12" cy="12" r="2"/></svg>',
    "bolt": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m13 2-8 12h6l-1 8 9-13h-6l0-7Z"/></svg>',
    "scan": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 8V5h3M16 5h3v3M19 16v3h-3M7 19H4v-3"/><circle cx="12" cy="12" r="4"/></svg>',
    "gear": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 2 2 3-.2.8 2.9 2.6 1.6-1.6 2.6.2 3-3 .8-2.9-1.6-2.6 1.6-2.6-1.6-2.9.8-3 2.9-.8 1.6-2.6-1.6-2.6 1.6-3-.2-2.9 3 .8 2.9 1.6 2.6-1.6 2.6 1.6 2.9-.8 3 2.9.8 1.6 2.6-1.6 2.6 1.6 3 .2-2.9 2.9-.8-1.6-2.6 1.6-2.6-1.6-3-2.9.8-2.9-3-2.6-1.6-2.6 1.6-2.9-.8-3-3 .2-2.9-2-2 2-2Z"/><circle cx="12" cy="12" r="3"/></svg>',
    "car": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 16-1-5 2-5h10l3 5 1 5H5Z"/><path d="M7 11h10M7 16v2m10-2v2"/><circle cx="8" cy="16" r="1.5"/><circle cx="16" cy="16" r="1.5"/></svg>',
    "shield": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 20 6v5c0 5-3.4 8.3-8 10-4.6-1.7-8-5-8-10V6l8-3Z"/><path d="m8.5 12 2.2 2.2 4.8-5"/></svg>',
    "check": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>',
    "clock": '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/></svg>',
    "location": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M19 10c0 5-7 10-7 10S5 15 5 10a7 7 0 1 1 14 0Z"/><circle cx="12" cy="10" r="2"/></svg>',
    "phone": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4h3l1.2 4-2 1.5a14 14 0 0 0 5.3 5.3l1.5-2 4 1.2v3c0 1.1-.9 2-2 2C10.3 19 5 13.7 5 7c0-1.7.9-3 2-3Z"/></svg>',
    "message": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v11H9l-5 4V5Z"/><path d="M8 9h8M8 12h5"/></svg>',
    "star": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z"/></svg>',
    "tool": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 5a5 5 0 0 0 5 7l-7 7a2 2 0 1 1-2-2l7-7a5 5 0 0 0-3-5l2 2-2 2-3-3 3-2Z"/></svg>',
    "spark": '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m12 2 1.5 6.5L20 10l-6.5 1.5L12 18l-1.5-6.5L4 10l6.5-1.5L12 2Zm7 14 .7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7L19 16Z"/></svg>',
}


def _icon(name: str) -> str:
    return ICON_SVGS.get(name, ICON_SVGS["spark"])


# ============================================================
# DETERMINISTIC PREMIUM TEMPLATE
# ============================================================

def _render_html(plan: Dict[str, Any]) -> str:
    business = _esc(plan["business_name"])
    business_type = _esc(plan["business_type"])
    eyebrow = _esc(plan["eyebrow"])
    headline = _esc(plan["headline"])
    subheadline = _esc(plan["subheadline"])
    primary_cta = _esc(plan["primary_cta"])
    secondary_cta = _esc(plan["secondary_cta"])

    accent = plan["accent"]
    accent_values = {
        "amber": ("#f4b740", "#ffcf68"),
        "red": ("#ef5b5b", "#ff8585"),
        "blue": ("#55a8ff", "#8bc8ff"),
        "green": ("#54d17b", "#8ee7a7"),
        "violet": ("#a985ff", "#c4adff"),
        "cyan": ("#42d5d0", "#8ae9e5"),
    }
    accent1, accent2 = accent_values.get(accent, accent_values["amber"])

    services_html = []
    for idx, service in enumerate(plan["services"][:12], 1):
        name = _esc(service.get("name", "Service"))
        desc = _esc(service.get("description", "Professional service tailored to your needs."))
        icon = _icon(service.get("icon", "wrench"))
        services_html.append(
            f"""
            <article class="service-card reveal">
              <div class="service-top">
                <span class="icon-box">{icon}</span>
                <span class="service-index">0{idx if idx < 10 else idx}</span>
              </div>
              <h3>{name}</h3>
              <p>{desc}</p>
              <span class="service-arrow" aria-hidden="true">↗</span>
            </article>
            """
        )

    reasons_html = []
    for reason in plan["reasons"][:6]:
        title = _esc(reason.get("title", "Professional"))
        desc = _esc(reason.get("description", "A thoughtful, customer-focused service experience."))
        icon = _icon(reason.get("icon", "check"))
        reasons_html.append(
            f"""
            <article class="reason reveal">
              <span class="reason-icon">{icon}</span>
              <div><h3>{title}</h3><p>{desc}</p></div>
            </article>
            """
        )

    process_html = []
    for item in plan["process"][:5]:
        step = _esc(item.get("step", "01"))
        title = _esc(item.get("title", "Next step"))
        desc = _esc(item.get("description", "A clear step toward getting the help you need."))
        process_html.append(
            f"""
            <article class="process-item reveal">
              <span class="step-number">{step}</span>
              <div><h3>{title}</h3><p>{desc}</p></div>
            </article>
            """
        )

    faq_html = []
    for item in plan["faq"][:8]:
        q = _esc(item.get("question", "How does it work?"))
        a = _esc(item.get("answer", "Contact the business to discuss your requirements."))
        faq_html.append(
            f"""
            <details class="faq-item reveal">
              <summary>{q}<span>+</span></summary>
              <p>{a}</p>
            </details>
            """
        )

    tel = _tel_href(plan["phone"])
    wa = _whatsapp_href(plan["whatsapp"])
    email = str(plan["email"] or "").strip()
    address = _esc(plan["address"])
    hours = _esc(plan["hours"])
    directions = str(plan["directions_url"] or "").strip()

    contact_cards = []
    if tel:
        contact_cards.append(
            f'<a class="contact-card reveal" href="{_esc(tel)}"><span class="contact-icon">{_icon("phone")}</span><span><small>Call</small><strong>{_esc(plan["phone"])}</strong></span></a>'
        )
    if wa:
        contact_cards.append(
            f'<a class="contact-card reveal" href="{_esc(wa)}" target="_blank" rel="noopener"><span class="contact-icon">{_icon("message")}</span><span><small>WhatsApp</small><strong>Message the garage</strong></span></a>'
        )
    if email:
        contact_cards.append(
            f'<a class="contact-card reveal" href="mailto:{_esc(email)}"><span class="contact-icon">{_icon("message")}</span><span><small>Email</small><strong>{_esc(email)}</strong></span></a>'
        )
    if address:
        contact_cards.append(
            f'<div class="contact-card reveal"><span class="contact-icon">{_icon("location")}</span><span><small>Location</small><strong>{address}</strong></span></div>'
        )
    if hours:
        contact_cards.append(
            f'<div class="contact-card reveal"><span class="contact-icon">{_icon("clock")}</span><span><small>Hours</small><strong>{hours}</strong></span></div>'
        )

    # Only show directions if the user actually supplied a URL.
    directions_button = ""
    if directions:
        directions_button = f'<a class="btn btn-ghost" href="{_esc(directions)}" target="_blank" rel="noopener">{_esc("Get Directions")} <span>↗</span></a>'

    hero_primary_href = "#booking"
    if tel:
        hero_primary_href = _esc(tel)
    elif wa:
        hero_primary_href = _esc(wa)

    about_text = _esc(plan["about_text"])
    review_summary = _esc(plan["review_summary"])

    trust_extra = ""
    if review_summary:
        trust_extra = f'<span><strong>Customer feedback</strong>{review_summary}</span>'

    faq_section = ""
    if faq_html:
        faq_section = f"""
        <section class="section section-muted" id="faq">
          <div class="container narrow-head">
            <div class="section-kicker">Answers</div>
            <h2>Questions, answered.</h2>
            <p>Useful information before you get started.</p>
          </div>
          <div class="container faq-grid">
            {''.join(faq_html)}
          </div>
        </section>
        """

    contact_html = ''.join(contact_cards) if contact_cards else """
      <div class="contact-card reveal">
        <span class="contact-icon">✦</span>
        <span><small>Ready when you are</small><strong>Use the request form to start a conversation.</strong></span>
      </div>
    """

    facts = [str(x).strip() for x in plan.get("business_facts", []) if str(x).strip()]
    fact_chips = ''.join(f'<span class="fact-chip">{_esc(x)}</span>' for x in facts[:6])
    if not fact_chips:
        fact_chips = '<span class="fact-chip">Professional service</span><span class="fact-chip">Clear communication</span>'

    service_count = len(plan["services"])
    service_label = "service" if service_count == 1 else "services"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="theme-color" content="#0b0d10">
<title>{business} — {business_type}</title>
<style>
:root {{
  --bg: #080a0d;
  --bg-soft: #0e1115;
  --surface: #14181e;
  --surface-2: #191e25;
  --line: rgba(255,255,255,.10);
  --text: #f4f6f8;
  --muted: #aab1bb;
  --accent: {accent1};
  --accent-2: {accent2};
  --max: 1180px;
  --radius: 18px;
  --shadow: 0 22px 70px rgba(0,0,0,.34);
}}
* {{ box-sizing: border-box; }}
html {{ scroll-behavior: smooth; }}
body {{
  margin: 0;
  background: var(--bg);
  color: var(--text);
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  line-height: 1.6;
  overflow-x: hidden;
}}
body::before {{
  content: "";
  position: fixed;
  inset: 0;
  pointer-events: none;
  opacity: .18;
  background-image:
    linear-gradient(rgba(255,255,255,.035) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,.035) 1px, transparent 1px);
  background-size: 48px 48px;
  mask-image: linear-gradient(to bottom, black, transparent 75%);
}}
a {{ color: inherit; text-decoration: none; }}
button, input, select, textarea {{ font: inherit; }}
.container {{ width: min(var(--max), calc(100% - 40px)); margin-inline: auto; }}
.narrow-head {{ max-width: 760px; }}
.section {{ padding: 108px 0; position: relative; }}
.section-muted {{ background: var(--bg-soft); border-block: 1px solid var(--line); }}
.section-kicker {{
  color: var(--accent);
  font-size: .78rem;
  font-weight: 800;
  letter-spacing: .16em;
  text-transform: uppercase;
  margin-bottom: 12px;
}}
h1, h2, h3, p {{ margin-top: 0; }}
h1 {{
  font-size: clamp(3.2rem, 7vw, 6.8rem);
  line-height: .94;
  letter-spacing: -.055em;
  max-width: 850px;
  margin-bottom: 28px;
}}
h2 {{
  font-size: clamp(2.2rem, 4.5vw, 4.2rem);
  line-height: 1;
  letter-spacing: -.045em;
  margin-bottom: 18px;
}}
h3 {{ line-height: 1.15; }}
.lead {{ color: var(--muted); font-size: clamp(1rem, 1.5vw, 1.18rem); max-width: 670px; }}
.btn {{
  display: inline-flex; align-items: center; justify-content: center; gap: 10px;
  min-height: 52px; padding: 0 20px; border-radius: 12px;
  border: 1px solid transparent; font-weight: 800; transition: transform .2s ease, background .2s ease, border-color .2s ease;
  cursor: pointer;
}}
.btn:hover {{ transform: translateY(-2px); }}
.btn-primary {{ background: var(--accent); color: #0a0b0d; box-shadow: 0 12px 35px rgba(244,183,64,.16); }}
.btn-primary:hover {{ background: var(--accent-2); }}
.btn-ghost {{ border-color: var(--line); background: rgba(255,255,255,.035); }}
.btn-ghost:hover {{ background: rgba(255,255,255,.08); }}
.btn:focus-visible, a:focus-visible, summary:focus-visible, input:focus-visible, textarea:focus-visible, select:focus-visible {{ outline: 2px solid var(--accent); outline-offset: 3px; }}

.site-header {{
  position: sticky; top: 0; z-index: 50;
  background: rgba(8,10,13,.78); backdrop-filter: blur(18px);
  border-bottom: 1px solid var(--line);
}}
.nav {{
  min-height: 74px;
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);
  align-items: center;
  gap: 24px;
}}
.brand {{
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
  justify-self: start;
}}
.brand-mark {{
  width: 38px; height: 38px; border-radius: 10px; display: grid; place-items: center;
  background: var(--accent); color: #080a0d; font-weight: 950; flex: 0 0 auto;
}}
.brand-name {{
  font-weight: 900;
  letter-spacing: -.02em;
  white-space: nowrap;
  overflow: visible;
  text-overflow: clip;
  max-width: none;
}}
.nav-links {{
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 28px;
  color: #cbd0d7;
  font-size: .94rem;
  justify-self: center;
  white-space: nowrap;
}}
.nav-links a {{ transition: color .2s ease; }}
.nav-links a:hover {{ color: #fff; }}
.nav-cta {{
  min-height: 42px;
  padding-inline: 16px;
  justify-self: end;
  white-space: nowrap;
}}
.menu-btn {{ display: none; background: transparent; border: 1px solid var(--line); color: #fff; border-radius: 10px; width: 44px; height: 44px; }}
.menu-btn span, .menu-btn::before, .menu-btn::after {{ content:""; display:block; width:18px; height:2px; background:#fff; margin:4px auto; }}
.mobile-menu {{ display:none; }}

.hero {{
  min-height: 680px; display: grid; align-items: center; position: relative; isolation: isolate;
  padding: 92px 0 84px;
}}
.hero::after {{
  content:""; position:absolute; width:620px; height:620px; border-radius:50%;
  background: radial-gradient(circle, color-mix(in srgb, var(--accent) 15%, transparent), transparent 68%);
  right:-240px; top:-180px; z-index:-1;
}}
.hero-grid {{ display:grid; grid-template-columns: minmax(0, 1.12fr) minmax(320px, .88fr); gap: 64px; align-items:center; }}
.eyebrow {{
  display:inline-flex; align-items:center; gap:9px; color:var(--accent);
  font-size:.8rem; font-weight:900; letter-spacing:.14em; text-transform:uppercase; margin-bottom:22px;
}}
.eyebrow::before {{ content:""; width:30px; height:2px; background:var(--accent); }}
.hero-copy .lead {{ margin-bottom:30px; }}
.hero-actions {{ display:flex; flex-wrap:wrap; gap:12px; }}
.hero-note {{ margin-top:20px; color:#7f8791; font-size:.84rem; }}

.hero-visual {{
  min-height: 430px; border:1px solid var(--line); border-radius:28px; background:
    linear-gradient(145deg, rgba(255,255,255,.08), rgba(255,255,255,.015)),
    radial-gradient(circle at 70% 22%, rgba(255,255,255,.07), transparent 34%),
    var(--surface);
  position:relative; overflow:hidden; box-shadow:var(--shadow);
}}
.hero-visual::before {{
  content:""; position:absolute; inset:0;
  background: linear-gradient(135deg, transparent 0 42%, rgba(255,255,255,.035) 42.2% 42.5%, transparent 42.7% 100%);
}}
.technical {{
  position:absolute; inset:18px; border:1px solid rgba(255,255,255,.08); border-radius:20px;
}}
.technical::before, .technical::after {{
  content:""; position:absolute; border:1px solid rgba(255,255,255,.07); border-radius:50%;
}}
.technical::before {{ width:230px; height:230px; right:-65px; top:-55px; }}
.technical::after {{ width:150px; height:150px; left:-55px; bottom:-55px; }}
.visual-label {{
  position:absolute; top:24px; left:26px; color:#858d97; font-size:.72rem; letter-spacing:.15em; text-transform:uppercase; font-weight:800;
}}
.visual-panel {{
  position:absolute; left:26px; right:26px; bottom:26px; padding:22px;
  border:1px solid var(--line); border-radius:18px; background:rgba(7,9,12,.76);
}}
.visual-panel-top {{ display:flex; justify-content:space-between; gap:16px; align-items:flex-start; }}
.visual-panel h3 {{ margin:0; font-size:1.2rem; }}
.status {{ color:var(--accent); font-size:.75rem; font-weight:900; text-transform:uppercase; letter-spacing:.1em; }}
.visual-bars {{ display:grid; gap:10px; margin-top:22px; }}
.bar {{ height:7px; background:#252b33; border-radius:99px; overflow:hidden; }}
.bar span {{ display:block; height:100%; background:linear-gradient(90deg, var(--accent), var(--accent-2)); border-radius:inherit; }}
.bar:nth-child(1) span {{ width:88%; }} .bar:nth-child(2) span {{ width:67%; }} .bar:nth-child(3) span {{ width:76%; }}

.trust-strip {{ border-block:1px solid var(--line); background:#0c0f13; }}
.trust-grid {{ display:grid; grid-template-columns:repeat(3,1fr); gap:1px; background:var(--line); }}
.trust-item {{ background:#0c0f13; padding:24px 26px; display:flex; align-items:center; gap:14px; }}
.trust-item svg {{ width:22px; height:22px; stroke:var(--accent); fill:none; stroke-width:1.8; stroke-linecap:round; stroke-linejoin:round; flex:0 0 auto; }}
.trust-item strong {{ display:block; font-size:.92rem; }}
.trust-item span {{ color:#7f8791; font-size:.82rem; }}

.section-head {{ display:flex; justify-content:space-between; align-items:end; gap:30px; margin-bottom:44px; }}
.section-head p {{ color:var(--muted); max-width:520px; margin:0; }}
.services-grid {{ display:grid; grid-template-columns:repeat(3,1fr); gap:16px; }}
.service-card {{
  min-height:260px; position:relative; padding:28px; border:1px solid var(--line); border-radius:var(--radius);
  background:linear-gradient(145deg, rgba(255,255,255,.045), rgba(255,255,255,.012));
  transition:transform .25s ease, border-color .25s ease, background .25s ease;
  overflow:hidden;
}}
.service-card::after {{ content:""; position:absolute; width:150px; height:150px; border-radius:50%; right:-70px; bottom:-80px; background:rgba(255,255,255,.035); }}
.service-card:hover {{ transform:translateY(-5px); border-color:rgba(255,255,255,.2); background:linear-gradient(145deg, rgba(255,255,255,.075), rgba(255,255,255,.018)); }}
.service-top {{ display:flex; justify-content:space-between; align-items:center; margin-bottom:42px; }}
.icon-box {{
  width:46px; height:46px; border-radius:12px; display:grid; place-items:center;
  background:rgba(255,255,255,.06); color:var(--accent); border:1px solid var(--line);
}}
.icon-box svg, .reason-icon svg, .contact-icon svg {{ width:22px; height:22px; fill:none; stroke:currentColor; stroke-width:1.7; stroke-linecap:round; stroke-linejoin:round; }}
.service-index {{ color:#626a74; font:800 .72rem/1 ui-monospace, SFMono-Regular, Menlo, monospace; }}
.service-card h3 {{ font-size:1.32rem; margin-bottom:10px; }}
.service-card p {{ color:var(--muted); font-size:.94rem; max-width:330px; margin:0; }}
.service-arrow {{ position:absolute; right:25px; bottom:22px; color:#606872; font-size:1.2rem; }}

.split {{ display:grid; grid-template-columns:.85fr 1.15fr; gap:70px; align-items:start; }}
.about-panel {{ position:relative; min-height:430px; border:1px solid var(--line); border-radius:26px; overflow:hidden; background:var(--surface); }}
.about-panel::before {{ content:""; position:absolute; inset:0; background:
  radial-gradient(circle at 28% 28%, rgba(255,255,255,.09), transparent 25%),
  linear-gradient(145deg, transparent 20%, rgba(255,255,255,.025) 20.2% 20.7%, transparent 21%),
  repeating-linear-gradient(90deg, transparent 0 38px, rgba(255,255,255,.035) 39px 40px);
}}
.about-badge {{ position:absolute; left:26px; top:26px; border:1px solid var(--line); background:rgba(8,10,13,.76); padding:10px 12px; border-radius:10px; color:var(--accent); font-size:.72rem; font-weight:900; letter-spacing:.12em; text-transform:uppercase; }}
.about-wheel {{ position:absolute; width:250px; height:250px; border:2px solid rgba(255,255,255,.14); border-radius:50%; left:50%; top:50%; transform:translate(-50%,-50%); box-shadow:0 0 0 18px rgba(255,255,255,.018), 0 0 0 38px rgba(255,255,255,.012); }}
.about-wheel::before {{ content:""; position:absolute; inset:55px; border:2px solid var(--accent); border-radius:50%; opacity:.75; }}
.about-wheel::after {{ content:""; position:absolute; left:50%; top:50%; width:9px; height:9px; transform:translate(-50%,-50%); background:var(--accent); border-radius:50%; box-shadow:0 0 0 15px rgba(244,183,64,.08); }}
.about-copy p {{ color:var(--muted); font-size:1.05rem; max-width:680px; }}
.fact-chips {{ display:flex; flex-wrap:wrap; gap:8px; margin-top:28px; }}
.fact-chip {{ border:1px solid var(--line); background:rgba(255,255,255,.035); border-radius:99px; padding:8px 12px; color:#cbd0d7; font-size:.78rem; font-weight:700; }}

.reasons {{ display:grid; grid-template-columns:repeat(2,1fr); gap:14px; margin-top:34px; }}
.reason {{ display:flex; gap:16px; padding:20px; border:1px solid var(--line); border-radius:16px; background:rgba(255,255,255,.025); }}
.reason-icon {{ width:40px; height:40px; flex:0 0 auto; display:grid; place-items:center; color:var(--accent); background:rgba(255,255,255,.05); border-radius:11px; }}
.reason h3 {{ margin:2px 0 5px; font-size:1rem; }}
.reason p {{ margin:0; color:#8f97a1; font-size:.87rem; }}

.process-grid {{ display:grid; grid-template-columns:repeat(3,1fr); gap:1px; background:var(--line); border:1px solid var(--line); }}
.process-item {{ background:var(--bg-soft); padding:30px; min-height:210px; }}
.step-number {{ color:var(--accent); font:900 .76rem/1 ui-monospace, SFMono-Regular, Menlo, monospace; letter-spacing:.1em; }}
.process-item h3 {{ margin:35px 0 9px; font-size:1.18rem; }}
.process-item p {{ margin:0; color:var(--muted); font-size:.9rem; }}

.cta {{
  position:relative; overflow:hidden; padding:76px; border:1px solid var(--line); border-radius:28px;
  background:linear-gradient(120deg, rgba(255,255,255,.07), rgba(255,255,255,.02));
}}
.cta::after {{ content:""; position:absolute; width:420px; height:420px; border-radius:50%; right:-180px; top:-180px; background:radial-gradient(circle, rgba(255,255,255,.09), transparent 65%); }}
.cta > * {{ position:relative; z-index:1; }}
.cta p {{ color:var(--muted); max-width:620px; }}
.cta-actions {{ display:flex; flex-wrap:wrap; gap:12px; margin-top:26px; }}

.booking-grid {{ display:grid; grid-template-columns:.78fr 1.22fr; gap:44px; align-items:start; }}
.contact-stack {{ display:grid; gap:10px; margin-top:28px; }}
.contact-card {{
  display:flex; gap:14px; align-items:center; padding:16px; border:1px solid var(--line); border-radius:14px;
  background:rgba(255,255,255,.025);
}}
.contact-card:hover {{ border-color:rgba(255,255,255,.18); }}
.contact-icon {{ width:40px; height:40px; border-radius:11px; display:grid; place-items:center; background:rgba(255,255,255,.05); color:var(--accent); flex:0 0 auto; }}
.contact-card small {{ display:block; color:#747d87; font-size:.72rem; text-transform:uppercase; letter-spacing:.1em; font-weight:800; }}
.contact-card strong {{ display:block; color:#e9edf1; font-size:.9rem; margin-top:2px; }}

.form-card {{ padding:28px; border:1px solid var(--line); border-radius:22px; background:var(--surface); box-shadow:var(--shadow); }}
.form-grid {{ display:grid; grid-template-columns:1fr 1fr; gap:14px; }}
.field {{ display:grid; gap:7px; }}
.field.full {{ grid-column:1 / -1; }}
.field label {{ color:#c7cdd4; font-size:.78rem; font-weight:800; }}
.field input, .field select, .field textarea {{
  width:100%; border:1px solid var(--line); background:#0d1014; color:#fff; border-radius:11px;
  padding:13px 14px; outline:none;
}}
.field textarea {{ min-height:120px; resize:vertical; }}
.form-note {{ color:#6f7883; font-size:.75rem; margin:14px 0 0; }}
.form-message {{ margin-top:14px; min-height:22px; color:var(--accent); font-weight:700; font-size:.85rem; }}

.faq-grid {{ display:grid; gap:10px; max-width:850px; }}
.faq-item {{ border:1px solid var(--line); border-radius:14px; background:rgba(255,255,255,.025); padding:0 20px; }}
.faq-item summary {{ list-style:none; cursor:pointer; padding:19px 0; display:flex; justify-content:space-between; gap:20px; font-weight:800; }}
.faq-item summary::-webkit-details-marker {{ display:none; }}
.faq-item summary span {{ color:var(--accent); font-size:1.25rem; }}
.faq-item p {{ color:var(--muted); padding:0 0 18px; margin:0; }}

.footer {{ padding:34px 0; border-top:1px solid var(--line); color:#717984; }}
.footer-grid {{ display:flex; justify-content:space-between; gap:30px; align-items:center; }}
.footer-brand {{ color:#e7ebef; font-weight:900; }}
.footer-links {{ display:flex; flex-wrap:wrap; gap:18px; font-size:.82rem; }}
.footer-links a:hover {{ color:#fff; }}

.reveal {{ opacity:0; transform:translateY(18px); transition:opacity .65s ease, transform .65s ease; }}
.reveal.visible {{ opacity:1; transform:none; }}

.back-top {{
  position:fixed; right:20px; bottom:20px; z-index:40; width:46px; height:46px; border-radius:50%;
  border:1px solid var(--line); background:rgba(20,24,30,.86); color:#fff; cursor:pointer; opacity:0; pointer-events:none;
  transition:opacity .2s ease, transform .2s ease;
}}
.back-top.show {{ opacity:1; pointer-events:auto; }}
.back-top:hover {{ transform:translateY(-3px); }}

 @media (min-width: 981px) and (max-width: 1120px) {{
   .nav {{ gap: 16px; }}
   .brand {{ gap: 9px; }}
   .brand-name {{ font-size: .9rem; }}
   .nav-links {{ gap: 20px; font-size: .88rem; }}
   .nav-cta {{ padding-inline: 13px; font-size: .88rem; }}
 }}
 @media (max-width: 980px) {{
  .nav {{ grid-template-columns: 1fr auto; }}
  .nav-links, .nav-cta {{ display:none; }}
  .menu-btn {{ display:block; }}
  .mobile-menu {{
    position:absolute; left:0; right:0; top:74px; padding:12px 20px 20px;
    background:rgba(8,10,13,.97); border-bottom:1px solid var(--line);
  }}
  .mobile-menu.open {{ display:grid; gap:4px; }}
  .mobile-menu a {{ padding:13px 10px; border-radius:10px; color:#d5dae0; }}
  .mobile-menu a:hover {{ background:rgba(255,255,255,.06); color:#fff; }}
  .hero-grid, .split, .booking-grid {{ grid-template-columns:1fr; }}
  .hero {{ min-height:auto; padding-top:72px; }}
  .hero-visual {{ min-height:360px; }}
  .services-grid {{ grid-template-columns:repeat(2,1fr); }}
  .trust-grid {{ grid-template-columns:1fr; }}
}}
@media (max-width: 680px) {{
  .container {{ width:min(var(--max), calc(100% - 28px)); }}
  .brand-name {{ font-size: .92rem; }}
  .section {{ padding:78px 0; }}
  h1 {{ font-size:clamp(2.65rem, 14vw, 4.1rem); }}
  h2 {{ font-size:2.35rem; }}
  .hero {{ padding:56px 0 70px; }}
  .hero-visual {{ min-height:320px; }}
  .services-grid, .reasons, .process-grid, .form-grid {{ grid-template-columns:1fr; }}
  .section-head {{ display:block; }}
  .section-head p {{ margin-top:14px; }}
  .cta {{ padding:42px 24px; }}
  .footer-grid {{ align-items:flex-start; flex-direction:column; }}
  .form-card {{ padding:20px; }}
  .field.full {{ grid-column:auto; }}
  .hero-actions .btn {{ width:100%; }}
}}
@media (prefers-reduced-motion: reduce) {{
  html {{ scroll-behavior:auto; }}
  *, *::before, *::after {{ animation:none !important; transition:none !important; }}
  .reveal {{ opacity:1; transform:none; }}
}}
</style>
</head>
<body>

<header class="site-header">
  <div class="container nav">
    <a class="brand" href="#home" aria-label="{business} home">
      <span class="brand-mark">R</span>
      <span class="brand-name">{business}</span>
    </a>
    <nav class="nav-links" aria-label="Primary navigation">
      <a href="#services">Services</a>
      <a href="#about">About</a>
      <a href="#process">Process</a>
      <a href="#booking">Contact</a>
    </nav>
    <a class="btn btn-primary nav-cta" href="#booking">{primary_cta}</a>
    <button class="menu-btn" id="menuBtn" aria-label="Open menu" aria-expanded="false"></button>
  </div>
  <nav class="mobile-menu" id="mobileMenu" aria-label="Mobile navigation">
    <a href="#services">Services</a>
    <a href="#about">About</a>
    <a href="#process">Process</a>
    <a href="#booking">Contact</a>
    <a href="#booking">{primary_cta}</a>
  </nav>
</header>

<main>
<section class="hero" id="home">
  <div class="container hero-grid">
    <div class="hero-copy">
      <div class="eyebrow">{eyebrow}</div>
      <h1>{headline}</h1>
      <p class="lead">{subheadline}</p>
      <div class="hero-actions">
        <a class="btn btn-primary" href="{hero_primary_href}">{primary_cta} <span>↗</span></a>
        <a class="btn btn-ghost" href="#services">{secondary_cta}</a>
      </div>
      <div class="hero-note">{business_type} · Built for a clear, professional service experience.</div>
    </div>

    <div class="hero-visual" aria-label="Decorative service dashboard">
      <div class="technical"></div>
      <div class="visual-label">SERVICE / DETAIL / PRECISION</div>
      <div class="visual-panel">
        <div class="visual-panel-top">
          <div>
            <div class="status">Ready to help</div>
            <h3>{business}</h3>
          </div>
          <span class="icon-box">{_icon("spark")}</span>
        </div>
        <div class="visual-bars" aria-hidden="true">
          <div class="bar"><span></span></div>
          <div class="bar"><span></span></div>
          <div class="bar"><span></span></div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="trust-strip" aria-label="Business highlights">
  <div class="container trust-grid">
    <div class="trust-item">{_icon("shield")}<span><strong>Professional approach</strong>Clear, customer-focused service</span></div>
    <div class="trust-item">{_icon("check")}<span><strong>Useful next steps</strong>Simple ways to get started</span></div>
    <div class="trust-item">{_icon("spark")}<span><strong>{service_count} {service_label}</strong>Focused on what customers need</span></div>
  </div>
</section>

<section class="section" id="services">
  <div class="container">
    <div class="section-head">
      <div>
        <div class="section-kicker">What we do</div>
        <h2>Services built around the job.</h2>
      </div>
      <p>Explore the services available and choose the route that fits what you need.</p>
    </div>
    <div class="services-grid">
      {''.join(services_html)}
    </div>
  </div>
</section>

<section class="section section-muted" id="about">
  <div class="container split">
    <div class="about-panel reveal" aria-hidden="true">
      <span class="about-badge">Built with intent</span>
      <div class="about-wheel"></div>
    </div>
    <div class="about-copy">
      <div class="section-kicker">About {business}</div>
      <h2>{_esc(plan["about_title"])}</h2>
      <p>{about_text}</p>
      <div class="fact-chips">{fact_chips}</div>
      <div class="reasons">
        {''.join(reasons_html)}
      </div>
    </div>
  </div>
</section>

<section class="section" id="process">
  <div class="container">
    <div class="section-head">
      <div>
        <div class="section-kicker">How it works</div>
        <h2>A simple path forward.</h2>
      </div>
      <p>No unnecessary friction. Start with what you need and move through the service clearly.</p>
    </div>
    <div class="process-grid">
      {''.join(process_html)}
    </div>
  </div>
</section>

<section class="section section-muted" id="booking">
  <div class="container">
    <div class="cta reveal">
      <div class="section-kicker">Ready when you are</div>
      <h2>Let's get the next step moving.</h2>
      <p>Use the contact options or send a service request. The form stays local and validates your details without pretending to submit to a server.</p>
      <div class="cta-actions">
        <a class="btn btn-primary" href="{hero_primary_href}">{primary_cta} <span>↗</span></a>
        {directions_button}
      </div>
    </div>
  </div>
</section>

<section class="section" id="contact">
  <div class="container booking-grid">
    <div>
      <div class="section-kicker">Contact</div>
      <h2>Start with a clear request.</h2>
      <p class="lead">Tell the business what you need. Keep it simple; the important details are enough to begin the conversation.</p>
      <div class="contact-stack">
        {contact_html}
      </div>
    </div>

    <div class="form-card reveal">
      <form id="serviceForm" novalidate>
        <div class="form-grid">
          <div class="field">
            <label for="name">Your name</label>
            <input id="name" name="name" autocomplete="name" required placeholder="Name">
          </div>
          <div class="field">
            <label for="phone">Phone</label>
            <input id="phone" name="phone" autocomplete="tel" required placeholder="Phone number">
          </div>
          <div class="field">
            <label for="vehicle">Vehicle / model</label>
            <input id="vehicle" name="vehicle" placeholder="e.g. Car brand and model">
          </div>
          <div class="field">
            <label for="service">Service needed</label>
            <select id="service" name="service" required>
              <option value="">Choose a service</option>
              {''.join(f'<option>{_esc(s.get("name","Service"))}</option>' for s in plan["services"][:12])}
            </select>
          </div>
          <div class="field">
            <label for="date">Preferred date</label>
            <input id="date" name="date" type="date">
          </div>
          <div class="field">
            <label for="time">Preferred time</label>
            <input id="time" name="time" type="time">
          </div>
          <div class="field full">
            <label for="message">What do you need help with?</label>
            <textarea id="message" name="message" placeholder="Briefly describe the service or problem"></textarea>
          </div>
          <div class="field full">
            <button class="btn btn-primary" type="submit">{_esc(plan["primary_cta"])} <span>↗</span></button>
          </div>
        </div>
        <p class="form-note">This local form does not send data anywhere. It checks your details and prepares the request on this page.</p>
        <div class="form-message" id="formMessage" role="status" aria-live="polite"></div>
      </form>
    </div>
  </div>
</section>

{faq_section}
</main>

<footer class="footer">
  <div class="container footer-grid">
    <div><div class="footer-brand">{business}</div><div>Professional service, clearly presented.</div></div>
    <nav class="footer-links" aria-label="Footer navigation">
      <a href="#home">Home</a><a href="#services">Services</a><a href="#about">About</a><a href="#booking">Contact</a>
    </nav>
  </div>
</footer>

<button class="back-top" id="backTop" aria-label="Back to top">↑</button>

<script>
(function() {{
  const menuBtn = document.getElementById('menuBtn');
  const mobileMenu = document.getElementById('mobileMenu');
  if (menuBtn && mobileMenu) {{
    menuBtn.addEventListener('click', function() {{
      const open = mobileMenu.classList.toggle('open');
      menuBtn.setAttribute('aria-expanded', String(open));
      menuBtn.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    }});
    mobileMenu.querySelectorAll('a').forEach(function(link) {{
      link.addEventListener('click', function() {{
        mobileMenu.classList.remove('open');
        menuBtn.setAttribute('aria-expanded', 'false');
        menuBtn.setAttribute('aria-label', 'Open menu');
      }});
    }});
  }}

  const reveals = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {{
    const observer = new IntersectionObserver(function(entries) {{
      entries.forEach(function(entry) {{
        if (entry.isIntersecting) {{
          entry.target.classList.add('visible');
          observer.unobserve(entry.target);
        }}
      }});
    }}, {{ threshold: 0.12 }});
    reveals.forEach(function(el) {{ observer.observe(el); }});
  }} else {{
    reveals.forEach(function(el) {{ el.classList.add('visible'); }});
  }}

  const form = document.getElementById('serviceForm');
  const message = document.getElementById('formMessage');
  if (form && message) {{
    form.addEventListener('submit', function(event) {{
      event.preventDefault();
      const name = document.getElementById('name');
      const phone = document.getElementById('phone');
      const service = document.getElementById('service');
      if (!name.value.trim() || !phone.value.trim() || !service.value) {{
        message.textContent = 'Please add your name, phone number, and service needed.';
        return;
      }}
      message.textContent = 'Request details look good. Please use the contact option above to send them to the business.';
    }});
  }}

  const backTop = document.getElementById('backTop');
  window.addEventListener('scroll', function() {{
    if (window.scrollY > 500) backTop.classList.add('show');
    else backTop.classList.remove('show');
  }});
  backTop.addEventListener('click', function() {{
    window.scrollTo({{ top: 0, behavior: 'smooth' }});
  }});
}})();
</script>
</body>
</html>"""


# ============================================================
# VALIDATION
# ============================================================

def validate_html(document: str) -> List[str]:
    problems: List[str] = []
    if not document:
        return ["Generated HTML is empty."]

    lower = document.lower()
    required = [
        ("<!doctype html>", "Missing doctype."),
        ("<html", "Missing <html>."),
        ("<head", "Missing <head>."),
        ("<body", "Missing <body>."),
        ('name="viewport"', "Missing viewport meta tag."),
        ("<title", "Missing title."),
        ("<style", "Missing CSS."),
        ("<script", "Missing JavaScript."),
        ("</html>", "Missing closing </html>."),
    ]
    for needle, message in required:
        if needle not in lower:
            problems.append(message)

    if re.search(r"<img\b", lower):
        problems.append("Unexpected <img> element.")
    if re.search(r"https?://", lower):
        # Remote links are permitted only for a supplied directions/WhatsApp
        # destination; the template does not load remote assets.
        asset_patterns = [
            r'<link[^>]+href=["\']https?://',
            r'<script[^>]+src=["\']https?://',
            r'<img[^>]+src=["\']https?://',
        ]
        for pattern in asset_patterns:
            if re.search(pattern, lower):
                problems.append("External asset dependency detected.")
                break

    if "lorem ipsum" in lower or "image goes here" in lower or "placeholder image" in lower:
        problems.append("Placeholder content detected.")

    for tag in ("div", "section", "article", "main"):
        opens = len(re.findall(rf"<{tag}\b", lower))
        closes = len(re.findall(rf"</{tag}>", lower))
        if opens != closes:
            problems.append(f"Unbalanced <{tag}> tags.")

    href_ids = set(re.findall(r'href\s*=\s*["\']#([a-zA-Z0-9_-]+)["\']', document))
    element_ids = set(re.findall(r'\bid\s*=\s*["\']([a-zA-Z0-9_-]+)["\']', document))
    missing = href_ids - element_ids
    if missing:
        problems.append("Missing anchor targets: " + ", ".join(sorted(missing)))

    if "width: 100vw" in lower:
        problems.append("Potential horizontal overflow from width:100vw.")

    return list(dict.fromkeys(problems))


# ============================================================
# PUBLIC API
# ============================================================

def create_html(prompt: str, filename: str = "shaqs_website.html") -> str:
    if prompt is None or not str(prompt).strip():
        raise ValueError("Website request cannot be empty.")

    filename = _clean_filename(filename)
    output_path = WEBSITES_DIR / filename

    print()
    print("=" * 68)
    print("SHAQS WEBSITE BUILDER V8.1")
    print("=" * 68)
    print(f"Model: {MODEL}")
    print("Stage 1/4: understanding the request...")
    plan = _make_plan(str(prompt).strip())

    print("Stage 2/4: creating business-specific content...")
    document = _render_html(plan)

    problems = validate_html(document)
    print("Stage 3/4: rendering the premium website...\nStage 4/4: quality control...")

    if problems:
        raise RuntimeError("Generated website failed validation: " + "; ".join(problems))

    output_path.write_text(document, encoding="utf-8")

    print()
    print("WEBSITE CREATED SUCCESSFULLY")
    print(f"File: {output_path.resolve()}")
    print("=" * 68)
    print()

    return str(output_path.resolve())


def create_website(prompt: str, filename: str = "shaqs_website.html") -> str:
    return create_html(prompt=prompt, filename=filename)


def build_website(prompt: str, filename: str = "shaqs_website.html") -> str:
    return create_html(prompt=prompt, filename=filename)


if __name__ == "__main__":
    test_request = """
Build a premium professional website for Royal Car Service Center.

It is a local automotive service and repair business.
Services include general car servicing and maintenance, engine repair,
brake inspection and repair, oil changes, tire rotation, vehicle diagnostics,
AC servicing, electrical repairs, suspension work, transmission-related work,
interior cleaning, exterior detailing, manual-to-automatic conversion, and
multi-brand car servicing and repairs.

The website goal is to increase local visibility, build trust, showcase
services and expertise, and encourage customers to contact or book.

Use a premium modern automotive design with a dark sophisticated base,
bold typography, strong automotive accents, clean layouts, subtle animation,
and a professional workshop feel.

Do not invent phone numbers, addresses, prices, reviews, ratings, awards,
certifications, opening hours, or years of experience.
"""

    try:
        print(create_html(test_request))
    except Exception as exc:
        print(f"Website creation failed: {exc}")
