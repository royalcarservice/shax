import json
import sqlite3
import webbrowser
from datetime import datetime

from ollama import chat

from skills.file_manager import (
    create_file,
    create_folder,
    list_files,
    read_file,
)

from skills.website_builder import create_html


# ============================================================
# CONFIGURATION
# ============================================================

DB_NAME = "memory.db"
MODEL = "qwen2.5-coder:7b"


# ============================================================
# MEMORY
# ============================================================

def get_memories():
    """Return all saved long-term memories."""

    try:
        connection = sqlite3.connect(DB_NAME)

        rows = connection.execute(
            "SELECT memory FROM memories ORDER BY id"
        ).fetchall()

        connection.close()

        return [row[0] for row in rows]

    except Exception:
        return []


# ============================================================
# BASIC TOOLS
# ============================================================

def get_time():
    """Get the current local computer time."""

    return datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )


# ============================================================
# WEBSITE TOOL
# ============================================================

def create_website(request):
    """Generate a professional standalone HTML website."""

    website_prompt = f"""
You are a senior professional web designer, UI/UX designer,
frontend developer, and conversion-focused website builder.

Create a COMPLETE, polished, professional website based on:

USER REQUEST:
{request}

IMPORTANT OUTPUT RULES

1. Return ONLY the complete HTML document.
2. The first line MUST be:
<!DOCTYPE html>
3. Put ALL CSS inside <style> tags.
4. Put ALL JavaScript inside <script> tags.
5. Everything must be contained inside ONE HTML file.
6. The website must work when opened using file://
7. Do NOT create separate CSS, JavaScript, image, JSON,
   or HTML files.
8. DO NOT use local image paths.
9. DO NOT use placeholder image filenames.
10. DO NOT create broken image elements.
11. Do not use Lorem ipsum.
12. Do not use generic placeholder business names.
13. Use the actual business/product/topic from the request.
14. Do NOT return Markdown code fences.
15. Do NOT explain anything outside the HTML.
16. End the document with </html>.

DESIGN QUALITY

Make the website look like a REAL professional website.

Use:

- modern typography
- strong visual hierarchy
- professional spacing
- polished buttons
- attractive cards
- subtle shadows
- elegant borders
- professional color palette
- gradients where appropriate
- subtle animations
- hover effects
- responsive layouts
- clean semantic HTML

Avoid:

- beginner HTML styling
- random colors
- childish design
- unfinished sections
- broken layouts
- excessive animations
- excessive empty space

VISUALS

The website must work as a standalone local HTML file.

Do not depend on local image files.

When visuals are needed, use:

- CSS backgrounds
- gradients
- inline SVG
- CSS shapes
- icons
- emoji when appropriate
- elegant visual compositions

NAVIGATION

Create a professional navigation bar.

Desktop:

- logo/brand
- navigation links
- active state
- CTA button when appropriate

Mobile:

- hamburger menu
- working JavaScript menu toggle
- responsive navigation

Navigation links must point to real sections.

Use smooth scrolling.

HERO

Create a strong visually impressive hero section.

Include:

- compelling headline
- supporting description
- primary CTA
- secondary CTA when appropriate
- attractive visual composition
- appropriate background treatment

MAIN CONTENT

Choose sections intelligently based on the user's request.

For business websites, sections may include:

- Hero
- Services
- Products
- Features
- About
- Statistics
- Testimonials
- Process
- Pricing
- FAQ
- Call to action
- Contact
- Footer

Do not blindly include every section.

PRODUCT / SERVICE CARDS

When appropriate, create realistic examples.

Cards should have:

- consistent sizing
- useful information
- attractive styling
- hover effects
- appropriate buttons

FORMS

If the website requires a form:

- use proper labels
- required fields
- validation
- useful placeholders
- submit button
- success message

The form must be FRONT-END ONLY.

Do not pretend that data was actually sent to a server.

After successful submission, show a message such as:

"Thank you! We'll get back to you shortly."

INTERACTIONS

Use JavaScript for useful interactions such as:

- mobile menu
- smooth scrolling
- form validation
- success messages
- FAQ accordion
- tabs
- filters
- modals

Every JavaScript feature must actually work.

RESPONSIVE DESIGN

The website MUST work on:

- desktop
- laptop
- tablet
- mobile

Use media queries.

Make sure:

- navigation works on mobile
- cards stack correctly
- text scales properly
- buttons remain usable
- forms fit small screens
- there is no unwanted horizontal scrolling

ACCESSIBILITY

Use:

- semantic HTML
- proper heading hierarchy
- labels for inputs
- accessible buttons
- meaningful link text
- sufficient contrast
- ARIA attributes when appropriate

CONTENT

Write realistic professional content based on the user's request.

Do not use:

- Lorem ipsum
- placeholder names
- unfinished text
- "insert text here"
- "image goes here"

FINAL QUALITY CHECK

Before returning the HTML, check that:

- <!DOCTYPE html> exists
- <html> exists
- <head> exists
- <body> exists
- </html> exists
- CSS is included
- JavaScript is included when needed
- navigation works
- buttons are styled
- sections are coherent
- forms work on the frontend
- mobile layout is handled
- there are no local image paths
- there are no broken placeholder images
- there is no Lorem ipsum
- there are no Markdown fences
- there is no explanation outside the HTML

Return ONLY the final HTML.
"""

    try:

        print("\n[ Shaqs website generator: generating website... ]")

        response = chat(
            model=MODEL,
            messages=[
                {
                    "role": "user",
                    "content": website_prompt,
                }
            ],
        )

        website_html = (
            response.message.content or ""
        ).strip()

        # Remove Markdown fences if the model accidentally adds them.

        if website_html.startswith("```html"):
            website_html = website_html[
                len("```html"):
            ].strip()

        elif website_html.startswith("```HTML"):
            website_html = website_html[
                len("```HTML"):
            ].strip()

        elif website_html.startswith("```"):
            website_html = website_html[
                3:
            ].strip()

        if website_html.endswith("```"):
            website_html = website_html[
                :-3
            ].strip()

        # Find DOCTYPE if the model added text before it.

        doctype_position = website_html.lower().find(
            "<!doctype html"
        )

        if doctype_position > 0:
            website_html = website_html[
                doctype_position:
            ]

        # Basic validation.

        html_lower = website_html.lower()

        if not html_lower.startswith(
            "<!doctype html"
        ):
            return (
                "Website creation failed: "
                "the AI did not return valid HTML."
            )

        if "<html" not in html_lower:
            return (
                "Website creation failed: "
                "missing <html>."
            )

        if "<body" not in html_lower:
            return (
                "Website creation failed: "
                "missing <body>."
            )

        if "</html>" not in html_lower:
            return (
                "Website creation failed: "
                "HTML appears incomplete."
            )

        # Save the website.

        output_file = create_html(
            website_html,
            "shaqs_website.html",
        )

        print(
            f"[ Website saved: {output_file} ]"
        )

        # Open browser.

        try:

            webbrowser.open(
                output_file.resolve().as_uri()
            )

        except Exception as e:

            print(
                f"[ Browser could not be opened: {e} ]"
            )

        return (
            "Website created successfully at: "
            f"{output_file}"
        )

    except Exception as e:

        return (
            f"Website creation failed: {e}"
        )


# ============================================================
# TOOL DEFINITIONS
# ============================================================

tools = [

    {
        "type": "function",
        "function": {
            "name": "get_time",
            "description": (
                "Get the current local computer time."
            ),
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "create_file",
            "description": (
                "Create a file in the Shaqs workspace."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string",
                        "description": (
                            "Name of the file to create."
                        ),
                    },
                    "content": {
                        "type": "string",
                        "description": (
                            "Content to put inside the file."
                        ),
                    },
                },
                "required": ["filename"],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "create_folder",
            "description": (
                "Create a folder in the Shaqs workspace."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "foldername": {
                        "type": "string",
                        "description": (
                            "Name of the folder to create."
                        ),
                    }
                },
                "required": ["foldername"],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": (
                "List files and folders in the "
                "Shaqs workspace."
            ),
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": (
                "Read the contents of a file in "
                "the Shaqs workspace."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string",
                        "description": (
                            "Name of the file to read."
                        ),
                    }
                },
                "required": ["filename"],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "create_website",
            "description": (
                "Create a complete professional "
                "responsive website from the user's "
                "description, save it as an HTML file, "
                "and open it in the browser."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "request": {
                        "type": "string",
                        "description": (
                            "Detailed description of "
                            "the website the user wants."
                        ),
                    }
                },
                "required": ["request"],
            },
        },
    },
]


# ============================================================
# TOOL REGISTRY
# ============================================================

tool_functions = {

    "get_time": get_time,

    "create_file": create_file,

    "create_folder": create_folder,

    "list_files": list_files,

    "read_file": read_file,

    "create_website": create_website,

}


# ============================================================
# TOOL REQUEST PARSER
# ============================================================

def parse_tool_request(response):
    """
    Extract an official Ollama tool call or
    a JSON tool request returned as normal text.
    """

    # Official Ollama tool call.

    if response.message.tool_calls:

        tool_call = (
            response.message.tool_calls[0]
        )

        arguments = (
            tool_call.function.arguments
        )

        if arguments is None:

            arguments = {}

        elif isinstance(arguments, str):

            try:

                arguments = json.loads(
                    arguments
                )

            except json.JSONDecodeError:

                arguments = {}

        return (
            tool_call.function.name,
            arguments
        )

    # Qwen sometimes returns JSON as text.

    content = (
        response.message.content or ""
    ).strip()

    if content.startswith("```json"):

        content = content[7:].strip()

    elif content.startswith("```"):

        content = content[3:].strip()

    if content.endswith("```"):

        content = content[:-3].strip()

    try:

        parsed = json.loads(content)

        if (
            isinstance(parsed, dict)
            and "name" in parsed
        ):

            arguments = parsed.get(
                "arguments",
                {}
            )

            if not isinstance(
                arguments,
                dict
            ):

                arguments = {}

            return (
                parsed["name"],
                arguments
            )

    except json.JSONDecodeError:

        pass

    return None, {}


# ============================================================
# TOOL EXECUTION
# ============================================================

def execute_tool(
    tool_name,
    arguments
):

    if tool_name not in tool_functions:

        return (
            f"Unknown tool: {tool_name}"
        )

    try:

        result = tool_functions[
            tool_name
        ](**arguments)

        return str(result)

    except Exception as e:

        return (
            f"Tool error: {e}"
        )


# ============================================================
# SYSTEM PROMPT
# ============================================================

def build_system_prompt():

    memories = get_memories()

    prompt = """
You are Shaqs, a personal AI assistant.

You are helpful, intelligent, honest and friendly.

You have access to the user's long-term memories
and several real tools.

MEMORY RULES:

- Use memories when they are relevant.
- If the user asks something directly answered by
  a memory, use that memory.
- Do not invent memories.
- If the user asks for their name and a memory
  contains their name, answer it directly.

TOOL RULES:

- Use real tools when genuinely necessary or useful.
- Do not tell the user to manually execute a tool.
- Do not display tool JSON to the user.
- After a tool finishes, answer the original
  request normally.
- Never pretend a tool ran if it did not run.

AVAILABLE TOOLS:

- get_time
- create_file
- create_folder
- list_files
- read_file
- create_website

The create_website tool can generate complete
professional HTML websites from natural-language
descriptions.
"""

    if memories:

        prompt += (
            "\n\nUSER'S LONG-TERM MEMORIES:\n"
        )

        for memory in memories:

            prompt += (
                f"- {memory}\n"
            )

    return prompt


# ============================================================
# MAIN AGENT
# ============================================================

def run_agent(
    user_message,
    conversation=None
):

    if conversation is None:

        conversation = []

    messages = [

        {
            "role": "system",
            "content": build_system_prompt(),
        }

    ]

    messages.extend(
        conversation
    )

    messages.append(
        {
            "role": "user",
            "content": user_message,
        }
    )

    # --------------------------------------------------------
    # FIRST AI CALL
    # --------------------------------------------------------

    response = chat(
        model=MODEL,
        messages=messages,
        tools=tools,
    )

    # --------------------------------------------------------
    # FIND TOOL REQUEST
    # --------------------------------------------------------

    tool_name, arguments = (
        parse_tool_request(response)
    )

    # --------------------------------------------------------
    # NORMAL RESPONSE
    # --------------------------------------------------------

    if not tool_name:

        assistant_text = (
            response.message.content or ""
        )

        messages.append(
            {
                "role": "assistant",
                "content": assistant_text,
            }
        )

        return (
            assistant_text,
            messages
        )

    # --------------------------------------------------------
    # EXECUTE TOOL
    # --------------------------------------------------------

    print(
        f"\n[ Shaqs is using tool: "
        f"{tool_name} ]"
    )

    result = execute_tool(
        tool_name,
        arguments
    )

    print(
        f"[ Tool result: {result} ]"
    )

    # --------------------------------------------------------
    # ADD TOOL REQUEST
    # --------------------------------------------------------

    messages.append(
        {
            "role": "assistant",
            "content": (
                response.message.content or ""
            ),
        }
    )

    # --------------------------------------------------------
    # ADD TOOL RESULT
    # --------------------------------------------------------

    messages.append(
        {
            "role": "tool",
            "content": result,
        }
    )

    # --------------------------------------------------------
    # SECOND AI CALL
    #
    # IMPORTANT:
    # We intentionally DO NOT pass tools here.
    # This prevents Qwen from requesting another
    # tool instead of giving the user an answer.
    # --------------------------------------------------------

    messages.append(
        {
            "role": "user",
            "content": (
                "The requested tool has finished.\n\n"
                f"Tool result: {result}\n\n"
                "Now answer the user's original request "
                "normally.\n"
                "Do not output JSON.\n"
                "Do not show tool instructions.\n"
                "Do not ask the user to run anything manually."
            ),
        }
    )

    final_response = chat(
        model=MODEL,
        messages=messages,
    )

    final_text = (
        final_response.message.content or ""
    ).strip()

    # --------------------------------------------------------
    # SAFETY FALLBACK
    # --------------------------------------------------------

    second_tool_name, _ = (
        parse_tool_request(
            final_response
        )
    )

    if second_tool_name:

        if tool_name == "get_time":

            final_text = (
                f"The current time is {result}."
            )

        elif tool_name == "create_website":

            final_text = (
                "Your website has been "
                "created successfully.\n"
                f"{result}"
            )

        else:

            final_text = result

    # --------------------------------------------------------
    # SAVE ASSISTANT RESPONSE TO CONVERSATION
    # --------------------------------------------------------

    messages.append(
        {
            "role": "assistant",
            "content": final_text,
        }
    )

    return (
        final_text,
        messages
    )