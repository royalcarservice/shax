import json
import sqlite3
import webbrowser
from datetime import datetime

from ollama import chat

from skills.file_manager import (
    create_file,
    create_folder,
    list_files,
    read_file,
)
from skills.website_builder import create_html


DB_NAME = "memory.db"
MODEL = "qwen2.5-coder:7b"


# ============================================================
# MEMORY
# ============================================================

def get_memories():
    """Return saved long-term memories."""
    try:
        connection = sqlite3.connect(DB_NAME)
        rows = connection.execute(
            "SELECT memory FROM memories ORDER BY id"
        ).fetchall()
        connection.close()
        return [row[0] for row in rows]
    except Exception:
        return []


# ============================================================
# BASIC TOOLS
# ============================================================

def get_time():
    """Get the current local computer time."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ============================================================
# AI WEBSITE BUILDER
# ============================================================

def create_website(request):
    """
    Generate a complete professional website from a natural-language
    request, save it as HTML, and open it in the browser.
    """

    website_prompt = f"""
You are the senior creative director, UX designer, UI designer,
copywriter, and front-end developer for a premium AI website builder.

The user wants this website:

{request}

============================================================
YOUR JOB
============================================================

Understand the user's request first.

Determine:
1. What type of website/business this is.
2. Who the target audience is.
3. What the most important conversion/action should be.
4. What visual style fits the business.
5. Which sections and features are appropriate.

Then create the complete website.

Do NOT create a generic template if the business clearly needs
something more specific.

============================================================
DESIGN QUALITY
============================================================

The website must look like a professionally designed real-world
website, not a beginner HTML exercise.

Use:
- Strong visual hierarchy
- Excellent spacing
- Premium typography
- Beautiful cards
- Modern buttons
- Subtle shadows
- Gradients where appropriate
- Smooth transitions
- Micro-interactions
- Scroll animations
- Responsive layouts
- Strong CTA placement
- Consistent design system
- Professional color palette

Choose the visual identity based on the business.

Examples:

Luxury / automotive:
- Premium dark or sophisticated palette
- Large cinematic hero
- Vehicle showcase cards
- Specs
- Financing/booking CTA
- Premium typography

Restaurant:
- Elegant food-focused layout
- Menu sections
- Reservation CTA
- Story/about section
- Location/hours
- Gallery-style visual blocks

SaaS / technology:
- Modern product-focused design
- Feature grid
- Product benefits
- Pricing
- Testimonials
- Strong signup CTA

Agency:
- Bold creative layout
- Services
- Case studies
- Process
- Testimonials
- Contact CTA

Fitness:
- Energetic design
- Programs
- Trainers
- Pricing
- Testimonials
- Membership CTA

Real estate:
- Property cards
- Search/filter UI
- Property details
- Agent section
- Inquiry CTA

E-commerce:
- Product grid
- Categories
- Product cards
- Offers
- Cart-style front-end interactions where appropriate

Portfolio:
- Strong personal branding
- Projects
- Skills/services
- About
- Testimonials
- Contact

============================================================
STRUCTURE
============================================================

Choose sections intelligently.

A typical site may include:

1. Navigation
2. Hero
3. Trust indicators / statistics
4. Main products or services
5. Features / benefits
6. About / story
7. Gallery / portfolio / showcase
8. Testimonials
9. Pricing when appropriate
10. FAQ when appropriate
11. Strong CTA
12. Contact
13. Footer

Do NOT force every section onto every website.

Only include sections that make sense for the user's business.

============================================================
FUNCTIONALITY
============================================================

The site should include useful front-end interactions where relevant.

Examples:
- Mobile menu
- Smooth scrolling
- FAQ accordion
- Tabs
- Filters
- Search UI
- Product/category filtering
- Test-drive/booking UI
- Contact form validation
- Newsletter form
- Modal dialogs
- Pricing toggle
- Gallery interactions
- Scroll reveal animations
- Back-to-top button

All interactions must work with vanilla JavaScript.

Do not create fake backend functionality.

If something requires a backend, make it a polished front-end demonstration
and clearly keep it local/front-end.

============================================================
IMAGES AND ASSETS — MANDATORY
============================================================

The website MUST be completely self-contained and MUST NOT have broken
images.

ABSOLUTE RULES:
- DO NOT use <img> tags anywhere in the HTML.
- DO NOT use background-image:url(...).
- DO NOT use local image paths.
- DO NOT use remote image URLs.
- DO NOT reference .jpg, .jpeg, .png, .webp, .gif, .avif, or other image files.
- DO NOT use placeholder image filenames.
- DO NOT reference external CSS files.
- DO NOT reference external JavaScript files.
- DO NOT reference external fonts.

For visual content, use ONLY:
- inline SVG written directly inside the HTML
- CSS gradients
- CSS shapes
- CSS illustrations
- inline icons
- tasteful emoji only when appropriate

For an automotive site, create attractive inline SVG/CSS vehicle
illustrations inside each vehicle card. They must look intentional and
premium rather than like empty placeholders.

The page must still look visually rich even with the computer offline.

============================================================
CSS / NAVIGATION — MANDATORY
============================================================

The generated HTML MUST contain a complete <style> block.

The navigation MUST NOT appear as default browser bullet lists.

Use a structure such as:
<nav class="site-nav">
  <div class="nav-container">
    ...
  </div>
</nav>

The CSS MUST include:
- body margin reset
- box-sizing reset
- navigation display:flex
- navigation links with text-decoration:none
- navigation spacing
- responsive mobile navigation
- styled buttons
- consistent typography
- section spacing
- card styling
- form styling

Do not rely on browser default styles for any major component.

Before returning the HTML, specifically verify that the navigation would
NOT render as <ul> bullets and that no image icon would show a broken-file
placeholder.

============================================================
HTML REQUIREMENTS
============================================================

1. Return ONLY the complete HTML document.
2. Start with <!DOCTYPE html>.
3. Include CSS inside <style>.
4. Include JavaScript inside <script>.
5. Use semantic HTML.
6. Make it responsive for desktop, tablet, and mobile.
7. Use accessible labels and reasonable contrast.
8. Add hover/focus states.
9. Avoid excessive animation.
10. Respect prefers-reduced-motion where practical.
11. No external local files.
12. No Markdown code fences.
13. No explanation before or after the HTML.
14. The file must work when double-clicked locally.

============================================================
CONTENT REQUIREMENTS
============================================================

Write realistic, polished website copy.

Do NOT fill the site with:
- Lorem ipsum
- "Your Company Here"
- "Lorem"
- generic placeholder text
- unexplained fake image filenames

If the user gives a business name, use it consistently.

If important business information is missing:
- make sensible assumptions
- keep claims generic
- do not invent real certifications, awards, addresses,
  phone numbers, customer counts, or factual achievements

Use realistic demo content where needed without pretending it is factual.

============================================================
FINAL QUALITY CHECK
============================================================

Before returning the HTML, mentally check:

- Does the design fit the business?
- Does the homepage immediately explain what the business does?
- Is the primary CTA obvious?
- Are the sections logically ordered?
- Does it look premium?
- Does it work on mobile?
- Do buttons and navigation behave correctly?
- Are there any broken local asset references?
- Is the HTML complete?
- Is all CSS included?
- Is all JavaScript included?
- Is there any Markdown outside the HTML?

Return ONLY the final HTML.
"""

    try:
        response = chat(
            model=MODEL,
            messages=[
                {
                    "role": "user",
                    "content": website_prompt,
                }
            ],
        )

        website_html = response.message.content.strip()

        # Remove accidental Markdown fences.
        if website_html.startswith("```html"):
            website_html = website_html[7:]
        elif website_html.startswith("```"):
            website_html = website_html[3:]

        if website_html.endswith("```"):
            website_html = website_html[:-3]

        website_html = website_html.strip()

        if not website_html.lower().startswith("<!doctype html"):
            return (
                "Website creation failed: "
                "the AI did not return a complete HTML document."
            )

        # ------------------------------------------------------------
        # TARGETED QUALITY REPAIR
        # ------------------------------------------------------------
        # Qwen can occasionally return valid HTML that still contains
        # default browser navigation or accidental image references.
        # Run one focused repair pass when those symptoms are detected.
        html_lower = website_html.lower()

        needs_repair = (
            "<img" in html_lower
            or "background-image:" in html_lower
            or "url(" in html_lower
            or "<style" not in html_lower
            or "<nav" not in html_lower
        )

        if needs_repair:
            repair_prompt = f'''
You are a meticulous senior front-end engineer repairing a generated
website.

Return ONLY the complete corrected HTML document.

MANDATORY:
1. Start with <!DOCTYPE html>.
2. Keep the requested business, branding, copy, sections and overall concept.
3. Make the navigation a polished flex/grid navigation, never a default browser bullet list.
4. Include a complete <style> block with body reset, responsive layout,
   styled navigation, buttons, cards and forms.
5. DO NOT use <img> anywhere.
6. DO NOT use background-image:url(...) or any url(...) asset reference.
7. DO NOT reference image files or external CSS/JS/fonts.
8. Replace every image-dependent visual with inline SVG or CSS artwork.
9. For vehicle cards, use attractive inline SVG/CSS car illustrations.
10. Keep all JavaScript inside <script>.
11. Make it responsive on desktop, tablet and mobile.
12. Keep the page visually rich and professional.
13. No Markdown fences.
14. No explanation outside the HTML.

Here is the generated HTML to repair:

{website_html}
'''

            repair_response = chat(
                model=MODEL,
                messages=[
                    {
                        "role": "user",
                        "content": repair_prompt,
                    }
                ],
            )

            repaired_html = (repair_response.message.content or "").strip()

            if repaired_html.startswith("```html"):
                repaired_html = repaired_html[7:]
            elif repaired_html.startswith("```"):
                repaired_html = repaired_html[3:]

            if repaired_html.endswith("```"):
                repaired_html = repaired_html[:-3]

            repaired_html = repaired_html.strip()

            if repaired_html.lower().startswith("<!doctype html"):
                website_html = repaired_html

        # Final safety check: do not knowingly save a page containing
        # image-file references that can break when opened locally.
        forbidden_markers = (
            "<img",
            "background-image:url(",
            ".jpg",
            ".jpeg",
            ".png",
            ".webp",
            ".gif",
            ".avif",
        )

        lowered = website_html.lower()
        if any(marker in lowered for marker in forbidden_markers):
            return (
                "Website creation failed quality validation: "
                "the generated page still contains an image asset reference. "
                "Please try the website request again."
            )

        output_file = create_html(
            website_html,
            "shaqs_website.html",
        )

        try:
            webbrowser.open(output_file.resolve().as_uri())
        except Exception:
            pass

        return f"Website created successfully at: {output_file}"

    except Exception as e:
        return f"Website creation failed: {e}"


# ============================================================
# TOOL DEFINITIONS
# ============================================================

tools = [
    {
        "type": "function",
        "function": {
            "name": "get_time",
            "description": "Get the current local computer time.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_file",
            "description": "Create a file in the Shaqs workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string",
                        "description": "Name of the file to create.",
                    },
                    "content": {
                        "type": "string",
                        "description": "Content to put inside the file.",
                    },
                },
                "required": ["filename"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_folder",
            "description": "Create a folder in the Shaqs workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "foldername": {
                        "type": "string",
                        "description": "Name of the folder to create.",
                    }
                },
                "required": ["foldername"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": "List files and folders in the Shaqs workspace.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read the contents of a file in the Shaqs workspace.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string",
                        "description": "Name of the file to read.",
                    }
                },
                "required": ["filename"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_website",
            "description": (
                "Create a complete professional responsive website from "
                "a natural-language description. Automatically determine "
                "the appropriate design, sections, content, and front-end "
                "features, save the result as HTML, and open it in the browser."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "request": {
                        "type": "string",
                        "description": (
                            "Detailed or simple description of the website "
                            "the user wants."
                        ),
                    }
                },
                "required": ["request"],
            },
        },
    },
]


# ============================================================
# TOOL REGISTRY
# ============================================================

tool_functions = {
    "get_time": get_time,
    "create_file": create_file,
    "create_folder": create_folder,
    "list_files": list_files,
    "read_file": read_file,
    "create_website": create_website,
}


# ============================================================
# TOOL REQUEST PARSER
# ============================================================

def parse_tool_request(response):
    """Extract official Ollama tool calls or JSON tool requests."""

    if response.message.tool_calls:
        tool_call = response.message.tool_calls[0]
        arguments = tool_call.function.arguments

        if arguments is None:
            arguments = {}
        elif isinstance(arguments, str):
            try:
                arguments = json.loads(arguments)
            except json.JSONDecodeError:
                arguments = {}

        return tool_call.function.name, arguments

    content = (response.message.content or "").strip()

    if content.startswith("```json"):
        content = content[7:]
    elif content.startswith("```"):
        content = content[3:]

    if content.endswith("```"):
        content = content[:-3]

    content = content.strip()

    try:
        parsed = json.loads(content)

        if isinstance(parsed, dict) and "name" in parsed:
            arguments = parsed.get("arguments", {})

            if not isinstance(arguments, dict):
                arguments = {}

            return parsed["name"], arguments

    except json.JSONDecodeError:
        pass

    return None, {}


# ============================================================
# TOOL EXECUTION
# ============================================================

def execute_tool(tool_name, arguments):
    if tool_name not in tool_functions:
        return f"Unknown tool: {tool_name}"

    try:
        return str(tool_functions[tool_name](**arguments))
    except Exception as e:
        return f"Tool error: {e}"


# ============================================================
# SYSTEM PROMPT
# ============================================================

def build_system_prompt():
    memories = get_memories()

    prompt = """
You are Shaqs, a personal AI assistant.

You are helpful, intelligent, honest and friendly.

You have access to the user's long-term memories and real tools.

MEMORY RULES:
- Use memories when relevant.
- If a memory directly answers a question, use it.
- Do not invent memories.
- If the user asks for their name and a memory contains it, answer directly.

TOOL RULES:
- Use real tools when genuinely necessary or useful.
- Never tell the user to manually execute a tool.
- Never show tool JSON to the user.
- Never pretend a tool ran when it did not.
- After a tool finishes, answer the original request normally.

AVAILABLE TOOLS:
- get_time
- create_file
- create_folder
- list_files
- read_file
- create_website

WEBSITE BUILDER:
The create_website tool is a professional AI website builder.
It can interpret simple natural-language requests and automatically
choose an appropriate design, sections, copy, interactions, and responsive
layout for the requested business or project.
"""

    if memories:
        prompt += "\nUSER'S LONG-TERM MEMORIES:\n"
        for memory in memories:
            prompt += f"- {memory}\n"

    return prompt


# ============================================================
# MAIN AGENT
# ============================================================

def run_agent(user_message, conversation=None):
    if conversation is None:
        conversation = []

    messages = [
        {
            "role": "system",
            "content": build_system_prompt(),
        }
    ]

    messages.extend(conversation)

    messages.append(
        {
            "role": "user",
            "content": user_message,
        }
    )

    # First AI call.
    response = chat(
        model=MODEL,
        messages=messages,
        tools=tools,
    )

    tool_name, arguments = parse_tool_request(response)

    # Normal response.
    if not tool_name:
        assistant_text = response.message.content or ""

        messages.append(
            {
                "role": "assistant",
                "content": assistant_text,
            }
        )

        return assistant_text, messages

    # Execute selected tool.
    print(f"\n[ Shaqs is using tool: {tool_name} ]")

    result = execute_tool(
        tool_name,
        arguments,
    )

    print(f"[ Tool result: {result} ]")

    messages.append(
        {
            "role": "assistant",
            "content": response.message.content or "",
        }
    )

    messages.append(
        {
            "role": "tool",
            "content": result,
        }
    )

    # Second call deliberately has no tools.
    messages.append(
        {
            "role": "user",
            "content": (
                "The requested tool has finished.\n\n"
                f"Tool result: {result}\n\n"
                "Now answer the user's original request normally. "
                "Do not output JSON. "
                "Do not show tool instructions. "
                "Do not ask the user to run anything manually."
            ),
        }
    )

    final_response = chat(
        model=MODEL,
        messages=messages,
    )

    final_text = (final_response.message.content or "").strip()

    # Safety fallback if the model still outputs a tool request.
    second_tool_name, _ = parse_tool_request(final_response)

    if second_tool_name:
        if tool_name == "get_time":
            final_text = f"The current time is {result}."
        elif tool_name == "create_website":
            final_text = (
                "Your website has been created successfully.\n"
                f"{result}"
            )
        else:
            final_text = result

    messages.append(
        {
            "role": "assistant",
            "content": final_text,
        }
    )

    return final_text, messages