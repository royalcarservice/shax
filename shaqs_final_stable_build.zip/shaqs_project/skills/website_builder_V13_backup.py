from __future__ import annotations
import json, re, webbrowser
from html import escape
from pathlib import Path
from ollama import chat

MODEL = 'qwen2.5-coder:7b'
BASE_DIR = Path(__file__).resolve().parent.parent
WEBSITES_DIR = BASE_DIR / 'workspace' / 'websites'
WEBSITES_DIR.mkdir(parents=True, exist_ok=True)

CATEGORY_RULES = {
 'coffee':['coffee shop','cafe','café','coffeehouse','coffee house','espresso','latte','cappuccino','bakery cafe','coffee'],
 'automotive':['car garage','garage','mechanic','auto service','car service','automotive','vehicle repair','car repair','workshop','detailing'],
 'restaurant':['restaurant','diner','bistro','eatery','food house','fine dining'],
 'salon':['salon','barber','beauty','hair studio','hair salon','spa'],
 'fitness':['gym','fitness','crossfit','yoga studio','pilates','workout'],
 'retail':['shop','store','boutique','retail','fashion','clothing'],
 'professional':['law firm','lawyer','accounting','accountant','consulting','agency','real estate','architect','clinic','doctor']}

THEMES = {
 'coffee':dict(bg='#17110D',surface='#211812',surface2='#2B2019',text='#FFF7ED',muted='#CDBEAF',accent='#D89B52',accent2='#F0C98E',line='#49382C'),
 'automotive':dict(bg='#090B0D',surface='#111519',surface2='#171C21',text='#F5F7FA',muted='#AAB3BE',accent='#F5B83D',accent2='#FFE09A',line='#2B333C'),
 'restaurant':dict(bg='#160C0B',surface='#211211',surface2='#2C1715',text='#FFF7F0',muted='#D2BEB4',accent='#E27A52',accent2='#F2B39A',line='#4B2A25'),
 'salon':dict(bg='#120F13',surface='#1C171E',surface2='#261F29',text='#FFF8FC',muted='#CDBFCB',accent='#D99BC4',accent2='#F0C8E1',line='#423642'),
 'fitness':dict(bg='#080D0B',surface='#101713',surface2='#172119',text='#F3FFF6',muted='#B4C5BA',accent='#8BE35A',accent2='#C4F7A7',line='#2D4132'),
 'retail':dict(bg='#0D0D10',surface='#15151A',surface2='#1D1D23',text='#FAFAFF',muted='#B8B8C5',accent='#B6A0FF',accent2='#D6CCFF',line='#34343F'),
 'professional':dict(bg='#0B1016',surface='#121923',surface2='#192330',text='#F5F8FC',muted='#B5C0CD',accent='#7DB5FF',accent2='#BBD8FF',line='#2C3948'),
 'general':dict(bg='#0D0F12',surface='#15181D',surface2='#1D2128',text='#F6F7F9',muted='#B2B8C2',accent='#D5A84B',accent2='#F0D28B',line='#303741')}

FALLBACKS = {
 'coffee':dict(headline='Coffee worth slowing down for.',sub='A warm, modern coffee experience built around good drinks, good food and good moments.',eyebrow='BREWED WITH INTENTION',cta='Explore the menu',secondary='Visit the cafe',section='Signature drinks',items=[('Espresso','Rich, concentrated and made for the first sip.'),('Cappuccino','Velvety espresso with a soft layer of milk foam.'),('Latte','Smooth espresso and steamed milk, easy to settle into.'),('Mocha','Deep chocolate notes balanced with espresso.'),('Cold Brew','Slow, smooth and refreshing.'),('Fresh Pastries','A simple companion for your coffee.')]),
 'automotive':dict(headline='Confident service for every drive.',sub='Practical diagnosis, careful repairs and multi-brand automotive support.',eyebrow='AUTOMOTIVE SERVICE / REPAIR',cta='Book a service',secondary='Explore services',section='What we handle',items=[('Car servicing','Routine maintenance and preventative care.'),('Diagnostics & repair','Find the problem first, then choose the right repair.'),('Brakes & suspension','Inspection and repair for confident handling.'),('AC & electrical','Fault-finding and service for comfort and reliability.'),('Transmission work','Transmission-related inspection and repair.'),('Multi-brand service','Support for vehicles across different brands.')]),
 'restaurant':dict(headline='A table worth coming back to.',sub='Thoughtful food, a welcoming room and a menu designed around the experience.',eyebrow='FOOD / FLAVOUR / EXPERIENCE',cta='View the menu',secondary='Plan your visit',section='From the kitchen',items=[('Signature plates','Standout dishes made to be remembered.'),('Small plates','Easy-to-share favourites for the table.'),('Mains','Comforting, considered plates for a proper meal.'),('Desserts','A sweet finish to the evening.'),('Drinks','Pair your meal with something refreshing.'),('Seasonal specials','Fresh ideas that change with the mood.')]),
 'salon':dict(headline='A little more like you.',sub='A considered beauty experience with thoughtful service and a polished finish.',eyebrow='BEAUTY / CARE / STYLE',cta='Book an appointment',secondary='Explore services',section='Our services',items=[('Hair styling','A polished cut, style or refresh for your look.'),('Colour','Thoughtful colour work tailored to your style.'),('Treatments','Care-focused treatments for a healthy finish.'),('Beauty services','Simple, refined details that complete the look.'),('Occasion styling','A considered finish for important moments.'),('Consultation','Start with a conversation about what you want.')]),
 'fitness':dict(headline='Train with purpose. Feel the difference.',sub='A focused training environment built around movement, consistency and progress.',eyebrow='TRAIN / MOVE / PROGRESS',cta='Start training',secondary='See programs',section='Training paths',items=[('Strength','Build a stronger foundation with focused training.'),('Conditioning','Improve fitness, stamina and everyday energy.'),('Mobility','Move better and build useful range of motion.'),('Classes','Structured sessions with a clear purpose.'),('Personal training','Individual guidance built around your goals.'),('Recovery','Make recovery part of the plan, not an afterthought.')]),
 'retail':dict(headline='Things worth taking home.',sub='A considered collection presented with a simple, enjoyable shopping experience.',eyebrow='SHOP / DISCOVER / CHOOSE',cta='Explore the collection',secondary='Visit the store',section='Featured collection',items=[('New arrivals','Fresh pieces selected to stand out.'),('Best sellers','Customer favourites worth another look.'),('Everyday essentials','Useful, well-chosen pieces for daily life.'),('Statement pieces','A little more character when you want it.'),('Gifts','Easy ideas for someone worth thinking about.'),('Seasonal edit','A changing selection for the moment.')]),
 'professional':dict(headline='Clear expertise. Better next steps.',sub='A polished professional experience designed to make expertise easier to understand and act on.',eyebrow='EXPERTISE / CLARITY / TRUST',cta='Start a conversation',secondary='Explore services',section='How we can help',items=[('Advisory','Practical guidance shaped around the situation.'),('Strategy','A clear way forward when the next step is complex.'),('Review','Careful attention to the details that matter.'),('Planning','Turn priorities into an actionable plan.'),('Support','Ongoing help when you need a steady partner.'),('Consultation','Begin with a focused conversation.')]),
 'general':dict(headline='Built around what matters to you.',sub='A clear, modern introduction to the business, its offer and the people it serves.',eyebrow='WELCOME',cta='Get started',secondary='Explore more',section='What we offer',items=[('What we do','A clear introduction to the core offer.'),('What makes it different','The details that make the business worth choosing.'),('A better experience','Simple, thoughtful service from first contact onward.'),('For your needs','An offer shaped around the customer.'),('Practical support','Clear information without unnecessary friction.'),('Let’s talk','Start with a simple conversation.')])}

ABOUT_TITLE = {'coffee':'More than a cup.','automotive':'Experience that stays practical.','restaurant':'Made for the whole experience.','salon':'Care, detail and a polished finish.','fitness':'Consistency creates progress.','retail':'A collection with a point of view.','professional':'Expertise, without the unnecessary complexity.','general':'A clearer way to experience the business.'}
ABOUT_TEXT = {'coffee':'A place to pause, order something you love and stay a little longer. The experience keeps the focus on the drinks, the atmosphere and the simple pleasure of a good cafe.','automotive':'A strong service experience starts with understanding the problem. The experience puts clarity, practical expertise and the next useful step in front of the customer.','restaurant':'Good dining is more than a list of dishes. It is the food, the room, the people and the reason you chose to come in.','salon':'The best beauty experiences feel considered rather than complicated. The focus stays on care, confidence and a finish that feels like you.','fitness':'Progress is built from repeatable habits. The experience makes training feel focused, understandable and worth returning to.','retail':'A good shop makes choosing feel easy. The collection is given space to breathe, with clear categories and a visual identity that feels intentional.','professional':'People should be able to understand what you do, why it matters and what to do next. The experience keeps expertise clear and approachable.','general':'A useful website should answer important questions quickly, make the business feel distinctive and give visitors an obvious next step.'}


def detect_category(request):
    t=request.lower(); scores={c:sum(k in t for k in ks) for c,ks in CATEGORY_RULES.items()}; best=max(scores,key=scores.get); return best if scores[best] else 'general'

def extract_name(request, category):
    patterns = [
        r'(?:named|called)\s+["\']?([A-Za-z0-9][A-Za-z0-9_-]{1,30})["\']?(?=[\s.,!?]|$)',
        r'coffee\s+shop\s+["\']?([A-Za-z0-9][A-Za-z0-9_-]{1,30})["\']?(?=[\s.,!?]|$)',
    ]

    for pat in patterns:
        m = re.search(pat, request, re.I)
        if m:
            return m.group(1).strip().rstrip('.,!? ')

    return 'Your Business'

def plan_with_ai(request,category,name):
    fallback=FALLBACKS[category]
    prompt=f'''Return ONLY valid JSON for a premium {category} website. Business: {name}. Request: {request}. Never invent address, phone, prices, ratings, hours, awards, certifications or years. Keys: headline, sub, eyebrow, cta, secondary, section, items. items: exactly 6 objects with name and description.'''
    try:
        r=chat(model=MODEL,messages=[{'role':'user','content':prompt}]); raw=(r.message.content or '').strip(); raw=re.sub(r'^```(?:json)?\s*|\s*```$','',raw,flags=re.I|re.S).strip(); a,b=raw.find('{'),raw.rfind('}'); data=json.loads(raw[a:b+1]) if a>=0 and b>a else {}
        if not isinstance(data,dict):return fallback
        out=fallback.copy()
        for k in ['headline','sub','eyebrow','cta','secondary','section']:
            if isinstance(data.get(k),str) and data[k].strip():out[k]=data[k].strip()
        clean=[]
        for x in data.get('items',[])[:6]:
            if isinstance(x,dict) and x.get('name') and x.get('description'):clean.append((str(x['name']).strip(),str(x['description']).strip()))
        if len(clean)>=4:out['items']=clean+fallback['items'][len(clean):]
        return out
    except Exception:return fallback

def esc(x):return escape(str(x),quote=True)

def svg(category):
    art={
    'coffee':'''<svg class="hero-art" viewBox="0 0 620 560" role="img" aria-label="Coffee cup with steam" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="cup" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#F0C98E"/><stop offset="1" stop-color="#B56E36"/></linearGradient></defs><circle cx="310" cy="280" r="230" fill="#2D2018"/><circle cx="310" cy="280" r="185" fill="#3B291F" stroke="#6D4C36"/><path d="M250 142 C215 95 265 76 245 34 M315 142 C280 92 337 72 316 28 M380 142 C345 96 399 78 382 42" fill="none" stroke="#F0C98E" stroke-width="11" stroke-linecap="round"/><path d="M183 220 H437 V355 C437 421 389 463 310 463 C231 463 183 421 183 355 Z" fill="url(#cup)"/><ellipse cx="310" cy="221" rx="127" ry="45" fill="#5A351F" stroke="#F5D6A7" stroke-width="7"/><ellipse cx="310" cy="220" rx="102" ry="29" fill="#24140E"/><path d="M437 258 C520 242 543 292 527 339 C515 374 479 386 438 373" fill="none" stroke="#F0C98E" stroke-width="24"/><ellipse cx="450" cy="480" rx="104" ry="18" fill="#120D0A" opacity=".45"/></svg>''',
    'automotive':'''<svg class="hero-art" viewBox="0 0 620 560" role="img" aria-label="Car illustration" xmlns="http://www.w3.org/2000/svg"><rect x="55" y="60" width="510" height="410" rx="42" fill="#171C21" stroke="#36414C"/><path d="M132 333 L166 242 Q177 214 212 204 L390 204 Q423 207 445 238 L492 333" fill="none" stroke="#F5B83D" stroke-width="12" stroke-linecap="round"/><path d="M113 333 H507 V380 H113Z" fill="#0A0C0F" stroke="#F5B83D" stroke-width="8"/><circle cx="182" cy="383" r="45" fill="#0B0D10" stroke="#AAB3BE" stroke-width="10"/><circle cx="438" cy="383" r="45" fill="#0B0D10" stroke="#AAB3BE" stroke-width="10"/><path d="M202 238 L236 221 H372 L413 244" fill="none" stroke="#AAB3BE" stroke-width="6"/></svg>''',
    'restaurant':'''<svg class="hero-art" viewBox="0 0 620 560" role="img" aria-label="Plated dish illustration" xmlns="http://www.w3.org/2000/svg"><circle cx="310" cy="285" r="220" fill="#2B1715"/><ellipse cx="310" cy="330" rx="180" ry="48" fill="#120A09" opacity=".55"/><ellipse cx="310" cy="300" rx="165" ry="62" fill="#FFF7F0"/><ellipse cx="310" cy="285" rx="122" ry="42" fill="#E27A52"/><path d="M218 286 C251 240 280 260 310 280 C343 300 374 248 404 285" fill="none" stroke="#160C0B" stroke-width="16" stroke-linecap="round"/></svg>''',
    'salon':'''<svg class="hero-art" viewBox="0 0 620 560" role="img" aria-label="Salon scissors and hair illustration" xmlns="http://www.w3.org/2000/svg"><circle cx="310" cy="280" r="215" fill="#2D2430"/><path d="M220 130 C170 215 198 392 310 450 C422 392 450 215 400 130" fill="none" stroke="#D99BC4" stroke-width="18"/><circle cx="245" cy="270" r="30" fill="none" stroke="#F0C8E1" stroke-width="10"/><circle cx="375" cy="270" r="30" fill="none" stroke="#F0C8E1" stroke-width="10"/><path d="M264 285 L355 382 M356 285 L265 382" stroke="#D99BC4" stroke-width="12" stroke-linecap="round"/></svg>''',
    'fitness':'''<svg class="hero-art" viewBox="0 0 620 560" role="img" aria-label="Barbell illustration" xmlns="http://www.w3.org/2000/svg"><circle cx="310" cy="280" r="220" fill="#172119"/><path d="M125 280 H495" stroke="#F3FFF6" stroke-width="18"/><path d="M180 220 V340 M155 235 V325 M440 220 V340 M465 235 V325" stroke="#8BE35A" stroke-width="24" stroke-linecap="round"/></svg>''',
    'retail':'''<svg class="hero-art" viewBox="0 0 620 560" role="img" aria-label="Shopping bag illustration" xmlns="http://www.w3.org/2000/svg"><rect x="90" y="70" width="440" height="420" rx="42" fill="#1D1D23"/><path d="M205 220 C205 125 415 125 415 220" fill="none" stroke="#D6CCFF" stroke-width="14"/><path d="M155 205 H465 L435 430 H185 Z" fill="#B6A0FF"/><path d="M235 300 H385" stroke="#0D0D10" stroke-width="12" stroke-linecap="round"/></svg>''',
    'professional':'''<svg class="hero-art" viewBox="0 0 620 560" role="img" aria-label="Document and check mark illustration" xmlns="http://www.w3.org/2000/svg"><rect x="150" y="70" width="320" height="420" rx="28" fill="#192330" stroke="#7DB5FF" stroke-width="6"/><path d="M220 170 H400 M220 225 H400 M220 280 H350" stroke="#BBD8FF" stroke-width="12" stroke-linecap="round"/><path d="M218 365 L278 420 L402 302" fill="none" stroke="#7DB5FF" stroke-width="20" stroke-linecap="round" stroke-linejoin="round"/></svg>'''}
    return art.get(category,'''<svg class="hero-art" viewBox="0 0 620 560" role="img" aria-label="Business illustration" xmlns="http://www.w3.org/2000/svg"><circle cx="310" cy="280" r="220" fill="#252A31"/><circle cx="310" cy="280" r="140" fill="none" stroke="#F0D28B" stroke-width="8"/><path d="M190 330 L270 245 L325 295 L430 190" fill="none" stroke="#D5A84B" stroke-width="18" stroke-linecap="round" stroke-linejoin="round"/></svg>''')

# ============================================================
# V12.0 — ADAPTIVE DESIGN STRATEGY ENGINE
# ============================================================

DESIGN_STRATEGIES = {
    'coffee': {
        'layout': 'editorial',
        'hero': 'immersive',
        'content': 'menu-first',
        'density': 'comfortable',
        'visual': 'warm-editorial',
        'cta': 'visit-focused',
    },

    'automotive': {
        'layout': 'asymmetric',
        'hero': 'service-focused',
        'content': 'service-first',
        'density': 'structured',
        'visual': 'technical-industrial',
        'cta': 'booking-focused',
    },

    'restaurant': {
        'layout': 'image-led',
        'hero': 'immersive',
        'content': 'experience-first',
        'density': 'comfortable',
        'visual': 'culinary-editorial',
        'cta': 'reservation-focused',
    },

    'salon': {
        'layout': 'minimalist',
        'hero': 'visual',
        'content': 'service-first',
        'density': 'airy',
        'visual': 'elegant',
        'cta': 'booking-focused',
    },

    'fitness': {
        'layout': 'conversion',
        'hero': 'action-focused',
        'content': 'program-first',
        'density': 'energetic',
        'visual': 'athletic',
        'cta': 'signup-focused',
    },

    'retail': {
        'layout': 'bento',
        'hero': 'collection-focused',
        'content': 'product-first',
        'density': 'visual',
        'visual': 'modern-retail',
        'cta': 'shopping-focused',
    },

    'professional': {
        'layout': 'structured',
        'hero': 'trust-focused',
        'content': 'expertise-first',
        'density': 'formal',
        'visual': 'corporate',
        'cta': 'consultation-focused',
    },

    'general': {
        'layout': 'modular',
        'hero': 'balanced',
        'content': 'business-first',
        'density': 'balanced',
        'visual': 'neutral-modern',
        'cta': 'contact-focused',
    },
}


def get_design_strategy(category, request=''):
    """
    Select the initial adaptive design strategy.

    V12.0 intentionally keeps this deterministic.
    Later versions can allow an AI planner to refine it.
    """

    category = str(category or 'general').lower()

    strategy = dict(
        DESIGN_STRATEGIES.get(
            category,
            DESIGN_STRATEGIES['general']
        )
    )

    request_lower = str(request or '').lower()

    # Intent overrides.
    if any(word in request_lower for word in [
        'book',
        'booking',
        'appointment',
        'reserve',
        'reservation'
    ]):
        strategy['cta'] = 'booking-focused'

    if any(word in request_lower for word in [
        'portfolio',
        'photography',
        'photographer',
        'creative',
        'designer'
    ]):
        strategy['layout'] = 'gallery'
        strategy['hero'] = 'visual'
        strategy['content'] = 'work-first'
        strategy['visual'] = 'creative'

    if any(word in request_lower for word in [
        'saas',
        'software',
        'startup',
        'app',
        'platform',
        'technology',
        'tech'
    ]):
        strategy['layout'] = 'product'
        strategy['hero'] = 'product-focused'
        strategy['content'] = 'feature-first'
        strategy['visual'] = 'technology'
        strategy['cta'] = 'conversion-focused'

    if any(word in request_lower for word in [
        'luxury',
        'premium',
        'exclusive',
        'high-end'
    ]):
        strategy['visual'] = 'luxury'
        strategy['density'] = 'airy'

    return strategy

def render(plan, name, category, request=''):
    strategy = get_design_strategy(category, request)
    t = THEMES[category]

    # ---------------------------------------------------------
    # V12 — STRATEGY → REAL VISUAL STRUCTURE
    # ---------------------------------------------------------

    layout = strategy['layout']
    hero_style = strategy['hero']
    content_style = strategy['content']
    visual_style = strategy['visual']
    cta_style = strategy['cta']
    density = strategy['density']

    nav = 'Menu' if category in ('coffee', 'restaurant', 'retail') else 'Services'

    if category == 'coffee':
        label = 'Visit the cafe'
    elif category == 'automotive':
        label = 'Book a service'
    else:
        label = plan['cta']

    # ---------------------------------------------------------
    # Strategy classes
    # ---------------------------------------------------------

    strategy_classes = (
        f"layout-{layout} "
        f"hero-{hero_style} "
        f"content-{content_style} "
        f"visual-{visual_style} "
        f"cta-{cta_style} "
        f"density-{density}"
    )

    # ---------------------------------------------------------
    # Items
    # ---------------------------------------------------------

    items = ''.join(
        '<article class="item">'
        '<span class="num">%02d</span>'
        '<div>'
        '<h3>%s</h3>'
        '<p>%s</p>'
        '</div>'
        '<span class="arrow">→</span>'
        '</article>'
        % (i + 1, esc(n), esc(d))
        for i, (n, d) in enumerate(plan['items'])
    )

    # ---------------------------------------------------------
    # V12 adaptive CSS
    # ---------------------------------------------------------

    adaptive_css = '''

/* =========================================================
   V12 ADAPTIVE DESIGN ENGINE
   The strategy now changes the actual visual structure.
   ========================================================= */

/* ---------- BASE ---------- */

body{
    transition:background .35s ease,color .35s ease;
}

.site-shell{
    position:relative;
    overflow:hidden;
}

/* ---------- EDITORIAL ---------- */

.layout-editorial .hero{
    grid-template-columns:1.2fr .8fr;
}

.layout-editorial h1{
    max-width:900px;
}

.layout-editorial .hero-frame{
    border-radius:40px;
}

.layout-editorial .item{
    min-height:270px;
}

.visual-warm-editorial .hero-frame{
    background:
        radial-gradient(circle at 30% 20%,rgba(255,180,90,.18),transparent 35%),
        linear-gradient(145deg,var(--surface2),var(--surface));
}

.visual-culinary-editorial .hero-frame{
    background:
        radial-gradient(circle at 70% 25%,rgba(255,120,80,.16),transparent 35%),
        linear-gradient(145deg,var(--surface2),var(--surface));
}

/* ---------- ASYMMETRIC / AUTOMOTIVE ---------- */

.layout-asymmetric .hero{
    grid-template-columns:.72fr 1.28fr;
}

.layout-asymmetric .hero > div:first-child{
    order:2;
}

.layout-asymmetric .hero-frame{
    order:1;
    min-height:620px;
    border-radius:22px;
}

.layout-asymmetric .grid{
    grid-template-columns:1fr 1fr;
}

.layout-asymmetric .item:nth-child(3n){
    border-right:1px solid var(--line);
}

.layout-asymmetric .item:nth-child(2n){
    border-right:0;
}

.visual-technical-industrial .hero-frame{
    border-radius:12px;
    background:
        linear-gradient(135deg,
            var(--surface2),
            var(--surface));
}

.visual-technical-industrial .item{
    border-radius:0;
}

/* ---------- IMAGE LED ---------- */

.layout-image-led .hero{
    display:block;
    position:relative;
}

.layout-image-led .hero > div:first-child{
    position:relative;
    z-index:3;
    max-width:780px;
    padding:70px 0;
}

.layout-image-led .hero-frame{
    min-height:650px;
    margin-top:-120px;
    width:100%;
    border-radius:36px;
}

.layout-image-led .hero-frame .hero-art{
    width:70%;
}

.layout-image-led .grid{
    grid-template-columns:repeat(2,1fr);
}

.layout-image-led .item{
    min-height:280px;
}

/* ---------- CONVERSION / FITNESS ---------- */

.layout-conversion .hero{
    grid-template-columns:1fr;
    text-align:center;
}

.layout-conversion .hero > div:first-child{
    max-width:900px;
    margin:auto;
}

.layout-conversion .lead{
    margin-left:auto;
    margin-right:auto;
}

.layout-conversion .actions{
    justify-content:center;
}

.layout-conversion .hero-frame{
    min-height:460px;
    max-width:900px;
    width:100%;
    margin:auto;
}

.layout-conversion .grid{
    grid-template-columns:repeat(3,1fr);
}

.visual-athletic .hero-frame{
    border-radius:28px;
    background:
        radial-gradient(circle at 50% 40%,rgba(255,255,255,.10),transparent 35%),
        linear-gradient(145deg,var(--surface2),var(--surface));
}

.visual-athletic .item{
    border-radius:18px;
    margin:8px;
    border:1px solid var(--line);
}

/* ---------- HERO MODES ---------- */

.hero-service-focused .hero-frame{
    min-height:600px;
}

.hero-action-focused .hero-frame{
    min-height:500px;
}

.hero-immersive .hero-frame{
    min-height:620px;
}

.hero-product-focused .hero-frame{
    min-height:520px;
}

/* ---------- CONTENT MODES ---------- */

.content-menu-first .grid{
    grid-template-columns:repeat(3,1fr);
}

.content-service-first .grid{
    grid-template-columns:repeat(2,1fr);
}

.content-program-first .grid{
    grid-template-columns:repeat(3,1fr);
}

.content-experience-first .grid{
    grid-template-columns:repeat(2,1fr);
}

/* ---------- DENSITY ---------- */

.density-airy .section{
    padding-top:150px;
    padding-bottom:150px;
}

.density-comfortable .section{
    padding-top:110px;
    padding-bottom:110px;
}

.density-structured .section{
    padding-top:80px;
    padding-bottom:80px;
}

.density-energetic .section{
    padding-top:70px;
    padding-bottom:70px;
}

/* ---------- CTA MODES ---------- */

.cta-booking-focused .cta-box{
    border-radius:18px;
    padding:70px;
}

.cta-signup-focused .cta-box{
    text-align:center;
    border-radius:30px;
}

.cta-reservation-focused .cta-box{
    border-radius:40px;
    padding:80px;
}

.cta-visit-focused .cta-box{
    border-radius:34px;
}

/* ---------- MOBILE ---------- */

@media(max-width:900px){

    .layout-asymmetric .hero{
        grid-template-columns:1fr;
    }

    .layout-asymmetric .hero > div:first-child{
        order:1;
    }

    .layout-asymmetric .hero-frame{
        order:2;
    }

    .layout-image-led .hero-frame{
        margin-top:0;
    }

    .layout-conversion .hero{
        grid-template-columns:1fr;
    }

}

@media(max-width:600px){

    .layout-image-led .hero > div:first-child{
        padding:35px 0;
    }

    .layout-image-led .hero-frame{
        min-height:360px;
    }

    .layout-asymmetric .grid,
    .layout-image-led .grid,
    .content-service-first .grid,
    .content-experience-first .grid{
        grid-template-columns:1fr;
    }

    .density-airy .section{
        padding-top:90px;
        padding-bottom:90px;
    }

    .cta-booking-focused .cta-box,
    .cta-reservation-focused .cta-box{
        padding:40px 24px;
    }

}
'''

    # ---------------------------------------------------------
    # Main template
    # ---------------------------------------------------------

    template = '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>__NAME__ — __CATEGORY__</title>
<meta name="description" content="__SUB__">

<style>

:root{
--bg:__BG__;
--surface:__SURFACE__;
--surface2:__SURFACE2__;
--text:__TEXT__;
--muted:__MUTED__;
--accent:__ACCENT__;
--accent2:__ACCENT2__;
--line:__LINE__
}

*{
box-sizing:border-box
}

html{
scroll-behavior:smooth
}

body{
margin:0;
background:var(--bg);
color:var(--text);
font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;
line-height:1.5
}

a{
color:inherit;
text-decoration:none
}

.wrap{
width:min(1180px,calc(100% - 40px));
margin:auto
}

.nav{
position:sticky;
top:0;
z-index:20;
border-bottom:1px solid var(--line);
background:var(--bg)
}

.navin{
height:78px;
display:flex;
align-items:center;
justify-content:space-between
}

.brand{
display:flex;
gap:12px;
align-items:center;
font-weight:900;
letter-spacing:-.03em
}

.mark{
width:42px;
height:42px;
border-radius:13px;
background:var(--accent);
color:#17110D;
display:grid;
place-items:center;
font-weight:950
}

.links{
display:flex;
gap:30px;
color:var(--muted);
font-size:14px
}

.links a:hover{
color:var(--text)
}

.navcta,
.btn{
display:inline-flex;
align-items:center;
justify-content:center;
gap:9px;
padding:14px 18px;
border-radius:14px;
font-weight:850;
border:1px solid var(--line);
transition:.25s
}

.navcta,
.primary{
background:var(--accent);
color:#17110D;
border-color:transparent;
box-shadow:0 12px 34px rgba(0,0,0,.18)
}

.btn:hover,
.navcta:hover{
transform:translateY(-2px)
}

.ghost{
background:var(--surface)
}

.hero{
min-height:700px;
padding:80px 0 70px;
display:grid;
grid-template-columns:1.03fr .97fr;
gap:54px;
align-items:center
}

.eyebrow,
.kicker{
font-size:12px;
font-weight:900;
letter-spacing:.18em;
color:var(--accent)
}

h1{
font-size:clamp(58px,7.6vw,112px);
line-height:.9;
letter-spacing:-.075em;
margin:22px 0 28px
}

.lead{
font-size:20px;
color:var(--muted);
max-width:650px
}

.actions{
display:flex;
gap:12px;
flex-wrap:wrap;
margin-top:30px
}

.micro{
margin-top:20px;
color:var(--muted);
font-size:13px
}

.hero-frame{
min-height:560px;
border:1px solid var(--line);
border-radius:34px;
background:
radial-gradient(circle at 65% 20%,rgba(255,255,255,.06),transparent 36%),
linear-gradient(145deg,var(--surface2),var(--surface));
display:grid;
place-items:center;
position:relative;
overflow:hidden;
box-shadow:0 30px 90px rgba(0,0,0,.28)
}

.hero-frame:before{
content:"";
position:absolute;
width:430px;
height:430px;
border:1px solid var(--line);
border-radius:50%;
top:-120px;
right:-120px
}

.hero-frame:after{
content:"";
position:absolute;
width:270px;
height:270px;
border:1px solid var(--line);
border-radius:50%;
bottom:-140px;
left:-80px
}

.hero-art{
width:86%;
position:relative;
z-index:2;
filter:drop-shadow(0 30px 45px rgba(0,0,0,.3))
}

.art-label{
position:absolute;
top:25px;
left:27px;
color:var(--muted);
font-size:11px;
font-weight:900;
letter-spacing:.16em
}

.section{
padding:110px 0
}

.head{
display:flex;
justify-content:space-between;
align-items:end;
gap:40px;
margin-bottom:42px
}

.head h2,
.story h2,
.cta h2{
font-size:clamp(44px,5.4vw,76px);
line-height:.94;
letter-spacing:-.065em;
margin:12px 0 0
}

.head p,
.story p,
.cta p{
color:var(--muted);
max-width:470px;
font-size:17px;
line-height:1.6
}

.grid{
display:grid;
grid-template-columns:repeat(3,1fr);
border:1px solid var(--line);
border-radius:24px;
overflow:hidden
}

.item{
min-height:240px;
padding:30px;
background:var(--surface);
border-right:1px solid var(--line);
border-bottom:1px solid var(--line);
display:flex;
flex-direction:column;
justify-content:space-between;
transition:.25s
}

.item:nth-child(3n){
border-right:0
}

.item:nth-last-child(-n+3){
border-bottom:0
}

.item:hover{
background:var(--surface2);
transform:translateY(-3px)
}

.num{
color:var(--accent);
font-weight:900;
font-size:12px;
letter-spacing:.12em
}

.item h3{
font-size:22px;
margin:28px 0 8px
}

.item p{
margin:0;
color:var(--muted);
max-width:320px
}

.arrow{
align-self:flex-end;
color:var(--accent);
font-size:23px
}

.story{
display:grid;
grid-template-columns:.9fr 1.1fr;
gap:60px;
align-items:center
}

.story-art{
min-height:460px;
border:1px solid var(--line);
border-radius:30px;
background:var(--surface);
display:grid;
place-items:center;
overflow:hidden
}

.story-art .hero-art{
width:58%
}

.story p{
font-size:18px;
max-width:650px
}

.chips{
display:flex;
gap:9px;
flex-wrap:wrap;
margin-top:28px
}

.chip{
border:1px solid var(--line);
background:var(--surface);
color:var(--muted);
padding:9px 12px;
border-radius:999px;
font-size:13px
}

.cta{
padding:90px 0
}

.cta-box{
padding:62px;
border:1px solid var(--line);
border-radius:34px;
background:var(--surface)
}

.cta h2{
max-width:900px
}

footer{
border-top:1px solid var(--line);
padding:30px 0 50px;
color:var(--muted);
font-size:13px;
display:flex;
justify-content:space-between;
gap:20px
}

__ADAPTIVE_CSS__

@media(max-width:900px){

.hero,
.story{
grid-template-columns:1fr
}

.grid{
grid-template-columns:1fr 1fr
}

.links{
display:none
}

.navcta{
display:none
}

.hero-frame{
min-height:440px
}

}

@media(max-width:600px){

.wrap{
width:calc(100% - 24px)
}

.hero{
padding:48px 0;
min-height:auto
}

h1{
font-size:clamp(52px,15vw,78px)
}

.lead{
font-size:17px
}

.hero-frame{
min-height:350px;
border-radius:24px
}

.section{
padding:75px 0
}

.head{
display:block
}

.head p{
margin-top:22px
}

.grid{
grid-template-columns:1fr
}

.item,
.item:nth-child(3n),
.item:nth-last-child(-n+3){
border-right:0;
border-bottom:1px solid var(--line)
}

.item:last-child{
border-bottom:0
}

.story-art{
min-height:330px
}

.cta-box{
padding:38px 24px;
border-radius:24px
}

footer{
display:block
}

footer span{
display:block;
margin-top:8px
}

}

</style>
</head>

<body>

<nav class="nav">
<div class="wrap navin">

<a class="brand" href="#top">
<span class="mark">__INITIAL__</span>
<span>__NAME__</span>
</a>

<div class="links">
<a href="#offer">__NAV__</a>
<a href="#story">About</a>
<a href="#visit">Visit</a>
</div>

<a class="navcta" href="#visit">__LABEL__</a>

</div>
</nav>

<main id="top" class="site-shell __STRATEGY_CLASSES__">

<section class="wrap hero">

<div>

<div class="eyebrow">__EYEBROW__</div>

<h1>__HEADLINE__</h1>

<p class="lead">__SUB__</p>

<div class="actions">

<a class="btn primary" href="#offer">
__CTA__ →
</a>

<a class="btn ghost" href="#story">
__SECONDARY__
</a>

</div>

<div class="micro">
A category-specific website experience for
<strong>__NAME__</strong>.
</div>

</div>

<div class="hero-frame">

<div class="art-label">
__CATEGORY_UP__ / DETAIL / EXPERIENCE
</div>

__ART__

</div>

</section>

<section class="section" id="offer">

<div class="wrap">

<div class="head">

<div>

<div class="kicker">
__SECTION_UP__
</div>

<h2>
__SECTION__, thoughtfully presented.
</h2>

</div>

<p>
Clear choices, useful information and a visual experience shaped around what customers actually come here for.
</p>

</div>

<div class="grid">
__ITEMS__
</div>

</div>

</section>

<section class="section" id="story">

<div class="wrap story">

<div class="story-art">
__ART__
</div>

<div>

<div class="kicker">
THE EXPERIENCE
</div>

<h2>
__ABOUT_TITLE__
</h2>

<p>
__ABOUT_TEXT__
</p>

<div class="chips">

<span class="chip">
Category-specific design
</span>

<span class="chip">
Mobile responsive
</span>

<span class="chip">
Single local HTML
</span>

</div>

</div>

</div>

</section>

<section class="cta" id="visit">

<div class="wrap">

<div class="cta-box">

<div class="kicker">
READY WHEN YOU ARE
</div>

<h2>
Make the next step feel easy.
</h2>

<p>
When real business details are available, this area can hold the actual address, phone, booking link, ordering flow or social links. Nothing has been invented.
</p>

<div class="actions">

<a class="btn primary" href="#top">
__CTA__ →
</a>

<a class="btn ghost" href="#offer">
Explore __NAV_LOWER__
</a>

</div>

</div>

</div>

</section>

</main>

<footer class="wrap">

<span>
© __NAME__. Built for a clear customer experience.
</span>

<span>
Local-first • No external assets • Responsive
</span>

</footer>

<script>

const items=document.querySelectorAll('.item');

const obs=new IntersectionObserver(
es=>es.forEach(
e=>e.isIntersecting&&(
e.target.style.opacity='1',
e.target.style.transform='none'
)
),
{threshold:.08}
);

items.forEach(e=>{
e.style.opacity='0';
e.style.transform='translateY(14px)';
e.style.transition='.6s ease';
obs.observe(e)
});

</script>

</body>
</html>'''

    vals = {
        '__NAME__': esc(name),
        '__CATEGORY__': category.title(),
        '__SUB__': esc(plan['sub']),

        '__BG__': t['bg'],
        '__SURFACE__': t['surface'],
        '__SURFACE2__': t['surface2'],
        '__TEXT__': t['text'],
        '__MUTED__': t['muted'],
        '__ACCENT__': t['accent'],
        '__ACCENT2__': t['accent2'],
        '__LINE__': t['line'],

        '__INITIAL__': esc(name[:1].upper()),
        '__NAV__': nav,
        '__NAV_LOWER__': nav.lower(),
        '__LABEL__': esc(label),

        '__EYEBROW__': esc(plan['eyebrow']),
        '__HEADLINE__': esc(plan['headline']),
        '__CTA__': esc(plan['cta']),
        '__SECONDARY__': esc(plan['secondary']),

        '__CATEGORY_UP__': category.upper(),

        '__ART__': svg(category),

        '__SECTION_UP__': esc(plan['section'].upper()),
        '__SECTION__': esc(plan['section']),

        '__ITEMS__': items,

        '__ABOUT_TITLE__': esc(ABOUT_TITLE[category]),
        '__ABOUT_TEXT__': esc(ABOUT_TEXT[category]),

        '__STRATEGY_CLASSES__': strategy_classes,
        '__ADAPTIVE_CSS__': adaptive_css
    }

    for k, v in vals.items():
        template = template.replace(k, v)

    return template

def validate_website_html(text):
    low=text.lower(); req=['<!doctype html','<html','<head','<body','</html>','<style>','<script>']; miss=[x for x in req if x not in low]
    if miss:return False,'Missing required markers: '+', '.join(miss)
    forbidden=['<img','background-image','<iframe','<video','<audio','<link','@import']
    hits=[x for x in forbidden if x in low]
    if re.search(r'https?://(?!www\.w3\.org/)', low): hits.append('external URL')
    if hits:return False,'Forbidden external/asset features: '+', '.join(hits)
    return True,''

def save_html(content,filename='shaqs_website.html'):
    out=WEBSITES_DIR/Path(str(filename or 'shaqs_website.html')).name
    if out.suffix.lower()!='.html':out=out.with_suffix('.html')
    out.write_text(str(content),encoding='utf-8');return out

def create_website(request,filename='shaqs_website.html'):
    if not str(request).strip():return 'Website creation failed: empty request.'
    request=str(request).strip();category=detect_category(request);name=extract_name(request,category)
    print('\n'+'='*64);print('SHAQS WEBSITE BUILDER V11');print('='*64);print(f'Business: {name}');print(f'Category: {category}')
    strategy = get_design_strategy(category, request)
    print(f"Layout strategy: {strategy['layout']}")
    print(f"Hero strategy: {strategy['hero']}")
    print(f"Content strategy: {strategy['content']}")
    print(f"Visual strategy: {strategy['visual']}")
    print(f"CTA strategy: {strategy['cta']}")
    print('Stage 1/4: understanding the business...');plan=plan_with_ai(request,category,name)
    print('Stage 2/4: creating category-specific design plan...');print('Stage 3/4: rendering premium website...')
    html=render(plan,name,category,request);print('Stage 4/4: deterministic quality control...')
    ok,err=validate_website_html(html)
    if not ok:return 'Website creation failed quality validation: '+err
    out=save_html(html,filename)
    try:webbrowser.open(out.resolve().as_uri())
    except Exception:pass
    print('WEBSITE CREATED SUCCESSFULLY');print(f'File: {out.resolve()}');print('='*64)
    return f'Website created successfully at: {out.resolve()}'

def build_website(request,filename='shaqs_website.html'):return create_website(request,filename)
def create_html(content,filename='shaqs_website.html'):
    s=str(content or '').lstrip()
    return save_html(s,filename) if s.lower().startswith('<!doctype html') else create_website(s,filename)

if __name__=='__main__':print(create_website('Build a website for a coffee shop named KOPIEEE'))
