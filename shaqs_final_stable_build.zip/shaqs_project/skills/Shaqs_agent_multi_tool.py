import json
import re
import sqlite3
import webbrowser
from datetime import datetime
from pathlib import Path

from ollama import chat

from skills.file_manager import (
    create_file,
    create_folder,
    list_files,
    read_file,
)

from skills.website_builder import create_html


# ============================================================
# CONFIGURATION
# ============================================================

DB_NAME = "memory.db"
MODEL = "qwen2.5-coder:7b"

WEBSITE_FILENAME = "shaqs_website.html"

MAX_WEBSITE_REPAIR_ATTEMPTS = 3


# ============================================================
# MEMORY
# ============================================================

def _ensure_memory_table():
    connection = sqlite3.connect(DB_NAME)

    connection.execute(
        """
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            memory TEXT NOT NULL
        )
        """
    )

    connection.commit()
    connection.close()


def get_memories():
    """Return all saved long-term memories."""

    try:
        _ensure_memory_table()

        connection = sqlite3.connect(DB_NAME)

        rows = connection.execute(
            "SELECT memory FROM memories ORDER BY id"
        ).fetchall()

        connection.close()

        return [row[0] for row in rows]

    except Exception:
        return []


def get_memory():
    """Return all saved long-term memories."""

    memories = get_memories()

    if not memories:
        return "No long-term memories are currently saved."

    return "\n".join(
        f"{index}. {memory}"
        for index, memory in enumerate(memories, 1)
    )


def save_memory(memory=None, key=None, value=None):
    """
    Save useful long-term information.

    Supports:

        save_memory(memory="...")

    and model-generated formats such as:

        save_memory(key="...", value="...")
    """

    if memory is not None:
        memory = str(memory).strip()

    elif key is not None and value is not None:
        memory = (
            f"{str(key).strip()}: "
            f"{str(value).strip()}"
        )

    elif key is not None:
        memory = str(key).strip()

    elif value is not None:
        memory = str(value).strip()

    else:
        return "Memory was empty; nothing was saved."

    if not memory:
        return "Memory was empty; nothing was saved."

    _ensure_memory_table()

    connection = sqlite3.connect(DB_NAME)

    connection.execute(
        "INSERT INTO memories (memory) VALUES (?)",
        (memory,),
    )

    connection.commit()
    connection.close()

    return f"Memory saved: {memory}"


def forget_memory(memory=None, key=None, value=None):
    """Forget memories matching supplied text."""

    search_text = memory or key or value

    if not search_text:
        return "Please provide the memory text to forget."

    search_text = str(search_text).strip()

    _ensure_memory_table()

    connection = sqlite3.connect(DB_NAME)

    cursor = connection.execute(
        "DELETE FROM memories WHERE memory LIKE ?",
        (f"%{search_text}%",),
    )

    deleted = cursor.rowcount

    connection.commit()
    connection.close()

    if deleted:
        return f"Forgot {deleted} matching memory/memories."

    return "No matching memory was found."


# ============================================================
# BASIC TOOLS
# ============================================================

def get_time():
    """Get the current local computer time."""

    return datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )


# ============================================================
# WEBSITE HTML UTILITIES
# ============================================================

def clean_markdown_fences(html):
    """
    Remove Markdown code fences accidentally returned by the model.
    """

    if not html:
        return ""

    html = str(html).strip()

    if html.startswith("```html"):
        html = html[7:].strip()

    elif html.startswith("```HTML"):
        html = html[7:].strip()

    elif html.startswith("```"):
        html = html[3:].strip()

    if html.endswith("```"):
        html = html[:-3].strip()

    return html


def extract_html_document(html):
    """
    Extract the actual HTML document if the model adds
    explanations before the document.
    """

    html = clean_markdown_fences(html)

    doctype_position = html.lower().find(
        "<!doctype html"
    )

    if doctype_position >= 0:
        html = html[doctype_position:]

    return html.strip()


def validate_basic_html(html):
    """
    Validate the minimum HTML document structure.
    """

    if not html:
        return (
            False,
            "The generated HTML is empty."
        )

    lowered = html.lower()

    required_markers = [
        "<!doctype html",
        "<html",
        "<head",
        "<body",
        "</html>",
    ]

    missing = [
        marker
        for marker in required_markers
        if marker not in lowered
    ]

    if missing:
        return (
            False,
            "Missing required HTML markers: "
            + ", ".join(missing)
        )

    return True, ""


def normalize_html_for_asset_validation(html):
    """
    Prepare HTML for asset validation.

    IMPORTANT:

    Inline SVG is allowed.

    Therefore this legitimate namespace:

        xmlns="http://www.w3.org/2000/svg"

    must NOT be interpreted as an external website asset.

    We remove only the known-safe SVG namespace before checking
    for forbidden HTTP/HTTPS resources.
    """

    if not html:
        return ""

    normalized = str(html)

    normalized = re.sub(
        r"""
        xmlns
        \s*=\s*
        ["']
        http://www\.w3\.org/2000/svg
        ["']
        """,
        "",
        normalized,
        flags=re.IGNORECASE | re.VERBOSE,
    )

    normalized = re.sub(
        r"""
        xmlns
        \s*=\s*
        ["']
        https://www\.w3\.org/2000/svg
        ["']
        """,
        "",
        normalized,
        flags=re.IGNORECASE | re.VERBOSE,
    )

    return normalized


def find_forbidden_website_assets(html):
    """
    Return a list of forbidden external/image asset patterns.

    Shaqs websites are intentionally self-contained.

    Allowed:
        - HTML
        - CSS
        - vanilla JavaScript
        - inline SVG
        - CSS gradients
        - CSS shapes
        - inline icons
        - SVG namespace declarations

    Forbidden:
        - img
        - external image URLs
        - local image files
        - background-image
        - CSS url()
        - external CSS
        - external JavaScript
        - external fonts
        - iframe/embed/object
        - video/audio assets
        - remote asset references
    """

    validation_html = normalize_html_for_asset_validation(
        html
    )

    lowered = validation_html.lower()

    violations = []

    # --------------------------------------------------------
    # IMAGE ELEMENTS
    # --------------------------------------------------------

    if re.search(
        r"<\s*img\b",
        lowered,
        re.IGNORECASE,
    ):
        violations.append(
            "The page contains an <img> element."
        )

    # --------------------------------------------------------
    # IMAGE SOURCE ELEMENTS
    # --------------------------------------------------------

    if re.search(
        r"<\s*(picture|source)\b",
        lowered,
        re.IGNORECASE,
    ):
        violations.append(
            "The page contains picture/source media elements."
        )

    # --------------------------------------------------------
    # BACKGROUND IMAGE
    # --------------------------------------------------------

    if re.search(
        r"background-image\s*:",
        lowered,
        re.IGNORECASE,
    ):
        violations.append(
            "The page contains a background-image declaration."
        )

    # --------------------------------------------------------
    # CSS URL
    # --------------------------------------------------------

    if re.search(
        r"url\s*\(",
        lowered,
        re.IGNORECASE,
    ):
        violations.append(
            "The page contains CSS url(...) references."
        )

    # --------------------------------------------------------
    # IMAGE FILE EXTENSIONS
    # --------------------------------------------------------

    image_extensions = [
        ".jpg",
        ".jpeg",
        ".png",
        ".webp",
        ".gif",
        ".avif",
        ".bmp",
        ".ico",
        ".tiff",
    ]

    for extension in image_extensions:

        if extension in lowered:

            violations.append(
                f"The page contains a {extension} asset reference."
            )

    # --------------------------------------------------------
    # SVG FILE REFERENCES
    # --------------------------------------------------------

    if re.search(
        r"""
        (?:
            src
            |
            href
            |
            xlink:href
        )
        \s*=\s*
        ["']
        [^"']+\.svg
        (?:
            ["']
            |
            [?#]
        )
        """,
        lowered,
        re.IGNORECASE | re.VERBOSE,
    ):
        violations.append(
            "The page contains an external/local SVG file reference."
        )

    # --------------------------------------------------------
    # EXTERNAL HTTP/HTTPS RESOURCES
    # --------------------------------------------------------

    external_url_patterns = [
        r"https?://",
        r"//cdn\.",
        r"//fonts\.",
        r"//www\.",
    ]

    for pattern in external_url_patterns:

        if re.search(
            pattern,
            lowered,
            re.IGNORECASE,
        ):
            violations.append(
                "The page contains an external URL."
            )
            break

    # --------------------------------------------------------
    # EXTERNAL CSS
    # --------------------------------------------------------

    if re.search(
        r"<\s*link\b",
        lowered,
        re.IGNORECASE,
    ):
        violations.append(
            "The page contains a <link> element."
        )

    # --------------------------------------------------------
    # EXTERNAL / EMBEDDED DOCUMENTS
    # --------------------------------------------------------

    for tag in [
        "iframe",
        "embed",
        "object",
        "frame",
        "frameset",
    ]:

        if re.search(
            rf"<\s*{tag}\b",
            lowered,
            re.IGNORECASE,
        ):
            violations.append(
                f"The page contains a <{tag}> element."
            )

    # --------------------------------------------------------
    # MEDIA ELEMENTS
    # --------------------------------------------------------

    for tag in [
        "video",
        "audio",
        "track",
    ]:

        if re.search(
            rf"<\s*{tag}\b",
            lowered,
            re.IGNORECASE,
        ):
            violations.append(
                f"The page contains a <{tag}> media element."
            )

    # --------------------------------------------------------
    # EXTERNAL FONT IMPORTS
    # --------------------------------------------------------

    if re.search(
        r"@import\b",
        lowered,
        re.IGNORECASE,
    ):
        violations.append(
            "The page contains an @import rule."
        )

    if re.search(
        r"@import\s+url",
        lowered,
        re.IGNORECASE,
    ):
        violations.append(
            "The page contains an external CSS import."
        )

    if re.search(
        r"fonts\.googleapis\.com",
        lowered,
        re.IGNORECASE,
    ):
        violations.append(
            "The page contains an external Google Fonts reference."
        )

    if re.search(
        r"fonts\.gstatic\.com",
        lowered,
        re.IGNORECASE,
    ):
        violations.append(
            "The page contains an external Google Fonts asset."
        )

    # --------------------------------------------------------
    # REMOTE ASSET ATTRIBUTES
    # --------------------------------------------------------

    if re.search(
        r"""
        (?:
            src
            |
            href
            |
            action
            |
            poster
            |
            data
        )
        \s*=\s*
        ["']
        (?:
            https?:|
            //
        )
        """,
        lowered,
        re.IGNORECASE | re.VERBOSE,
    ):
        violations.append(
            "The page contains a remote resource reference."
        )

    # --------------------------------------------------------
    # DUPLICATE REMOVAL
    # --------------------------------------------------------

    unique_violations = []

    for violation in violations:

        if violation not in unique_violations:
            unique_violations.append(
                violation
            )

    return unique_violations


def replace_img_elements_with_svg(html):
    """
    Deterministically replace <img> elements with a small
    inline SVG placeholder.

    This is a safety net after the AI repair step.

    It does NOT download anything.
    It does NOT reference any external file.

    IMPORTANT:

    The SVG intentionally does not include an external
    namespace URL so that the fallback itself can never
    trigger the external URL validator.
    """

    pattern = re.compile(
        r"<\s*img\b[^>]*>",
        re.IGNORECASE,
    )

    replacement = """
<svg
    class="inline-visual"
    viewBox="0 0 320 180"
    role="img"
    aria-label="Decorative visual"
>
    <rect
        x="0"
        y="0"
        width="320"
        height="180"
        rx="18"
        fill="currentColor"
        opacity="0.08"
    ></rect>

    <path
        d="M70 130 L125 75 L165 112 L195 82 L250 140 Z"
        fill="currentColor"
        opacity="0.22"
    ></path>

    <circle
        cx="105"
        cy="65"
        r="16"
        fill="currentColor"
        opacity="0.25"
    ></circle>
</svg>
""".strip()

    return pattern.sub(
        replacement,
        html,
    )


def remove_forbidden_media_elements(html):
    """
    Remove media elements that cannot be safely converted
    deterministically.
    """

    # --------------------------------------------------------
    # REMOVE COMPLETE PAIRED ELEMENTS
    # --------------------------------------------------------

    paired_tags = [
        "picture",
        "video",
        "audio",
        "object",
        "embed",
        "iframe",
        "frame",
        "frameset",
    ]

    for tag in paired_tags:

        html = re.sub(
            rf"<\s*{tag}\b[^>]*>.*?<\s*/\s*{tag}\s*>",
            "",
            html,
            flags=re.IGNORECASE | re.DOTALL,
        )

        # Also remove self-closing/open-only versions.
        html = re.sub(
            rf"<\s*{tag}\b[^>]*\/?>",
            "",
            html,
            flags=re.IGNORECASE,
        )

    # --------------------------------------------------------
    # REMOVE SOURCE / TRACK
    # --------------------------------------------------------

    for tag in [
        "source",
        "track",
    ]:

        html = re.sub(
            rf"<\s*{tag}\b[^>]*\/?>",
            "",
            html,
            flags=re.IGNORECASE,
        )

    return html


def remove_external_stylesheets(html):
    """
    Remove external stylesheet link elements.

    Internal CSS in <style> remains untouched.
    """

    return re.sub(
        r"""
        <\s*link\b
        [^>]*>
    """,
        "",
        html,
        flags=re.IGNORECASE | re.VERBOSE,
    )


def remove_css_external_imports(html):
    """
    Remove @import statements.

    Shaqs websites use self-contained CSS.
    """

    return re.sub(
        r"""
        @import
        [^;]+;
    """,
        "",
        html,
        flags=re.IGNORECASE | re.VERBOSE,
    )


def remove_background_image_declarations(html):
    """
    Remove forbidden background-image declarations.

    The surrounding CSS remains intact.
    """

    return re.sub(
        r"""
        background-image
        \s*:
        [^;{}]*
        ;
    """,
        "",
        html,
        flags=re.IGNORECASE | re.VERBOSE,
    )


def deterministic_website_cleanup(html):
    """
    Final deterministic cleanup.

    The AI should generate valid self-contained HTML itself,
    but this provides a last safety layer.

    Cleanup order:

        1. Remove <img> elements.
        2. Remove forbidden media.
        3. Remove external stylesheet links.
        4. Remove CSS imports.
        5. Remove background-image declarations.
    """

    html = replace_img_elements_with_svg(
        html
    )

    html = remove_forbidden_media_elements(
        html
    )

    html = remove_external_stylesheets(
        html
    )

    html = remove_css_external_imports(
        html
    )

    html = remove_background_image_declarations(
        html
    )

    return html


def validate_website_html(html):
    """
    Complete website validation.

    Returns:

        (True, "")

    or:

        (False, reason)
    """

    basic_valid, basic_error = validate_basic_html(
        html
    )

    if not basic_valid:
        return False, basic_error

    violations = find_forbidden_website_assets(
        html
    )

    if violations:

        return (
            False,
            " ".join(violations)
        )

    return True, ""


# ============================================================
# WEBSITE REPAIR
# ============================================================

def repair_website_html(html, validation_error, attempt):
    """
    Ask the local model to repair invalid website HTML.
    """

    repair_prompt = f"""
You are repairing a website generated by Shaqs.

This is repair attempt {attempt}.

The generated HTML failed validation because:

{validation_error}

============================================================
ABSOLUTE REQUIREMENTS
============================================================

Return ONLY the complete corrected HTML document.

Do NOT return Markdown.

Do NOT explain anything.

The document MUST begin with:

<!DOCTYPE html>

The document MUST contain:

<html>
<head>
<body>
</html>

============================================================
SELF-CONTAINED WEBSITE REQUIREMENT
============================================================

This website MUST work completely from a local .html file.

Therefore you MUST NOT use:

- <img>
- <picture>
- <source>
- <video>
- <audio>
- <iframe>
- <embed>
- <object>
- <frame>
- <frameset>
- background-image
- url(...)
- http://
- https://
- //cdn...
- external images
- local image files
- .jpg
- .jpeg
- .png
- .webp
- .gif
- .avif
- external .svg files
- external CSS
- <link>
- external JavaScript
- external fonts
- Google Fonts
- Font Awesome CDN
- Bootstrap CDN
- Tailwind CDN
- icon CDNs
- analytics scripts
- tracking scripts
- any remote asset

DO NOT generate an <img> element under any circumstance.

============================================================
VISUAL ASSETS
============================================================

If the design needs images or visual elements, use:

- Inline SVG
- CSS gradients
- CSS shapes
- CSS illustrations
- Inline icons
- Decorative patterns
- Typography
- Tasteful emoji

Inline SVG is explicitly allowed.

An SVG written directly inside the HTML is allowed.

For example:

<svg viewBox="0 0 100 100">
    <circle cx="50" cy="50" r="40"></circle>
</svg>

The SVG may optionally contain:

xmlns="http://www.w3.org/2000/svg"

This namespace is legitimate for inline SVG and is NOT an
external asset.

But:

<img src="something.svg">

is NOT allowed.

============================================================
PRESERVE THE WEBSITE
============================================================

Keep:

- the same business
- the same business name
- the same overall concept
- the same useful content
- the same sections where possible
- the same professional quality

Only change what is necessary to make the website
fully self-contained and valid.

If an image was used, replace it with:

- inline SVG
- CSS artwork
- gradient artwork
- an elegant decorative shape

Do NOT replace an image with another image URL.

============================================================
DESIGN
============================================================

The result must remain:

- premium
- professional
- responsive
- visually polished
- modern
- accessible
- mobile friendly

Navigation must remain properly styled.

Cards must remain properly styled.

Buttons must remain properly styled.

Do not turn the website into plain unstyled HTML.

============================================================
FINAL CHECK
============================================================

Before returning the HTML, verify internally:

1. No <img> exists.
2. No <picture> exists.
3. No <source> exists.
4. No background-image exists.
5. No url(...) exists.
6. No external HTTP/HTTPS resources exist.
7. No external CSS exists.
8. No external JavaScript exists.
9. No external fonts exist.
10. No .jpg exists.
11. No .jpeg exists.
12. No .png exists.
13. No .webp exists.
14. No .gif exists.
15. No .avif exists.
16. No external .svg file exists.
17. No iframe exists.
18. No video exists.
19. No audio exists.
20. No object/embed exists.
21. No external stylesheet exists.
22. No external JavaScript exists.
23. CSS is inside <style>.
24. JavaScript is inside <script>.
25. The result is valid complete HTML.
26. Inline SVG is allowed.
27. The legitimate SVG namespace is allowed.

Return ONLY the HTML.

============================================================
HTML TO REPAIR
============================================================

{html}
"""

    try:

        response = chat(
            model=MODEL,
            messages=[
                {
                    "role": "user",
                    "content": repair_prompt,
                }
            ],
        )

        repaired = (
            response.message.content or ""
        ).strip()

        repaired = extract_html_document(
            repaired
        )

        return repaired

    except Exception as e:

        print(
            f"[ Website repair error: {e} ]"
        )

        return html


# ============================================================
# AI WEBSITE BUILDER
# ============================================================

def create_website(request):
    """
    Generate a complete professional self-contained website,
    validate it, repair it when necessary, save it, and open it.
    """

    website_prompt = f"""
You are the senior creative director, UX designer,
UI designer, copywriter, and front-end developer
for Shaqs, a premium AI website builder.

The user wants this website:

{request}

============================================================
YOUR JOB
============================================================

Understand the user's request first.

Determine:

1. What type of website/business this is.
2. Who the target audience is.
3. What the main conversion/action should be.
4. What visual style fits the business.
5. Which sections and features are appropriate.

Then create the complete website.

Do NOT create a generic template if the business clearly
needs something more specific.

============================================================
DESIGN QUALITY
============================================================

The website must look like a professionally designed
real-world website.

Use:

- Strong visual hierarchy
- Excellent spacing
- Premium typography
- Beautiful cards
- Modern buttons
- Subtle shadows
- Gradients where appropriate
- Smooth transitions
- Micro-interactions
- Scroll animations
- Responsive layouts
- Strong CTA placement
- Consistent design system
- Professional color palette

============================================================
SELF-CONTAINED WEBSITE
============================================================

CRITICAL:

The website will be saved as a local HTML file and opened
directly in the user's browser.

It MUST work without internet access.

Therefore DO NOT use:

- <img>
- <picture>
- <source>
- background-image
- url(...)
- http://
- https://
- external images
- local image files
- .jpg
- .jpeg
- .png
- .webp
- .gif
- .avif
- external .svg files
- external CSS
- <link>
- external JavaScript
- external fonts
- Google Fonts
- Font Awesome CDN
- Bootstrap CDN
- Tailwind CDN
- icon CDNs
- analytics
- tracking scripts
- iframes
- video assets
- audio assets
- object/embed resources

DO NOT generate an <img> element under any circumstance.

============================================================
VISUAL ASSETS
============================================================

If the design needs images or visual elements, use:

- Inline SVG
- CSS gradients
- CSS shapes
- CSS illustrations
- Inline icons
- Decorative patterns
- Typography
- Tasteful emoji

Inline SVG is explicitly allowed.

Example:

<svg
    viewBox="0 0 100 100"
    aria-hidden="true"
    xmlns="http://www.w3.org/2000/svg"
>
    <circle
        cx="50"
        cy="50"
        r="40"
    ></circle>
</svg>

The SVG is embedded directly in the HTML.

DO NOT use:

<img src="...">

============================================================
STRUCTURE
============================================================

Choose sections intelligently.

Possible sections:

- Navigation
- Hero
- Trust indicators
- Statistics
- Products
- Services
- Features
- About
- Gallery
- Portfolio
- Testimonials
- Pricing
- FAQ
- Contact
- CTA
- Footer

Do NOT force every section onto every website.

============================================================
FUNCTIONALITY
============================================================

Use vanilla JavaScript where useful.

Examples:

- Mobile menu
- Smooth scrolling
- FAQ accordion
- Tabs
- Filters
- Search UI
- Booking UI
- Contact form validation
- Newsletter form
- Modal dialogs
- Pricing toggle
- Gallery interactions
- Scroll reveal animations
- Back-to-top button

All front-end interactions must work.

Do not create fake backend functionality.

If something requires a backend, make it a polished
front-end demonstration.

============================================================
NAVIGATION
============================================================

Create a professional navigation bar.

It must NOT appear as default browser bullets.

Use flexbox or grid.

Include:

- Brand/logo
- Navigation links
- Active state
- CTA where appropriate
- Mobile hamburger menu

Navigation links must point to real sections.

Use smooth scrolling.

============================================================
RESPONSIVE DESIGN
============================================================

The website must work on:

- Desktop
- Laptop
- Tablet
- Mobile

Use media queries.

Ensure:

- Navigation works on mobile
- Cards stack correctly
- Text scales correctly
- Buttons remain usable
- Forms fit small screens
- No unwanted horizontal scrolling

============================================================
ACCESSIBILITY
============================================================

Use:

- Semantic HTML
- Proper heading hierarchy
- Labels for inputs
- Accessible buttons
- Meaningful links
- Good contrast
- ARIA attributes where appropriate
- Keyboard-friendly interactions

============================================================
CONTENT
============================================================

Write realistic polished website copy.

Do NOT use:

- Lorem ipsum
- Placeholder names
- "Your Company Here"
- "Insert text here"
- "Image goes here"

If the user provides a business name,
use it consistently.

If information is missing:

- Make sensible assumptions
- Keep claims generic
- Do not invent certifications
- Do not invent addresses
- Do not invent phone numbers
- Do not invent customer counts
- Do not invent awards

============================================================
FINAL QUALITY CHECK
============================================================

Before returning the HTML, verify:

- <!DOCTYPE html> exists
- <html> exists
- <head> exists
- <body> exists
- </html> exists
- CSS is included
- JavaScript is included when useful
- Navigation is styled
- Buttons are styled
- Sections are coherent
- Mobile layout works
- No <img> exists
- No <picture> exists
- No <source> exists
- No background-image exists
- No url(...) exists
- No external resource URLs exist
- No external CSS exists
- No <link> exists
- No external JavaScript exists
- No external fonts exist
- No .jpg exists
- No .jpeg exists
- No .png exists
- No .webp exists
- No .gif exists
- No .avif exists
- No external .svg file exists
- No iframe exists
- No video exists
- No audio exists
- No object exists
- No embed exists
- No Markdown fences exist
- No Lorem ipsum exists

Inline SVG is allowed.

The legitimate inline SVG namespace is allowed:

xmlns="http://www.w3.org/2000/svg"

Return ONLY the final HTML document.

DO NOT return an explanation.

DO NOT return Markdown.

DO NOT return ```html.

============================================================
USER WEBSITE REQUEST
============================================================

{request}
"""

    try:

        print(
            "\n[ Shaqs website generator: generating website... ]"
        )

        response = chat(
            model=MODEL,
            messages=[
                {
                    "role": "user",
                    "content": website_prompt,
                }
            ],
        )

        website_html = (
            response.message.content or ""
        ).strip()

        website_html = extract_html_document(
            website_html
        )

        # ----------------------------------------------------
        # DETERMINISTIC CLEANUP BEFORE INITIAL VALIDATION
        # ----------------------------------------------------

        website_html = deterministic_website_cleanup(
            website_html
        )

        website_html = extract_html_document(
            website_html
        )

        # ----------------------------------------------------
        # INITIAL VALIDATION
        # ----------------------------------------------------

        valid, error = validate_website_html(
            website_html
        )

        # ----------------------------------------------------
        # REPAIR LOOP
        # ----------------------------------------------------

        attempt = 0

        while (
            not valid
            and attempt < MAX_WEBSITE_REPAIR_ATTEMPTS
        ):

            attempt += 1

            print(
                "[ Shaqs website generator: "
                f"repairing invalid HTML "
                f"(attempt {attempt}/"
                f"{MAX_WEBSITE_REPAIR_ATTEMPTS})... ]"
            )

            website_html = repair_website_html(
                website_html,
                error,
                attempt,
            )

            website_html = extract_html_document(
                website_html
            )

            # ------------------------------------------------
            # CLEAN AGAIN AFTER AI REPAIR
            # ------------------------------------------------

            website_html = deterministic_website_cleanup(
                website_html
            )

            website_html = extract_html_document(
                website_html
            )

            valid, error = validate_website_html(
                website_html
            )

        # ----------------------------------------------------
        # FINAL DETERMINISTIC SAFETY CLEANUP
        # ----------------------------------------------------

        if not valid:

            print(
                "[ Website generator: applying "
                "deterministic asset cleanup... ]"
            )

            website_html = (
                deterministic_website_cleanup(
                    website_html
                )
            )

            website_html = extract_html_document(
                website_html
            )

            valid, error = validate_website_html(
                website_html
            )

        # ----------------------------------------------------
        # FINAL VALIDATION
        # ----------------------------------------------------

        if not valid:

            print(
                "[ Shaqs website generator: "
                f"final validation failed: {error} ]"
            )

            return (
                "Website creation failed quality validation: "
                f"{error}"
            )

        # ----------------------------------------------------
        # SAVE
        # ----------------------------------------------------

        output_file = create_html(
            website_html,
            WEBSITE_FILENAME,
        )

        print(
            f"[ Website saved: {output_file} ]"
        )

        # ----------------------------------------------------
        # OPEN IN BROWSER
        # ----------------------------------------------------

        try:

            webbrowser.open(
                output_file.resolve().as_uri()
            )

        except Exception as e:

            print(
                f"[ Browser could not be opened: {e} ]"
            )

        return (
            "Website created successfully at: "
            f"{output_file}"
        )

    except Exception as e:

        return (
            f"Website creation failed: {e}"
        )


# ============================================================
# WORKSPACE
# ============================================================

def _workspace_root():
    """Return the Shaqs workspace directory."""

    root = (
        Path(__file__).resolve().parent.parent
        / "workspace"
    )

    root.mkdir(
        parents=True,
        exist_ok=True,
    )

    return root


def _safe_workspace_path(name):
    """Safely resolve a path inside the workspace."""

    root = _workspace_root().resolve()

    candidate = (
        root / str(name)
    ).resolve()

    try:

        candidate.relative_to(root)

    except ValueError:

        raise ValueError(
            "Path must stay inside the Shaqs workspace."
        )

    return candidate


def edit_file(filename, content):
    """Replace contents of an existing workspace file."""

    path = _safe_workspace_path(filename)

    if not path.exists():
        return f"File not found: {path}"

    if not path.is_file():
        return f"Not a file: {path}"

    path.write_text(
        str(content),
        encoding="utf-8",
    )

    return f"File updated: {path}"


def search_files(query, path="."):
    """Search text inside workspace files."""

    query = str(query).strip()

    if not query:
        return "Search query was empty."

    root = _safe_workspace_path(path)

    if not root.exists():
        return f"Path does not exist: {root}"

    matches = []

    ignored = {
        ".venv",
        "__pycache__",
        ".git",
    }

    for file in root.rglob("*"):

        if not file.is_file():
            continue

        if any(
            part in ignored
            for part in file.parts
        ):
            continue

        if file.name == "memory.db":
            continue

        try:

            text = file.read_text(
                encoding="utf-8",
                errors="ignore",
            )

        except Exception:

            continue

        if query.lower() in text.lower():

            hits = []

            for number, line in enumerate(
                text.splitlines(),
                1,
            ):

                if query.lower() in line.lower():

                    hits.append(
                        f"{number}: {line.strip()[:180]}"
                    )

                    if len(hits) >= 5:
                        break

            matches.append(
                f"{file.relative_to(root)}\n"
                + "\n".join(
                    f"  {hit}"
                    for hit in hits
                )
            )

    if matches:

        return "\n".join(matches)

    return (
        f'No files containing "{query}" were found.'
    )


def delete_path(path):
    """Delete a workspace file or folder safely."""

    import shutil

    target = _safe_workspace_path(path)

    root = _workspace_root().resolve()

    if target == root:

        return (
            "Refused to delete the entire Shaqs workspace."
        )

    if target == (
        root / "memory.db"
    ).resolve():

        return (
            "Refused to delete the memory database."
        )

    if not target.exists():

        return f"Path not found: {target}"

    if target.is_dir():

        shutil.rmtree(target)

        return f"Folder deleted: {target}"

    target.unlink()

    return f"File deleted: {target}"


# ============================================================
# TOOL DEFINITIONS
# ============================================================

tools = [

    {
        "type": "function",
        "function": {
            "name": "get_time",
            "description": (
                "Get the current local computer time."
            ),
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "create_file",
            "description": (
                "Create a file in the Shaqs workspace."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string",
                        "description": (
                            "Name of the file to create."
                        ),
                    },
                    "content": {
                        "type": "string",
                        "description": (
                            "Content to put inside the file."
                        ),
                    },
                },
                "required": ["filename"],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "create_folder",
            "description": (
                "Create a folder in the Shaqs workspace."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "foldername": {
                        "type": "string",
                    }
                },
                "required": ["foldername"],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "list_files",
            "description": (
                "List files and folders in the Shaqs workspace."
            ),
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": (
                "Read a file in the Shaqs workspace."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string",
                    }
                },
                "required": ["filename"],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "create_website",
            "description": (
                "Create a complete professional responsive "
                "self-contained website from a natural-language "
                "description. The website works as a local HTML "
                "file without external assets."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "request": {
                        "type": "string",
                        "description": (
                            "Description of the website "
                            "the user wants."
                        ),
                    }
                },
                "required": ["request"],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "edit_file",
            "description": (
                "Replace the contents of an existing "
                "workspace file."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {
                        "type": "string"
                    },
                    "content": {
                        "type": "string"
                    },
                },
                "required": [
                    "filename",
                    "content",
                ],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "search_files",
            "description": (
                "Search for text inside workspace files."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string"
                    },
                    "path": {
                        "type": "string"
                    },
                },
                "required": ["query"],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "delete_path",
            "description": (
                "Delete a file or folder in the workspace."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string"
                    }
                },
                "required": ["path"],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "save_memory",
            "description": (
                "Save useful long-term information about "
                "the user or their projects. Use the "
                "'memory' parameter for the complete fact."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "memory": {
                        "type": "string",
                        "description": (
                            "The complete memory to save."
                        ),
                    }
                },
                "required": ["memory"],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "get_memory",
            "description": (
                "Retrieve all saved long-term memories."
            ),
            "parameters": {
                "type": "object",
                "properties": {},
                "required": [],
            },
        },
    },

    {
        "type": "function",
        "function": {
            "name": "forget_memory",
            "description": (
                "Forget saved long-term memories matching "
                "the supplied text."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "memory": {
                        "type": "string"
                    }
                },
                "required": ["memory"],
            },
        },
    },
]


# ============================================================
# TOOL REGISTRY
# ============================================================

tool_functions = {

    "get_time": get_time,

    "create_file": create_file,

    "create_folder": create_folder,

    "list_files": list_files,

    "read_file": read_file,

    "create_website": create_website,

    "edit_file": edit_file,

    "search_files": search_files,

    "delete_path": delete_path,

    "save_memory": save_memory,

    "get_memory": get_memory,

    "forget_memory": forget_memory,
}


# ============================================================
# ARGUMENT NORMALIZATION
# ============================================================

def normalize_arguments(tool_name, arguments):
    """
    Normalize model-generated tool arguments.

    This protects Shaqs from small differences in
    argument naming produced by local models.
    """

    if not isinstance(arguments, dict):
        return {}

    arguments = dict(arguments)

    # --------------------------------------------------------
    # MEMORY
    # --------------------------------------------------------

    if tool_name in {
        "save_memory",
        "forget_memory",
    }:

        if "memory" not in arguments:

            if (
                tool_name == "save_memory"
                and "key" in arguments
                and "value" in arguments
            ):

                arguments["memory"] = (
                    f"{arguments['key']}: "
                    f"{arguments['value']}"
                )

            elif "value" in arguments:

                arguments["memory"] = (
                    arguments["value"]
                )

            elif "key" in arguments:

                arguments["memory"] = (
                    arguments["key"]
                )

        allowed = {
            "memory",
        }

        arguments = {
            key: value
            for key, value in arguments.items()
            if key in allowed
        }

    return arguments


# ============================================================
# TOOL REQUEST PARSER
# ============================================================

def parse_tool_requests(response):
    """Extract all official Ollama tool calls or JSON tool requests."""

    requests = []

    # --------------------------------------------------------
    # OFFICIAL OLLAMA TOOL CALLS
    # --------------------------------------------------------

    official_calls = getattr(response.message, "tool_calls", None) or []

    if official_calls:
        for tool_call in official_calls:
            arguments = tool_call.function.arguments

            if arguments is None:
                arguments = {}
            elif isinstance(arguments, str):
                try:
                    arguments = json.loads(arguments)
                except json.JSONDecodeError:
                    arguments = {}

            if not isinstance(arguments, dict):
                arguments = {}

            requests.append(
                (
                    tool_call.function.name,
                    arguments,
                )
            )

        return requests

    # --------------------------------------------------------
    # JSON TOOL REQUESTS RETURNED AS NORMAL TEXT
    # --------------------------------------------------------

    content = (
        response.message.content or ""
    ).strip()

    if not content:
        return requests

    if content.startswith("```json"):
        content = content[7:].strip()
    elif content.startswith("```"):
        content = content[3:].strip()

    if content.endswith("```"):
        content = content[:-3].strip()

    # First try a normal single JSON document.
    try:
        parsed = json.loads(content)

        if isinstance(parsed, dict) and "name" in parsed:
            arguments = parsed.get("arguments", {})
            if not isinstance(arguments, dict):
                arguments = {}

            requests.append(
                (
                    parsed["name"],
                    arguments,
                )
            )

            return requests

        if isinstance(parsed, list):
            for item in parsed:
                if not isinstance(item, dict) or "name" not in item:
                    continue

                arguments = item.get("arguments", {})
                if not isinstance(arguments, dict):
                    arguments = {}

                requests.append(
                    (
                        item["name"],
                        arguments,
                    )
                )

            if requests:
                return requests

    except json.JSONDecodeError:
        pass

    # --------------------------------------------------------
    # MULTIPLE JSON OBJECTS WITHOUT A JSON ARRAY
    #
    # Some local models emit:
    #
    # {"name":"edit_file", ...}
    # {"name":"read_file", ...}
    #
    # json.loads() rejects that because it contains two JSON
    # documents. JSONDecoder.raw_decode() lets us consume them
    # one after another.
    # --------------------------------------------------------

    decoder = json.JSONDecoder()
    position = 0
    length = len(content)

    while position < length:
        while position < length and content[position].isspace():
            position += 1

        if position >= length:
            break

        try:
            parsed, consumed = decoder.raw_decode(
                content,
                position,
            )
        except json.JSONDecodeError:
            break

        position = consumed

        if not isinstance(parsed, dict):
            continue

        if "name" not in parsed:
            continue

        arguments = parsed.get("arguments", {})

        if not isinstance(arguments, dict):
            arguments = {}

        requests.append(
            (
                parsed["name"],
                arguments,
            )
        )

    return requests


def parse_tool_request(response):
    """Backward-compatible helper returning the first tool request."""

    requests = parse_tool_requests(response)

    if requests:
        return requests[0]

    return None, {}


# ============================================================
# TOOL EXECUTION
# ============================================================

def execute_tool(
    tool_name,
    arguments,
):

    if tool_name not in tool_functions:

        return f"Unknown tool: {tool_name}"

    try:

        arguments = normalize_arguments(
            tool_name,
            arguments,
        )

        return str(
            tool_functions[tool_name](
                **arguments
            )
        )

    except Exception as e:

        return f"Tool error: {e}"


# ============================================================
# SYSTEM PROMPT
# ============================================================

def build_system_prompt():

    memories = get_memories()

    prompt = """
You are Shaqs, a personal AI assistant.

You are helpful, intelligent, honest and friendly.

You have access to the user's long-term memories
and real tools.

============================================================
MEMORY RULES
============================================================

Long-term memory is for information useful across
future conversations.

Examples:

- User's name
- Important preferences
- Ongoing projects
- Goals
- Persistent facts

Do NOT save:

- Ordinary conversation
- Temporary information
- Questions
- Greetings
- One-time instructions

If the user explicitly says:

- "remember this"
- "remember that"
- "save this"
- "save that"
- "store this"
- "store that"

use save_memory.

If the user explicitly asks you to forget something,
use forget_memory.

If the user asks:

"What do you remember about me?"

use get_memory.

Never invent memories.

============================================================
TOOL RULES
============================================================

- Use real tools when genuinely necessary.
- Never tell the user to manually execute a tool.
- Never show tool JSON to the user.
- Never pretend a tool ran when it did not.
- Trust the actual tool result.
- After a tool finishes, answer the original request normally.
- If a tool reports failure, report the failure honestly.
- Never claim success when the tool result says failure.

============================================================
AVAILABLE TOOLS
============================================================

get_time
create_file
create_folder
list_files
read_file
edit_file
search_files
delete_path
save_memory
get_memory
forget_memory
create_website

============================================================
MEMORY BEHAVIOR
============================================================

When saving a memory, save the complete useful fact.

For example:

User:
"Remember that my favorite food is dosa."

Save:

"My favorite food is dosa."

Do NOT save:

"dosa"

When the user asks what you remember,
use the actual memory tool result.

Do not invent additional memories.

============================================================
WEBSITE BUILDER
============================================================

The create_website tool is a professional AI
website builder.

It creates self-contained HTML websites.

Websites generated by this tool are designed to work
from a local HTML file.

They must not depend on external images,
external CSS, external JavaScript, external fonts,
or remote resources.

Inline SVG and CSS artwork are allowed.

============================================================
CONVERSATION
============================================================

Maintain awareness of the current conversation.

If the user says:

"Make it modern."

understand what "it" refers to from the
conversation history.

Do not repeatedly ask for information that
has already been provided.

If enough information exists to perform a task,
perform it.

"""

    if memories:

        prompt += (
            "\n============================================================\n"
            "USER'S LONG-TERM MEMORIES\n"
            "============================================================\n"
        )

        for memory in memories:

            prompt += (
                f"- {memory}\n"
            )

    return prompt


# ============================================================
# MAIN AGENT
# ============================================================

def run_agent(
    user_message,
    conversation=None,
):
    """
    Main Shaqs agent with a proper multi-tool execution loop.

    The model may request multiple tools in one response and may
    request additional tools after seeing previous tool results.

    Example:

        edit_file(...)
        read_file(...)

    Both tools are executed, their real results are returned to
    the model, and the model then produces the final answer.
    """

    if conversation is None:
        conversation = []

    conversation_history = [
        message
        for message in conversation
        if isinstance(message, dict)
        and message.get("role") in {
            "user",
            "assistant",
            "tool",
        }
    ]

    text = user_message.lower().strip()

    messages = [
        {
            "role": "system",
            "content": build_system_prompt(),
        }
    ]

    messages.extend(conversation_history)

    messages.append(
        {
            "role": "user",
            "content": user_message,
        }
    )

    # ========================================================
    # WEBSITE DETECTION
    # ========================================================

    website_start_phrases = [
        "build a website",
        "make a website",
        "create a website",
        "build me a website",
        "make me a website",
        "create me a website",
        "i want a website",
        "i need a website",
        "website for my business",
        "website for my company",
        "website for my brand",
        "build a site",
        "make a site",
        "create a site",
    ]

    website_words = [
        "website",
        "web site",
        "webpage",
        "web page",
        "site",
    ]

    conversation_text = " ".join(
        str(message.get("content", ""))
        for message in conversation_history
        if message.get("role") in {"user", "assistant"}
    ).lower()

    full_website_context = conversation_text + " " + text

    website_started_now = any(
        phrase in text
        for phrase in website_start_phrases
    )

    website_already_discussed = any(
        word in conversation_text
        for word in website_words
    )

    website_mode = (
        website_started_now
        or website_already_discussed
    )

    # ========================================================
    # WEBSITE CONFIRMATION
    # ========================================================

    confirmation_phrases = [
        "yes",
        "yes build it",
        "build it",
        "build it now",
        "create it",
        "create it now",
        "make it",
        "go ahead",
        "go ahead and build it",
        "go ahead and create it",
        "do it",
        "start building",
        "start building it",
        "generate it",
        "generate the website",
        "create the website",
        "build the website",
        "make the website",
        "yes please",
        "that's all",
        "that is all",
        "looks good",
        "everything is good",
    ]

    explicit_build_command = any(
        phrase in text
        for phrase in [
            "build the website",
            "build it now",
            "create the website",
            "create it now",
            "generate the website",
            "generate it now",
            "make the website",
            "make it now",
            "go ahead and build",
            "go ahead and create",
            "start building",
        ]
    )

    simple_confirmation = text in confirmation_phrases

    previous_assistant_message = ""

    for message in reversed(conversation_history):
        if message.get("role") == "assistant":
            previous_assistant_message = str(
                message.get("content", "")
            ).lower().strip()
            break

    confirmation_requested = any(
        phrase in previous_assistant_message
        for phrase in [
            "shall i build",
            "should i build",
            "want me to build",
            "would you like me to build",
            "ready to build",
            "ready for me to build",
            "i have enough information",
            "i have everything i need",
            "i can build it now",
            "i'll build it now",
            "i can create it now",
            "shall i create",
            "want me to create",
        ]
    )

    user_confirmed_build = (
        explicit_build_command
        or (
            simple_confirmation
            and confirmation_requested
        )
    )

    # ========================================================
    # WEBSITE INFORMATION DETECTION
    # ========================================================

    business_indicators = [
        "my business is",
        "my business:",
        "business is",
        "business:",
        "my company is",
        "my company:",
        "company is",
        "company:",
        "my brand is",
        "my brand:",
        "brand is",
        "brand:",
        "i run a",
        "i run an",
        "i own a",
        "i own an",
        "we are a",
        "we are an",
        "we sell",
        "we offer",
        "we provide",
        "we make",
        "we create",
        "i sell",
        "i offer",
        "i provide",
        "i make",
        "i create",
        "it's a",
        "it is a",
    ]

    product_service_indicators = [
        "we sell",
        "we offer",
        "we provide",
        "we make",
        "we create",
        "i sell",
        "i offer",
        "i provide",
        "i make",
        "i create",
        "products",
        "services",
        "product",
        "service",
    ]

    style_indicators = [
        "modern",
        "minimal",
        "minimalist",
        "luxury",
        "premium",
        "professional",
        "elegant",
        "bold",
        "clean",
        "creative",
        "corporate",
        "dark",
        "light",
        "colorful",
        "simple",
        "futuristic",
        "classic",
        "playful",
        "sophisticated",
    ]

    goal_indicators = [
        "sell",
        "selling",
        "shop",
        "shopping",
        "book",
        "booking",
        "contact",
        "contact us",
        "get customers",
        "generate leads",
        "showcase",
        "portfolio",
        "promote",
        "promote my business",
        "online store",
        "ecommerce",
        "e-commerce",
    ]

    has_business_info = any(
        phrase in full_website_context
        for phrase in business_indicators
    )

    has_product_service_info = any(
        phrase in full_website_context
        for phrase in product_service_indicators
    )

    has_style_info = any(
        phrase in full_website_context
        for phrase in style_indicators
    )

    has_goal_info = any(
        phrase in full_website_context
        for phrase in goal_indicators
    )

    _ = (has_style_info, has_goal_info)

    # ========================================================
    # WEBSITE PLANNING MODE
    # ========================================================

    if website_mode and not user_confirmed_build:

        planning_prompt = """
You are Shaqs, a personal AI assistant helping the user
plan a professional business website.

IMPORTANT:

The user is currently in WEBSITE PLANNING MODE.

DO NOT create the website yet.

DO NOT call create_website.

Your job is to have a natural conversation and collect enough
information to build a genuinely useful website.

You need to understand:

1. What type of business it is.
2. Business or brand name.
3. What products or services it provides.
4. Who the target customers are.
5. The main goal of the website.
6. Desired visual style.
7. Important pages or sections.
8. Important functionality.

Do NOT ask all eight questions at once.

Ask only the most important missing question.

Use information the user has already provided.

Do not ask for information that has already been answered.

If the user provides additional requirements, treat them as
website requirements and continue naturally.

Once you believe you have enough information, summarize the
website concept briefly and ask:

"I have everything I need. Shall I build it?"

Only after the user explicitly confirms should the actual
website generator be called.

Never invent important business information.
"""

        planning_messages = [
            {
                "role": "system",
                "content": (
                    build_system_prompt()
                    + "\n\n"
                    + planning_prompt
                ),
            }
        ]

        planning_messages.extend(
            conversation_history
        )

        planning_messages.append(
            {
                "role": "user",
                "content": user_message,
            }
        )

        try:
            planning_response = chat(
                model=MODEL,
                messages=planning_messages,
            )

            assistant_text = (
                planning_response.message.content or ""
            ).strip()

            if not assistant_text:
                assistant_text = (
                    "Absolutely. What kind of business do you run?"
                )

        except Exception as e:
            assistant_text = f"Website planning failed: {e}"

        new_conversation = list(conversation_history)
        new_conversation.append(
            {
                "role": "user",
                "content": user_message,
            }
        )
        new_conversation.append(
            {
                "role": "assistant",
                "content": assistant_text,
            }
        )

        return assistant_text, new_conversation

    # ========================================================
    # WEBSITE GENERATION MODE
    # ========================================================

    if website_mode:

        meaningful_website_information = (
            has_business_info
            or has_product_service_info
        )

        if user_confirmed_build:

            if not meaningful_website_information:
                assistant_text = (
                    "I still need to know what your business "
                    "does before I can build the website. "
                    "What kind of business is it?"
                )

                new_conversation = list(conversation_history)
                new_conversation.append(
                    {
                        "role": "user",
                        "content": user_message,
                    }
                )
                new_conversation.append(
                    {
                        "role": "assistant",
                        "content": assistant_text,
                    }
                )

                return assistant_text, new_conversation

            website_request = f"""
Create the website based on the complete conversation
between the user and Shaqs below.

IMPORTANT:

Use ALL relevant information from the conversation.

Do not invent important business facts.

If some minor details are missing, make sensible design
decisions while keeping claims generic.

The final website MUST be a self-contained local HTML file.

It MUST NOT contain:

- <img>
- external image references
- local image references
- url(...)
- background-image
- http://
- https://
- external CSS
- external JavaScript
- external fonts
- <link>
- iframe
- video
- audio
- object
- embed

Inline SVG and CSS artwork are allowed.

WEBSITE CONVERSATION:

{full_website_context}

END WEBSITE CONVERSATION.

Build the complete professional website now.
"""

            website_tools = [
                tool
                for tool in tools
                if tool["function"]["name"] == "create_website"
            ]

            website_messages = [
                {
                    "role": "system",
                    "content": (
                        build_system_prompt()
                        + """

WEBSITE GENERATION MODE:

The user has completed the website planning process
and explicitly confirmed that the website should now
be created.

Call create_website.

Do not ask more questions unless absolutely necessary.

Use the complete website conversation supplied by the user.

The generated website must be self-contained and must not
use external assets.

Inline SVG is allowed.
"""
                    ),
                }
            ]

            website_messages.extend(conversation_history)
            website_messages.append(
                {
                    "role": "user",
                    "content": website_request,
                }
            )

            try:
                website_response = chat(
                    model=MODEL,
                    messages=website_messages,
                    tools=website_tools,
                )

                website_requests = parse_tool_requests(
                    website_response
                )

            except Exception as e:
                assistant_text = f"Website generation failed: {e}"
                new_conversation = list(conversation_history)
                new_conversation.append(
                    {"role": "user", "content": user_message}
                )
                new_conversation.append(
                    {"role": "assistant", "content": assistant_text}
                )
                return assistant_text, new_conversation

            if not website_requests:
                website_requests = [
                    (
                        "create_website",
                        {"request": website_request},
                    )
                ]

            # Website generation is intentionally restricted to
            # the create_website tool.
            tool_name, arguments = website_requests[0]

            if tool_name != "create_website":
                tool_name = "create_website"
                arguments = {"request": website_request}

            print(
                "\n[ Shaqs is using tool: create_website ]"
            )

            result = execute_tool(
                "create_website",
                arguments,
            )

            print(f"[ Tool result: {result} ]")

            result_lower = result.lower()

            if (
                "failed" in result_lower
                or "error" in result_lower
            ):
                final_text = (
                    "I couldn't create the website yet.\n"
                    f"{result}"
                )
            else:
                final_text = (
                    "Your website has been created successfully.\n"
                    f"{result}"
                )

            new_conversation = list(conversation_history)
            new_conversation.append(
                {"role": "user", "content": user_message}
            )
            new_conversation.append(
                {"role": "assistant", "content": final_text}
            )

            return final_text, new_conversation

    # ========================================================
    # MEMORY TOOL AVAILABILITY
    # ========================================================

    available_tools = [
        tool
        for tool in tools
        if tool["function"]["name"] not in {
            "save_memory",
            "get_memory",
            "forget_memory",
        }
    ]

    explicit_save_request = any(
        phrase in text
        for phrase in [
            "remember that",
            "remember this",
            "save this",
            "save that",
            "save this as memory",
            "save this to memory",
            "store this",
            "store that",
        ]
    )

    if explicit_save_request:
        available_tools.append(
            next(
                tool
                for tool in tools
                if tool["function"]["name"] == "save_memory"
            )
        )

    memory_request = any(
        phrase in text
        for phrase in [
            "what do you remember",
            "what do you remember about me",
            "what do you know about me",
            "show my memories",
            "list my memories",
            "my memories",
        ]
    )

    if memory_request:
        available_tools.append(
            next(
                tool
                for tool in tools
                if tool["function"]["name"] == "get_memory"
            )
        )

    forget_request = any(
        phrase in text
        for phrase in [
            "forget this",
            "forget that",
            "forget the memory",
            "forget my memory",
            "remove this memory",
            "delete this memory",
        ]
    )

    if forget_request:
        available_tools.append(
            next(
                tool
                for tool in tools
                if tool["function"]["name"] == "forget_memory"
            )
        )

    # ========================================================
    # PROPER MULTI-TOOL EXECUTION LOOP
    # ========================================================

    MAX_TOOL_ROUNDS = 8
    last_tool_results = []

    for tool_round in range(1, MAX_TOOL_ROUNDS + 1):

        print(
            f"\n[ Shaqs AI round {tool_round}/{MAX_TOOL_ROUNDS} ]"
        )

        try:
            response = chat(
                model=MODEL,
                messages=messages,
                tools=available_tools,
            )

        except Exception as e:
            final_text = f"Shaqs error: {e}"
            new_conversation = list(conversation_history)
            new_conversation.append(
                {"role": "user", "content": user_message}
            )
            new_conversation.append(
                {"role": "assistant", "content": final_text}
            )
            return final_text, new_conversation

        tool_requests = parse_tool_requests(response)

        # ----------------------------------------------------
        # TOOL CALLS FOUND
        # ----------------------------------------------------

        if tool_requests:

            # Preserve the actual assistant tool-call message.
            if getattr(response.message, "tool_calls", None):
                messages.append(response.message)
            else:
                messages.append(
                    {
                        "role": "assistant",
                        "content": response.message.content or "",
                    }
                )

            # Execute EVERY requested tool.
            for tool_name, arguments in tool_requests:

                print(
                    f"\n[ Shaqs is using tool: {tool_name} ]"
                )
                print(
                    f"[ Tool arguments: {arguments} ]"
                )

                result = execute_tool(
                    tool_name,
                    arguments,
                )

                print(
                    f"[ Tool result: {result} ]"
                )

                last_tool_results.append(
                    {
                        "tool": tool_name,
                        "result": result,
                    }
                )

                # Feed the REAL result back to the model.
                messages.append(
                    {
                        "role": "tool",
                        "content": result,
                    }
                )

            # Ask the model what to do next. It may request
            # another tool, or it may now produce the answer.
            continue

        # ----------------------------------------------------
        # NORMAL RESPONSE
        # ----------------------------------------------------

        assistant_text = (
            response.message.content or ""
        ).strip()

        if not assistant_text:
            if last_tool_results:
                assistant_text = "\n".join(
                    (
                        f"{item['tool']}: "
                        f"{item['result']}"
                    )
                    for item in last_tool_results
                )
            else:
                assistant_text = (
                    "I completed the request, but the model "
                    "did not return a response."
                )

        new_conversation = list(conversation_history)
        new_conversation.append(
            {
                "role": "user",
                "content": user_message,
            }
        )
        new_conversation.append(
            {
                "role": "assistant",
                "content": assistant_text,
            }
        )

        return assistant_text, new_conversation

    # ========================================================
    # TOOL LOOP SAFETY LIMIT
    # ========================================================

    if last_tool_results:
        final_text = (
            "I completed the available tool operations, "
            "but reached the maximum tool-call rounds.\n\n"
            + "\n".join(
                (
                    f"{item['tool']}: "
                    f"{item['result']}"
                )
                for item in last_tool_results
            )
        )
    else:
        final_text = (
            "I couldn't complete the request because the "
            "tool execution loop reached its limit."
        )

    new_conversation = list(conversation_history)
    new_conversation.append(
        {"role": "user", "content": user_message}
    )
    new_conversation.append(
        {"role": "assistant", "content": final_text}
    )

    return final_text, new_conversation

